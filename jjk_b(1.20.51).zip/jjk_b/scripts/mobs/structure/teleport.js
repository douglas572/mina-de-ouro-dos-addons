import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
lib.tick(function(player) {

  const entities = player.dimension.getEntities({type: "lian:structure.hospital.teleport.1", location: player.location})
  entities.forEach(entity => {entity.runCommandAsync("particle lian:teleport.2"); entity.nameTag = "Abandoned hospital\n§cGrade 2"})

  const entities2 = player.dimension.getEntities({type: "lian:structure.hospital.teleport.1", location: player.location, maxDistance: 2})
  const entities3 = player.dimension.getEntities({type: "lian:structure.hospital.teleport.1", location: player.location, maxDistance: 5, minDistance: 3})
  if (entities2[0]) {

    !player.getDynamicProperty("teleporting") ? player.setDynamicProperty("teleporting", 20): null
    !entities2[0].getDynamicProperty("locationOfStructureX") ? entities2[0].setDynamicProperty("locationOfStructureX", lib.random(9999, -9999)): null; !entities2[0].getDynamicProperty("locationOfStructureZ") ? entities2[0].setDynamicProperty("locationOfStructureZ", lib.random(9999, -9999)): null
    player.setDynamicProperty("locationOfStructureX", entities2[0].getDynamicProperty("locationOfStructureX")); player.setDynamicProperty("locationOfStructureZ", entities2[0].getDynamicProperty("locationOfStructureZ"))
    player.getDynamicProperty("grade") === 6 || player.getDynamicProperty("grade") <= 2 && player.getDynamicProperty("teleporting") > 0 && player.getDynamicProperty("structureIs") === 0 && player.getDynamicProperty("canTeleport") == 0 && !player.hasTag("isInExpansion")  ? player.setDynamicProperty("teleporting", player.getDynamicProperty("teleporting") - 1): null
    player.getDynamicProperty("canTeleport") == 0 ? lib.subtitle(player, "teleporting in " + parseInt(player.getDynamicProperty("teleporting") / 5)): null
    if (player.getDynamicProperty("teleporting") === 0) {

      entities2[0].runCommandAsync("execute in the_end positioned ~ 100 ~ run fill " + (entities2[0].getDynamicProperty("locationOfStructureX") + 20) + " ~ " + (entities2[0].getDynamicProperty("locationOfStructureZ") + 20) + " " + (entities2[0].getDynamicProperty("locationOfStructureX") - 20) + " ~ " + (entities2[0].getDynamicProperty("locationOfStructureZ") - 20)+ " lian:void_expansion.1 outline").then(() => {

        !entities2[0].hasTag("generated") ? (entities2[0].runCommandAsync("execute in the_end run structure load hospital " + (entities2[0].getDynamicProperty("locationOfStructureX") - 30) + " 102 " + (entities2[0].getDynamicProperty("locationOfStructureZ") - 15)), entities2[0].addTag("generated")): null
        player.hasTag("secondHotbar") ? (lib.close(player), player.setDynamicProperty("skill", 0)): null
        player.setDynamicProperty("locAfterStructureX", player.location.x)
        player.setDynamicProperty("locAfterStructureY", player.location.y)
        player.setDynamicProperty("locAfterStructureZ", player.location.z)
        entities2[0].runCommandAsync("execute as @a[name=\"" + player.nameTag + "\"] in the_end positioned " + player.getDynamicProperty("locationOfStructureX") + " 170 " + player.getDynamicProperty("locationOfStructureX") + " run tp ~~~")
        player.setDynamicProperty("structureTime", 20); player.setDynamicProperty("structureIs", 1)
        player.runCommandAsync("fog @s push lian:hospital structureFog")
        mc.system.runTimeout(() => {player.runCommandAsync("music play record.far 1 3 loop")}, lib.convertTick(4))
        player.runCommandAsync("gamemode adventure")
        player.removeTag("breacksBlock")
        player.addTag("pvp")
  
  
      })


    }


  } if (entities3[0]) {

    player.setDynamicProperty("teleporting", 20)
    player.setDynamicProperty("canTeleport", 0)
    lib.subtitle(player, "")


  }

}, 1)
lib.tick(function(player) {
  
  const entities = player.dimension.getEntities({type: "lian:structure.store.teleport.1", location: player.location})
  entities.forEach(entity => {entity.runCommandAsync("particle lian:teleport.1"); entity.nameTag = "Store"})

  const entities2 = player.dimension.getEntities({type: "lian:structure.store.teleport.1", location: player.location, maxDistance: 2})
  const entities3 = player.dimension.getEntities({type: "lian:structure.store.teleport.1", location: player.location, maxDistance: 5, minDistance: 3})
  if (entities2[0]) {

    !player.getDynamicProperty("teleporting") ? player.setDynamicProperty("teleporting", 20): null
    !entities2[0].getDynamicProperty("locationOfStructureX") ? entities2[0].setDynamicProperty("locationOfStructureX", lib.random(9999, -9999)): null; !entities2[0].getDynamicProperty("locationOfStructureZ") ? entities2[0].setDynamicProperty("locationOfStructureZ", lib.random(9999, -9999)): null
    player.setDynamicProperty("locationOfStructureX", entities2[0].getDynamicProperty("locationOfStructureX")); player.setDynamicProperty("locationOfStructureZ", entities2[0].getDynamicProperty("locationOfStructureZ"))
    player.getDynamicProperty("teleporting") > 0 && player.getDynamicProperty("structureIs") === 0 && player.getDynamicProperty("canTeleport") == 0 && !player.hasTag("isInExpansion")  ? player.setDynamicProperty("teleporting", player.getDynamicProperty("teleporting") - 1): null
    player.getDynamicProperty("canTeleport") == 0 ? lib.subtitle(player, "teleporting in " + parseInt(player.getDynamicProperty("teleporting") / 5)): null
    if (player.getDynamicProperty("teleporting") === 0) {

      entities2[0].runCommandAsync("execute in the_end positioned ~ 100 ~ run fill " + (entities2[0].getDynamicProperty("locationOfStructureX") + 15) + " ~ " + (entities2[0].getDynamicProperty("locationOfStructureZ") + 15) + " " + (entities2[0].getDynamicProperty("locationOfStructureX") - 15) + " ~ " + (entities2[0].getDynamicProperty("locationOfStructureZ") - 15)+ " lian:void_expansion.1 outline").then(() => {

        !entities2[0].hasTag("generated") ? (entities2[0].runCommandAsync("execute in the_end run structure load store " + (entities2[0].getDynamicProperty("locationOfStructureX") - 15) + " 102 " + (entities2[0].getDynamicProperty("locationOfStructureZ") - 15)), entities2[0].addTag("generated")): null
        player.hasTag("secondHotbar") ? (lib.close(player), player.setDynamicProperty("skill", 0)): null
        player.setDynamicProperty("locAfterStructureX", player.location.x)
        player.setDynamicProperty("locAfterStructureY", player.location.y)
        player.setDynamicProperty("locAfterStructureZ", player.location.z)
        entities2[0].runCommandAsync("execute as @a[name=\"" + player.nameTag + "\"] in the_end positioned " + player.getDynamicProperty("locationOfStructureX") + " 170 " + player.getDynamicProperty("locationOfStructureX") + " run tp ~~~")
        player.setDynamicProperty("structureTime", 20); player.setDynamicProperty("structureIs", 1)
        player.runCommandAsync("fog @s push lian:store structureFog")
        mc.system.runTimeout(() => {player.runCommandAsync("music play record.mall 1 3 loop")}, lib.convertTick(4))
        player.runCommandAsync("gamemode adventure")
        player.removeTag("breacksBlock")
        player.removeTag("pvp")
        player.addTag("invulnerableStructure")
  
  
      })


    }


  } if (entities3[0]) {

    player.setDynamicProperty("teleporting", 20)
    player.setDynamicProperty("canTeleport", 0)
    lib.subtitle(player, "")


  }

}, 1)
lib.tick(function(player) {

  const entities = player.dimension.getEntities({type: "lian:structure.yaga.teleport.1", location: player.location})
  entities.forEach(entity => {entity.runCommandAsync("particle lian:teleport.2"); entity.nameTag = "Cursed place\n§cGrade 3"})


  const entities2 = player.dimension.getEntities({type: "lian:structure.yaga.teleport.1", location: player.location, maxDistance: 2})
  const entities3 = player.dimension.getEntities({type: "lian:structure.yaga.teleport.2", location: player.location, maxDistance: 5, minDistance: 3})
  if (entities2[0]) {

    !player.getDynamicProperty("teleporting") ? player.setDynamicProperty("teleporting", 20): null
    !entities2[0].getDynamicProperty("locationOfStructureX") ? entities2[0].setDynamicProperty("locationOfStructureX", lib.random(9999, -9999)): null; !entities2[0].getDynamicProperty("locationOfStructureZ") ? entities2[0].setDynamicProperty("locationOfStructureZ", lib.random(9999, -9999)): null
    player.setDynamicProperty("locationOfStructureX", entities2[0].getDynamicProperty("locationOfStructureX")); player.setDynamicProperty("locationOfStructureZ", entities2[0].getDynamicProperty("locationOfStructureZ"))
    player.getDynamicProperty("grade") === 6 || player.getDynamicProperty("grade") <= 3 && player.getDynamicProperty("teleporting") > 0 & player.getDynamicProperty("structureIs") === 0 && player.getDynamicProperty("canTeleport") == 0 && !player.hasTag("isInExpansion") ? player.setDynamicProperty("teleporting", player.getDynamicProperty("teleporting") - 1): null
    player.getDynamicProperty("canTeleport") == 0 ? lib.subtitle(player, "teleporting in " + parseInt(player.getDynamicProperty("teleporting") / 5)): null
    if (player.getDynamicProperty("teleporting") === 0) {

      entities2[0].runCommandAsync("execute in the_end positioned ~ 100 ~ run fill " + (entities2[0].getDynamicProperty("locationOfStructureX") + 15) + " ~ " + (entities2[0].getDynamicProperty("locationOfStructureZ") + 15) + " " + (entities2[0].getDynamicProperty("locationOfStructureX") - 15) + " ~ " + (entities2[0].getDynamicProperty("locationOfStructureZ") - 15)+ " lian:void_expansion.1 outline").then(() => {

        !entities2[0].hasTag("generated") ? (entities2[0].runCommandAsync("execute in the_end run structure load yaga " + (entities2[0].getDynamicProperty("locationOfStructureX") - 15) + " 102 " + (entities2[0].getDynamicProperty("locationOfStructureZ") - 15)), entities2[0].addTag("generated")): null
        player.hasTag("secondHotbar") ? (lib.close(player), player.setDynamicProperty("skill", 0)): null
        player.setDynamicProperty("locAfterStructureX", player.location.x)
        player.setDynamicProperty("locAfterStructureY", player.location.y)
        player.setDynamicProperty("locAfterStructureZ", player.location.z)
        entities2[0].runCommandAsync("execute as @a[name=\"" + player.nameTag + "\"] in the_end positioned " + player.getDynamicProperty("locationOfStructureX") + " 170 " + player.getDynamicProperty("locationOfStructureX") + " run tp ~~~")
        player.setDynamicProperty("structureTime", 20); player.setDynamicProperty("structureIs", 1)
        player.runCommandAsync("fog @s push lian:yaga structureFog")
        mc.system.runTimeout(() => {player.runCommandAsync("music play record.blocks 1 3 loop")}, lib.convertTick(4))
        player.runCommandAsync("gamemode adventure")
        player.removeTag("breacksBlock")
        player.addTag("pvp")
  
  
      })


    }


  } if (entities3[0]) {

    player.setDynamicProperty("teleporting", 20)
    player.setDynamicProperty("canTeleport", 0)
    lib.subtitle(player, "")


  }

}, 1)
lib.tick(function(player) {

  const entities = player.dimension.getEntities({type: "lian:structure.city.teleport.1", location: player.location})
  entities.forEach(entity => {entity.runCommandAsync("particle lian:teleport.2"); entity.nameTag = "City - Boss\n§cGrade 1"})


  const entities2 = player.dimension.getEntities({type: "lian:structure.city.teleport.1", location: player.location, maxDistance: 2})
  const entities3 = player.dimension.getEntities({type: "lian:structure.city.teleport.1", location: player.location, maxDistance: 5, minDistance: 3})
  if (entities2[0]) {

    !player.getDynamicProperty("teleporting") ? player.setDynamicProperty("teleporting", 20): null
    !entities2[0].getDynamicProperty("locationOfStructureX") ? entities2[0].setDynamicProperty("locationOfStructureX", lib.random(9999, -9999)): null; !entities2[0].getDynamicProperty("locationOfStructureZ") ? entities2[0].setDynamicProperty("locationOfStructureZ", lib.random(9999, -9999)): null
    player.setDynamicProperty("locationOfStructureX", entities2[0].getDynamicProperty("locationOfStructureX")); player.setDynamicProperty("locationOfStructureZ", entities2[0].getDynamicProperty("locationOfStructureZ"))
    player.getDynamicProperty("grade") === 6 || player.getDynamicProperty("grade") <= 1 && player.getDynamicProperty("teleporting") > 0 & player.getDynamicProperty("structureIs") === 0 && player.getDynamicProperty("canTeleport") == 0 && !player.hasTag("isInExpansion") ? player.setDynamicProperty("teleporting", player.getDynamicProperty("teleporting") - 1): null
    player.getDynamicProperty("canTeleport") == 0 ? lib.subtitle(player, "teleporting in " + parseInt(player.getDynamicProperty("teleporting") / 5)): null
    if (player.getDynamicProperty("teleporting") === 0) {

      entities2[0].runCommandAsync("execute in the_end positioned ~ 100 ~ run fill " + (entities2[0].getDynamicProperty("locationOfStructureX") + 32) + " ~ " + (entities2[0].getDynamicProperty("locationOfStructureZ") + 32) + " " + (entities2[0].getDynamicProperty("locationOfStructureX") - 32) + " ~ " + (entities2[0].getDynamicProperty("locationOfStructureZ") - 15)+ " lian:void_expansion.1 outline").then(() => {

        !entities2[0].hasTag("generated") ? (entities2[0].runCommandAsync("execute in the_end run structure load city " + (entities2[0].getDynamicProperty("locationOfStructureX") - 32) + " 102 " + (entities2[0].getDynamicProperty("locationOfStructureZ") - 32)), entities2[0].addTag("generated")): null
        player.hasTag("secondHotbar") ? (lib.close(player), player.setDynamicProperty("skill", 0)): null
        player.setDynamicProperty("locAfterStructureX", player.location.x)
        player.setDynamicProperty("locAfterStructureY", player.location.y)
        player.setDynamicProperty("locAfterStructureZ", player.location.z)
        entities2[0].runCommandAsync("execute as @a[name=\"" + player.nameTag + "\"] in the_end positioned " + player.getDynamicProperty("locationOfStructureX") + " 170 " + player.getDynamicProperty("locationOfStructureX") + " run tp ~~~")
        player.setDynamicProperty("structureTime", 20); player.setDynamicProperty("structureIs", 1)
        player.runCommandAsync("fog @s push lian:city structureFog")
        mc.system.runTimeout(() => {player.runCommandAsync("music play record.blocks 1 3 loop")}, lib.convertTick(4))
        player.runCommandAsync("gamemode adventure")
        player.addTag("pvp")
  
  
      })


    }


  } if (entities3[0]) {

    player.setDynamicProperty("teleporting", 20)
    player.setDynamicProperty("canTeleport", 0)
    lib.subtitle(player, "")


  }

}, 1)
lib.tick(function(player) {

  const entities = player.dimension.getEntities({type: "lian:structure.spawn", location: player.location})
  entities.forEach(entity => {
    
    entity.runCommandAsync("particle lian:teleport.1")
    const players = player.dimension.getEntities({type: "minecraft:player", location: entity.location, maxDistance: 200, minDistance: 150})
    if (players[0]) {

      player.teleport(entity.location)


    }

  
  })
  const entities2 = player.dimension.getEntities({type: "lian:structure.spawn", location: player.location, maxDistance: 3})
  const entities3 = player.dimension.getEntities({type: "lian:structure.spawn", location: player.location, maxDistance: 5, minDistance: 3})
  if (entities2[0]) {

    !player.getDynamicProperty("teleporting") ? player.setDynamicProperty("teleporting", 20): null
    player.getDynamicProperty("teleporting") > 0 && player.getDynamicProperty("structureIs") === 0 && player.getDynamicProperty("canTeleport") == 0 && !player.hasTag("isInExpansion")  ? player.setDynamicProperty("teleporting", player.getDynamicProperty("teleporting") - 1): null
    player.getDynamicProperty("canTeleport") == 0 ? lib.subtitle(player, "teleporting in " + parseInt(player.getDynamicProperty("teleporting") / 5)): null
    if (player.getDynamicProperty("teleporting") === 0) {

      player.hasTag("secondHotbar") ? (lib.close(player), player.setDynamicProperty("skill", 0)): null
      player.runCommandAsync("execute in overworld positioned " + player.getDynamicProperty("locAfterStructureX") + " " + player.getDynamicProperty("locAfterStructureY") + " " + player.getDynamicProperty("locAfterStructureZ") + " run tp ~~~")
      player.setDynamicProperty("canTeleport", 1)
      player.runCommandAsync("fog @s remove structureFog")
      player.runCommandAsync("music stop")
      player.runCommandAsync("gamemode survival")
      player.addTag("breacksBlock")
      player.addTag("pvp")
      player.removeTag("invulnerableStructure")


    }


  } if (entities3[0]) {

    player.setDynamicProperty("teleporting", 20)
    player.setDynamicProperty("canTeleport", 0)
    lib.subtitle(player, "")


  }

}, 1)