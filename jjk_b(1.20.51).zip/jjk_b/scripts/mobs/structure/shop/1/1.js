import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../../../lib.js";
shop({

  identifier: "lian:npc.structure.shop.1.1",
  title: "Weapons",
  condition: function(player) {if (lib.getItemInInventory(player, "lian:skills.4.open")) {return true} else {return false}},
  buttons: [
    {custo: 70000, custoDisplay: 70000, texture: "textures/weapon/1.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 10000, custoDisplay: 10000, texture: "textures/weapon/3.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.3 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 15000, custoDisplay: 15000, texture: "textures/weapon/4.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.4 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 5000, custoDisplay: 5000, texture: "textures/weapon/5.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.5 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 50000, custoDisplay: 50000, texture: "textures/weapon/7.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.7 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 70000, custoDisplay: 70000, texture: "textures/weapon/10.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.10 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 5000, custoDisplay: 5000, texture: "textures/lian/icons/skills/random", comando: function(player) {player.runCommandAsync(`give @s lian:random.inata.2 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}}
  ],
  buttons2: [
    {custo: 70000 / 100 * 80, custoDisplay: 70000 / 100 * 80, texture: "textures/weapon/1.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 10000 / 100 * 80, custoDisplay: 10000 / 100 * 80, texture: "textures/weapon/3.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.3 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 15000 / 100 * 80, custoDisplay: 15000 / 100 * 80, texture: "textures/weapon/4.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.4 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 5000 / 100 * 80, custoDisplay: 5000 / 100 * 80, texture: "textures/weapon/5.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.5 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 50000 / 100 * 80, custoDisplay: 50000 / 100 * 80, texture: "textures/weapon/7.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.7 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 70000 / 100 * 80, custoDisplay: 70000 / 100 * 80, texture: "textures/weapon/10.icon", comando: function(player) {player.runCommandAsync(`give @s lian:weapon.10 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}},
    {custo: 5000 / 100 * 80, custoDisplay: 5000 / 100 * 80, texture: "textures/lian/icons/skills/random", comando: function(player) {player.runCommandAsync(`give @s lian:random.inata.2 1 0 {"minecraft:item_lock":{ "mode": "lock_in_inventory" }, "minecraft:keep_on_death":{}}`)}}
  ]


})

function shop(informations) {

  mc.world.afterEvents.entityHitEntity.subscribe((data) => {let player = data.damagingEntity; let victim = data.hitEntity; if (victim && player.typeId === "minecraft:player" && victim.typeId === informations.identifier && !informations.condition(player)) {

    const userInterface = new ui.ActionFormData(); userInterface.title("shop:" + informations.title); userInterface.body(""); for (let i = 0; i <= (informations.buttons.length - 1); i++) {userInterface.button(`Custo: ${lib.getScore(player, "yen") >= informations.buttons[i].custo ? "§a": "§c"}${informations.buttons[i].custoDisplay}$`,informations.buttons[i].texture);}; userInterface.show(player).then((response) => {for (let i = 0; i <= (informations.buttons.length - 1); i++) {if (response.selection === i) {lib.getScore(player, "yen") >= informations.buttons[i].custo ? (informations.buttons[i].comando(player),player.runCommandAsync(`scoreboard players remove @s yen ${informations.buttons[i].custo}`),lib.tell(player, `§eCompra feita`)): (lib.tell(player, `§cVocê não possui yen o suficiente`))}}}).catch((error) => {console.warn(error);}); victim.playAnimation("animation.npc.1.interact")

  } else if(victim && player.typeId === "minecraft:player" && victim.typeId === informations.identifier && informations.condition(player)) {

    const userInterface = new ui.ActionFormData(); userInterface.title("shop:" + informations.title); userInterface.body(""); for (let i = 0; i <= (informations.buttons2.length - 1); i++) {userInterface.button(`Custo: ${lib.getScore(player, "yen") >= informations.buttons2[i].custo ? "§a": "§c"}${informations.buttons2[i].custoDisplay}$`,informations.buttons2[i].texture);}; userInterface.show(player).then((response) => {for (let i = 0; i <= (informations.buttons2.length - 1); i++) {if (response.selection === i) {lib.getScore(player, "yen") >= informations.buttons2[i].custo ? (informations.buttons2[i].comando(player),player.runCommandAsync(`scoreboard players remove @s yen ${informations.buttons2[i].custo}`),lib.tell(player, `§eCompra feita`), player.playSound("note.banjo")): (lib.hitUi(player, "§cYou don't have enough yen"), player.playSound("note.bass"))}}}).catch((error) => {console.warn(error);}); victim.playAnimation("animation.npc.1.interact")


  }
})


}