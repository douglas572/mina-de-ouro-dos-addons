import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../../../lib.js";
shop({

  identifier: "lian:npc.structure.shop.2.1",
  title: "Npc",
  buttons: [
    
    {custo: 700, custoDisplay: "700", texture: "textures/custom/clothing/1/1.icon", comando: function(player) {player.addTag("clothing.1.1")}},
    {custo: 1000, custoDisplay: "1000", texture: "textures/custom/clothing/1/2.icon", comando: function(player) {player.addTag("clothing.1.2")}},
    {custo: 700, custoDisplay: "700", texture: "textures/custom/clothing/1/3.icon", comando: function(player) {player.addTag("clothing.1.3")}},
    {custo: 1200, custoDisplay: "1200", texture: "textures/custom/clothing/1/4.icon", comando: function(player) {player.addTag("clothing.1.4")}},

    {custo: 800, custoDisplay: "800", texture: "textures/custom/clothing/2/1.icon", comando: function(player) {player.addTag("clothing.2.1")}},
    {custo: 1000, custoDisplay: "1000", texture: "textures/custom/clothing/2/2.icon", comando: function(player) {player.addTag("clothing.2.2")}},
    {custo: 750, custoDisplay: "750", texture: "textures/custom/clothing/2/3.icon", comando: function(player) {player.addTag("clothing.2.3")}},
    {custo: 750, custoDisplay: "750", texture: "textures/custom/clothing/2/4.icon", comando: function(player) {player.addTag("clothing.2.4")}},
    {custo: 1200, custoDisplay: "1200", texture: "textures/custom/clothing/2/5.icon", comando: function(player) {player.addTag("clothing.2.5")}},
    {custo: 1200, custoDisplay: "1200", texture: "textures/custom/clothing/2/6.icon", comando: function(player) {player.addTag("clothing.2.6")}},

    {custo: 1200, custoDisplay: "1600", texture: "textures/custom/clothing/2/7.icon", comando: function(player) {player.addTag("clothing.2.7")}},
    {custo: 1200, custoDisplay: "750", texture: "textures/custom/clothing/2/9.icon", comando: function(player) {player.addTag("clothing.2.9")}},
    {custo: 1200, custoDisplay: "750", texture: "textures/custom/clothing/2/10.icon", comando: function(player) {player.addTag("clothing.2.10")}},

    {custo: 600, custoDisplay: "600", texture: "textures/custom/clothing/3/1.icon", comando: function(player) {player.addTag("clothing.3.1")}},
    {custo: 800, custoDisplay: "800", texture: "textures/custom/clothing/3/2.icon", comando: function(player) {player.addTag("clothing.3.2")}},
    {custo: 450, custoDisplay: "450", texture: "textures/custom/clothing/3/3.icon", comando: function(player) {player.addTag("clothing.3.3")}},
    {custo: 450, custoDisplay: "450", texture: "textures/custom/clothing/3/4.icon", comando: function(player) {player.addTag("clothing.3.4")}},
    {custo: 700, custoDisplay: "700", texture: "textures/custom/clothing/3/5.icon", comando: function(player) {player.addTag("clothing.3.5")}},

    {custo: 700, custoDisplay: "1600", texture: "textures/custom/clothing/3/6.icon", comando: function(player) {player.addTag("clothing.3.6")}},
    {custo: 700, custoDisplay: "800", texture: "textures/custom/clothing/3/8.icon", comando: function(player) {player.addTag("clothing.3.8")}},
    {custo: 700, custoDisplay: "800", texture: "textures/custom/clothing/3/9.icon", comando: function(player) {player.addTag("clothing.3.9")}},
    {custo: 700, custoDisplay: "800", texture: "textures/custom/clothing/3/10.icon", comando: function(player) {player.addTag("clothing.3.10")}}
  
  ]


})

function shop(informations) {

  mc.world.afterEvents.entityHitEntity.subscribe((data) => {

    let player = data.damagingEntity;
    let victim = data.hitEntity;

    if (victim && player.typeId === "minecraft:player" && victim.typeId === informations.identifier) {

      const userInterface = new ui.ActionFormData()
      userInterface.title("shop:" + informations.title)
      userInterface.body("")
      for (let i = 0; i <= (informations.buttons.length - 1); i++) {

        userInterface.button(`Custo: ${
          lib.getScore(player, "yen") >= informations.buttons[i].custo ? "§a": "§c"
          }${informations.buttons[i].custoDisplay}$`,
          informations.buttons[i].texture);


      }

      userInterface.show(player).then((response) => {

        for (let i = 0; i <= (informations.buttons.length - 1); i++) {

          if (response.selection === i) {

            lib.getScore(player, "yen") >= informations.buttons[i].custo ? (

              informations.buttons[i].comando(player),
              player.runCommandAsync(`scoreboard players remove @s yen ${informations.buttons[i].custo}`),
              lib.tell(player, `§eCompra feita`),
              player.playSound("note.banjo")


            ): (

              lib.hitUi(player, "§cYou don't have enough yen"),
              player.playSound("note.bass")


            )


          }


        }
      }).catch((error) => {

        console.warn(error);


      })


    }


  })


}