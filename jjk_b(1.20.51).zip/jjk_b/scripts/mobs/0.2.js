import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../lib.js";

// configurations
const entity = {
  
  typeId: "lian:enemy.0.2",
  name: "Masked",
  class: "§cGrade 2"


}
const powersHit = [{

  name: "power 1", 
  function: function(player, entity) {

    !player.getDynamicProperty("combo") ? player.setDynamicProperty("combo", 0): null
    if (player.getDynamicProperty("combo") === 0) {
  
      player.setDynamicProperty("combo", 1)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(10, 20) / 10, 0.2)
      player.playAnimation("animation.attack.1")
  
  
    } else if (player.getDynamicProperty("combo") === 1) {
  
      player.setDynamicProperty("combo", 0)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(10, 20) / 10, 0.2)
      player.playAnimation("animation.attack.2")
  
  
    }
    
  
  }

}]

// hit event
mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entityDamaged = event.hitEntity; const entityLocation = {x: entityDamaged.location.x, y: entityDamaged.location.y, z: entityDamaged.location.z}
  if (player.typeId === entity.typeId) {

    powersHit[0].function(player, entityDamaged)


  }


})

mc.system.afterEvents.scriptEventReceive.subscribe(event => {

  const id = event.id, player = event.sourceEntity, message = event.message
  if (id === "lian:spawnEntity" && player.typeId === entity.typeId) {

    player.setDynamicProperty("name", entity.name)
    player.setDynamicProperty("class", entity.class)

  }


})