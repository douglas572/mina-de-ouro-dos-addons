import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../lib.js";

// configurations
const entity = {
  
  typeId: "lian:mobs.npc.sukuna",
  name: "Sukuna Heian",
  class: "§cGrade Especial",
  health: [4500, 5000],
  scale: [13, 12],
  damage: [80, 120],
  velocity: [5, 6]


}
const powersHit = [{

  name: "power 1", 
  function: function(player, damagedEntity) {

    !player.getDynamicProperty("combo") ? player.setDynamicProperty("combo", 0): null
    if (player.getDynamicProperty("combo") === 0) {
  
      player.setDynamicProperty("combo", 1)
      damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(10, 20) / 10, 0.2)
      player.playAnimation("animation.attack.1")
  
  
    } else if (player.getDynamicProperty("combo") === 1) {
  
      player.setDynamicProperty("combo", 2)
      damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(10, 20) / 10, 0.2)
      player.playAnimation("animation.attack.2")
  
  
    } else if (player.getDynamicProperty("combo") === 2) {
  
      player.setDynamicProperty("combo", 0)

      mc.world.playSound("explode", player.location, {volume: 1.0, pitch: lib.random(8, 12) / 10})
      damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(100, 130) / 10, 0.2)
      damagedEntity.runCommandAsync("particle lian:explosion")
      mc.system.runTimeout(() => {player.teleport(lookDirection(damagedEntity, -1), {facingLocation: damagedEntity.location})}, lib.convertTick(0.8))
      damagedEntity.applyDamage(entity.damage[1] * 1.5, {damagingEntity: player, cause: "contact"})


      player.playAnimation("animation.attack.1")
  
  
    }
    
  
  }

},
{

  name: "power 2", 
  function: function(player, damagedEntity) {

    !player.getDynamicProperty("skills.6.1") ? player.setDynamicProperty("skills.6.1", 0): null
    if (player.getDynamicProperty("skills.6.1") === 0) {
  
      lib.conditionSkillMob(player, 20, 0, (player) => {

        player.setDynamicProperty("skills.6.1", 1)
        damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(20, 25) / 10, 0.2)
        damagedEntity.applyDamage(entity.damage[1] * 1.5, {damagingEntity: player, cause: "entityAttack"})
        player.playAnimation("animation.player.skills.6.1.1")
        damagedEntity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
        mc.world.playSound("weapon.1.1", player.location, {volume: 10, pitch: lib.random(8, 12) / 10})


      })
  
  
    } else if (player.getDynamicProperty("skills.6.1") === 1) {
  
      lib.conditionSkillMob(player, 20, 0, (player) => {

        player.setDynamicProperty("skills.6.1", 0)
        damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(20, 25) / 10, 0.2)
        damagedEntity.applyDamage(entity.damage[1] * 2, {damagingEntity: player, cause: "entityAttack"})
        player.playAnimation("animation.player.skills.6.1.2")
        damagedEntity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
        mc.world.playSound("weapon.1.1", player.location, {volume: 10, pitch: lib.random(12, 18) / 10})


      })
      
  
    }
    
  
  }

},
{

  name: "power 3", 
  function: function(player, nothing) {

    const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 5, minDistance: 0, excludeFamilies: ["not"], exclueTypes: ["orb", "item"]})
    if (!entities[0]) return
    !player.getDynamicProperty("skills.6.2") ? player.setDynamicProperty("skills.6.2", 0): null
    if (player.getDynamicProperty("skills.6.2") === 0) {
  
      lib.conditionSkillMob(player, 20, 0, (player) => {

        player.setDynamicProperty("skills.6.2", 1)
        mc.system.runTimeout(() => {
    
          mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(10, 17) / 10})
          entities.forEach(damagedEntity => {
    
            damagedEntity.applyDamage(entity.damage[1] * 1, {damagingEntity: player, cause: "contact"})
            damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
            damagedEntity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
            damagedEntity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      
          })
    
    
        }, lib.convertTick(0.2))
        player.playAnimation("animation.player.skills.6.2.1")


      })
  
  
    } else if (player.getDynamicProperty("skills.6.2") === 1) {
  
      lib.conditionSkillMob(player, 20, 0, (player) => {

        player.setDynamicProperty("skills.6.2", 2)
        mc.system.runTimeout(() => {
    
          mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(17, 20) / 10})
          entities.forEach(damagedEntity => {
    
            damagedEntity.applyDamage(entity.damage[1] * 1.5, {damagingEntity: player, cause: "contact"})
            damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
            damagedEntity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
            damagedEntity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      
          })
    
    
        }, lib.convertTick(0.2))
        player.playAnimation("animation.player.skills.6.2.2")

        
      })
  
  
    } else if (player.getDynamicProperty("skills.6.2") === 2) {
  
      lib.conditionSkillMob(player, 20, 0, (player) => {

        player.setDynamicProperty("skills.6.2", 3)
        mc.system.runTimeout(() => {
    
          mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(20, 22) / 10})
          entities.forEach(damagedEntity => {
    
            damagedEntity.applyDamage(entity.damage[1] * 2, {damagingEntity: player, cause: "contact"})
            damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
            damagedEntity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
            damagedEntity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      
          })
    
    
        }, lib.convertTick(0.2))
        player.playAnimation("animation.player.skills.6.2.3")


      })
  
  
    } else if (player.getDynamicProperty("skills.6.2") === 3) {
  
      lib.conditionSkillMob(player, 20, 0, (player) => {

        player.setDynamicProperty("skills.6.2", 0)
        mc.system.runTimeout(() => {
    
          mc.world.playSound("explode", player.location, {volume: 1.0, pitch: lib.random(8, 10) / 10})
          mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(22, 25) / 10})
          entities.forEach(damagedEntity => {
    
            damagedEntity.applyDamage(entity.damage[1] * 2.5, {damagingEntity: player, cause: "contact"})
            damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 12, 0.2)
            damagedEntity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
            damagedEntity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
            damagedEntity.runCommandAsync("particle lian:skills.6.2.3 ~~1~")
            mc.system.runTimeout(() => {player.teleport(lookDirection(damagedEntity, -1), {facingLocation: damagedEntity.location})}, lib.convertTick(0.8))
      
          })
    
    
        }, lib.convertTick(0.2))
        player.playAnimation("animation.player.skills.6.2.4")
        mc.system.runTimeout(() => {player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 2.5, 0.2)}, lib.convertTick(0.3))


      })
  
  
    }
  
  
  }

},
{

  name: "power 4", 
  function: function(player) {

    lib.conditionSkillMob(player, 150, 1, (player) => {

      mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.6.1." + lib.random(1, 1))
      mc.system.runTimeout(() => {
        
        const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
        locate.runCommandAsync("execute at @a[name=id_" + player.getDynamicProperty("id") + "] positioned ^^^0.5 run tp @s ~~~ ~~").then(() => {
    
          const projectile = player.dimension.spawnEntity("lian:skills.6.3", {x: locate.location.x, y: locate.location.y, z: locate.location.z})
          projectile.nameTag = player.nameTag
          projectile.setProperty("lian:pivot_x", player.getRotation().x)
          projectile.setProperty("lian:pivot_y", player.getRotation().y)
          projectile.setProperty("lian:pivot_z", lib.random(90, -90))
          projectile.applyImpulse({x: player.getViewDirection().x * 2, y: player.getViewDirection().y  * 2, z: player.getViewDirection().z * 2})
          projectile.setDynamicProperty("initialDirectionX", player.getViewDirection().x); projectile.setDynamicProperty("initialDirectionZ", player.getViewDirection().z)
          const tick = mc.system.runInterval(() => {
    
            mc.world.playSound("weapon.1.1", projectile.location, {volume: 10, pitch: lib.random(8, 12) / 10})
            mc.world.playSound("explode", projectile.location, {volume: 10, pitch: lib.random(8, 12) / 10})
            projectile.dimension.createExplosion({x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, 3, {breaksBlocks: false, source: player})
            const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: 10, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()})
            const entities = player.dimension.getEntities({location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
            entities.forEach(entity => {
    
              try {
    
                entity.applyKnockback(projectile.getDynamicProperty("initialDirectionX"), projectile.getDynamicProperty("initialDirectionZ"), 1, 0.8)
                entity.applyDamage(entity.damage[1] * 0.5, {damagingEntity: player, cause: "contact"})
    
    
              } catch {}
    
    
            })
    
          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {mc.system.clearRun(tick); entity.remove()}, lib.convertTick(3))
          mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
          entity.addTag("finalPress")
    
    
        })
    
    
      }, lib.convertTick(0))


    })
    
  
  } 

},]

function lookDirection(player, distance) {

  return mc.Vector.add(player.getHeadLocation(), mc.Vector.multiply(player.getViewDirection(), distance))


}
// hit event
mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entityDamaged = event.hitEntity; const entityLocation = {x: entityDamaged.location.x, y: entityDamaged.location.y, z: entityDamaged.location.z}
  if (player.typeId === entity.typeId) {

    powersHit[lib.random(0, 3)].function(player, entityDamaged)


  }


})


// reverse event
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("overworld").getEntities({type: entity.typeId})
  entities.forEach(player => {
    
    if (player.getComponent("minecraft:health").currentValue < 800) {

      lib.conditionSkillMob(player, 500, 1, function() {
      
        const life = player.getComponent("minecraft:health").currentValue + parseInt(player.getComponent("minecraft:health").defaultValue / 100 * 40)
        player.getComponent("minecraft:health").setCurrentValue(life)
    
        const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (lib.random(-100, 100) / 100), y: player.location.y + (1 + (lib.random(-100, 100) / 100)), z: player.location.z + (lib.random(-100, 100) / 100)})
        display.nameTag = `§a+${parseInt(life) - player.getComponent("minecraft:health").currentValue}`
    
        player.runCommandAsync("particle lian:skills.extra.4")
        
    
    
      })


    }
  


  })


}, lib.convertTick(1))


mc.system.afterEvents.scriptEventReceive.subscribe(event => {

  const id = event.id, player = event.sourceEntity, message = event.message
  if (id === "lian:spawnEntity" && player.typeId === entity.typeId) {

    player.setDynamicProperty("name", entity.name)
    player.setDynamicProperty("class", entity.class)
    const health = lib.random(entity.health[0], entity.health[1])
    player.triggerEvent("1." + health)
    player.getComponent("health").setCurrentValue(health)
    player.triggerEvent("3." + lib.random(entity.damage[0], entity.damage[1]))
    player.triggerEvent("movement." + lib.random(entity.velocity[0], entity.velocity[1]) / 10)
    player.triggerEvent("scale." + lib.random(entity.scale[0], entity.scale[1]) / 10)
    lib.setScore(player, "energy_base", 8000)
    lib.setScore(player, "energy_cur", 8000)
    player.addTag("player")

  }


})