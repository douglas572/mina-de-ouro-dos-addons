import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../lib.js";

// configurations
const entity = {
  
  typeId: "lian:enemy.2.1",
  name: "Dinosaur Curse",
  class: "§cGrade 2",
  health: [2000, 2900],
  scale: [12, 30],
  damage: [8, 16],
  velocity: [3, 5]


}

const powersHit = [{

  name: "power 1", 
  function: function(player, entity) {

    !player.getDynamicProperty("combo") ? player.setDynamicProperty("combo", 0): null
    if (player.getDynamicProperty("combo") === 0) {
  
      player.setDynamicProperty("combo", 1)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(10, 20) / 10, 0.2)
      player.playAnimation("animation.attack.1")
  
  
    } else if (player.getDynamicProperty("combo") === 1) {
  
      player.setDynamicProperty("combo", 0)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(10, 20) / 10, 0.2)
      player.playAnimation("animation.attack.2")
  
  
    }
    
  
  }

}]

// hit event
mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entityDamaged = event.hitEntity; const entityLocation = {x: entityDamaged.location.x, y: entityDamaged.location.y, z: entityDamaged.location.z}
  if (player.typeId === entity.typeId) {

    powersHit[0].function(player, entityDamaged)


  }


})

mc.system.afterEvents.scriptEventReceive.subscribe(event => {

  const id = event.id, player = event.sourceEntity, message = event.message
  if(id === "lian:spawnEntity" && player.typeId === entity.typeId) {

    player.setDynamicProperty("name", entity.name)
    player.setDynamicProperty("class", entity.class)
    const health = lib.random(entity.health[0], entity.health[1])
    player.triggerEvent("1." + health)
    player.getComponent("health").setCurrentValue(health)
    player.triggerEvent("3." + lib.random(entity.damage[0], entity.damage[1]))
    player.triggerEvent("movement." + lib.random(entity.velocity[0], entity.velocity[1]) / 10)
    player.triggerEvent("scale." + lib.random(entity.scale[0], entity.scale[1]) / 10)


  }


})