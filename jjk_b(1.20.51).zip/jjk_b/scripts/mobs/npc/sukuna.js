import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";

// configurations
const entityInfo = {typeId: "lian:mobs.npc.sukuna"}

const powersHit = [{

  name: "power 1", 
  function: function(player, entity) {

    !player.getDynamicProperty("skills.6.1") ? player.setDynamicProperty("skills.6.1", 0): null
    if (player.hasTag("finalCombo")) return
    if (player.getDynamicProperty("skills.6.1") === 0) {
  
      lib.conditionSkillMob(player, 20, 1, (player) => {

        player.setDynamicProperty("skills.6.1", 1)
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "entityAttack"})
        player.playAnimation("animation.player.skills.6.1.1")
        entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
        mc.world.playSound("weapon.1.1", player.location, {volume: 10, pitch: lib.random(8, 12) / 10})


      })
  
  
    } else if (player.getDynamicProperty("skills.6.1") === 1) {
  
      lib.conditionSkillMob(player, 20, 1, (player) => {

        player.setDynamicProperty("skills.6.1", 2)
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "entityAttack"})
        player.playAnimation("animation.player.skills.6.1.2")
        entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
        mc.world.playSound("weapon.1.1", player.location, {volume: 10, pitch: lib.random(12, 18) / 10})


      })
      
  
    } else if (player.getDynamicProperty("skills.6.1") === 2) {
  
      lib.conditionSkillMob(player, 20, 1, (player) => {

        player.setDynamicProperty("skills.6.1", 0)
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 6, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 2.5, {damagingEntity: player, cause: "entityAttack"})
        player.playAnimation("animation.player.skills.6.1.3")
        entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
        mc.world.playSound("weapon.1.1", player.location, {volume: 10, pitch: lib.random(18, 25) / 10})
        player.addTag("finalCombo")


      })
  
  
    }
    
  
  }

},
{

  name: "power 2", 
  function: function(player, entity) {

    lib.conditionSkillMob(player, 0, 1, (player) => {

      entity.runCommandAsync("particle lian:skills.4.1 ^^1^")
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 7, 0.2)
      player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, -1, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "entityAttack"})
      player.playAnimation("animation.player.skills.4.1." + lib.random(1, 3))
      mc.world.playSound("explode", player.location, {pitch: lib.random(8, 15) / 10, volume: 1.0})
  
  
    })
    
  
  }

},
{

  name: "power 3", 
  function: function(player, entity) {

    lib.conditionSkillMob(player, 0, 1, (player) => {

      entity.runCommandAsync("particle lian:skills.4.1 ^^1^")
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 1.3)
      player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, -1, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 4, {damagingEntity: player, cause: "entityAttack"})
      player.playAnimation("animation.player.skills.4.2")
      mc.world.playSound("explode", player.location, {pitch: lib.random(8, 15) / 10, volume: 1.0})


    })
    
  
  }

}]
const powersComb = [
{

  name: "power 2", 
  function: function(player) {

    lib.conditionSkillMob(player, 150, 1, (player) => {

      mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.6.1." + lib.random(1, 1))
      mc.system.runTimeout(() => {
        
        const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
        locate.runCommandAsync("execute at @a[name=id_" + player.getDynamicProperty("id") + "] positioned ^^^0.5 run tp @s ~~~ ~~").then(() => {
    
          const projectile = player.dimension.spawnEntity("lian:skills.6.3", {x: locate.location.x, y: locate.location.y, z: locate.location.z})
          projectile.nameTag = player.nameTag
          projectile.setProperty("lian:pivot_x", player.getRotation().x)
          projectile.setProperty("lian:pivot_y", player.getRotation().y)
          projectile.setProperty("lian:pivot_z", lib.random(90, -90))
          projectile.applyImpulse({x: player.getViewDirection().x * 2, y: player.getViewDirection().y  * 2, z: player.getViewDirection().z * 2})
          projectile.setDynamicProperty("initialDirectionX", player.getViewDirection().x); projectile.setDynamicProperty("initialDirectionZ", player.getViewDirection().z)
          const tick = mc.system.runInterval(() => {
    
            mc.world.playSound("weapon.1.1", projectile.location, {volume: 10, pitch: lib.random(8, 12) / 10})
            mc.world.playSound("explode", projectile.location, {volume: 10, pitch: lib.random(8, 12) / 10})
            projectile.dimension.createExplosion({x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, 3, {breaksBlocks: false, source: player})
            const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: 10, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()})
            const entities = player.dimension.getEntities({location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
            entities.forEach(entity => {
    
              try {
    
                entity.applyKnockback(projectile.getDynamicProperty("initialDirectionX"), projectile.getDynamicProperty("initialDirectionZ"), 10, 0.8)
                entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "contact"})
    
    
              } catch {}
    
    
            })
    
          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {mc.system.clearRun(tick); entity.remove()}, lib.convertTick(3))
          mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
          entity.addTag("finalPress")
    
    
        })
    
    
      }, lib.convertTick(0))


    })
    
  
  } 

},
{

  name: "power 3", 
  function: function(player) {

    lib.conditionSkillMob(player, 400, 1, (player) => {

      player.playAnimation("animation.player.skills.6.4")
      entity.triggerEvent("4.0")
      const entities = player.getEntitiesFromViewDirection({maxDistance: 100})
      if (entities[0]) {
          
        entities.forEach(hit => {
          
          mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
          entity.addTag("finalPress")
          hit.entity.setDynamicProperty("locationOfSkills.6.4", {x: hit.entity.location.x, y: hit.entity.location.y, z: hit.entity.location.z})
          const tick = mc.system.runInterval(() => {
              
            if (hit.entity.typeId === "minecraft:player") {
    
              hit.entity.runCommandAsync("inputpermission set @s movement disabled")
    
    
            } else {
    
              hit.entity.teleport(hit.entity.getDynamicProperty("locationOfSkills.6.4"))
    
    
            }
    
    
          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {mc.system.clearRun(tick); hit.entity.runCommandAsync("inputpermission set @s movement enabled"); hit.entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.1)}, lib.convertTick(1))
         
        
        })
      
      
      }
      mc.system.runTimeout(() => {
        
        entity.triggerEvent("4.400")
        const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
        locate.runCommandAsync("execute at @a[name=id_" + player.getDynamicProperty("id") + "] positioned ^^^ run tp @s ~~~ ~~").then(() => {
    
          const projectile = player.dimension.spawnEntity("lian:skills.6.4", {x: locate.location.x, y: locate.location.y, z: locate.location.z})
          projectile.nameTag = player.nameTag
  
          projectile.setProperty("lian:pivot_x", player.getRotation().x)
          projectile.setProperty("lian:pivot_y", player.getRotation().y)
  
          projectile.applyImpulse({x: player.getViewDirection().x * 3, y: player.getViewDirection().y * 3, z: player.getViewDirection().z * 3})
          projectile.setDynamicProperty("initialDirectionX", player.getViewDirection().x); projectile.setDynamicProperty("initialDirectionZ", player.getViewDirection().z)
          const tick = mc.system.runInterval(() => {
    
            try {projectile.runCommandAsync("particle lian:skills.6.4.1"); projectile.runCommandAsync("particle lian:skills.6.4.2")} catch {}
            projectile.dimension.createExplosion({x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, lib.random(10, 20) / 10, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player}); const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: 5, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()})
            mc.world.playSound("mob.ghast.fireball", {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, {pitch: 1, volume: 10})
    
          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {
            
            const entities = player.dimension.getEntities({location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, maxDistance: 20, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
            entities.forEach(entity => {
    
              const tick = mc.system.runInterval(() => {
    
                entity.runCommandAsync("particle lian:skills.6.4.3")
                entity.runCommandAsync("particle lian:skills.6.4.4")
                entity.runCommandAsync("particle lian:skills.6.4.5")
                entity.runCommandAsync("particle lian:skills.6.4.6")
                entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "fire"})
                // entity.applyKnockback(entity.getViewDirection().x, entity.getViewDirection().z, 0, 1)
    
    
              }, lib.convertTick(0.1))
              mc.system.runTimeout(() => {mc.system.clearRun(tick)}, lib.convertTick(2))
    
    
            })
            mc.system.clearRun(tick); projectile.remove()
    
          
          
          }, lib.convertTick(0.5))
    
    
        })
    
    
      }, lib.convertTick(0.9))


    })


  }

}]
const powersEvent = [{

  name: "power 1", 
  function: function(player) {

    const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], exclueTypes: ["orb", "item"]})
    if (!entities[0]) return
    !player.getDynamicProperty("skills.6.2") ? player.setDynamicProperty("skills.6.2", 0): null
    if (player.getDynamicProperty("skills.6.2") === 0) {
  
      lib.conditionSkillMob(player, 20, 1, (player) => {

        player.setDynamicProperty("skills.6.2", 1)
        mc.system.runTimeout(() => {
    
          mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(10, 17) / 10})
          entities.forEach(entity => {
    
            entity.applyDamage(lib.getScore(player, "str_cur") * 1, {damagingEntity: player, cause: "contact"})
            entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
            entity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
            entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      
          })
    
    
        }, lib.convertTick(0.2))
        player.playAnimation("animation.player.skills.6.2.1")


      })
  
  
    } else if (player.getDynamicProperty("skills.6.2") === 1) {
  
      lib.conditionSkillMob(player, 20, 1, (player) => {

        player.setDynamicProperty("skills.6.2", 2)
        mc.system.runTimeout(() => {
    
          mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(17, 20) / 10})
          entities.forEach(entity => {
    
            entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "contact"})
            entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
            entity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
            entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      
          })
    
    
        }, lib.convertTick(0.2))
        player.playAnimation("animation.player.skills.6.2.2")

        
      })
  
  
    } else if (player.getDynamicProperty("skills.6.2") === 2) {
  
      lib.conditionSkillMob(player, 20, 1, (player) => {

        player.setDynamicProperty("skills.6.2", 3)
        mc.system.runTimeout(() => {
    
          mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(20, 22) / 10})
          entities.forEach(entity => {
    
            entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "contact"})
            entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
            entity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
            entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      
          })
    
    
        }, lib.convertTick(0.2))
        player.playAnimation("animation.player.skills.6.2.3")


      })
  
  
    } else if (player.getDynamicProperty("skills.6.2") === 3) {
  
      lib.conditionSkillMob(player, 20, 1, (player) => {

        player.setDynamicProperty("skills.6.2", 0)
        mc.system.runTimeout(() => {
    
          mc.world.playSound("explode", player.location, {volume: 1.0, pitch: lib.random(8, 10) / 10})
          mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(22, 25) / 10})
          entities.forEach(entity => {
    
            entity.applyDamage(lib.getScore(player, "str_cur") * 2.5, {damagingEntity: player, cause: "contact"})
            entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 12, 0.2)
            entity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
            entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
            entity.runCommandAsync("particle lian:skills.6.2.3 ~~1~")
      
          })
    
    
        }, lib.convertTick(0.2))
        player.playAnimation("animation.player.skills.6.2.4")
        mc.system.runTimeout(() => {player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 2.5, 0.2)}, lib.convertTick(0.3))


      })
  
  
    }
    mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
    entity.addTag("finalPress")
  
  
  }

},
{

  name: "power 2", 
  function: function(player) {

    lib.conditionSkillMob(player, 150, 1, (player) => {

      mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.6.1." + lib.random(1, 1))
      mc.system.runTimeout(() => {
        
        const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
        locate.runCommandAsync("execute at @a[name=id_" + player.getDynamicProperty("id") + "] positioned ^^^0.5 run tp @s ~~~ ~~").then(() => {
    
          const projectile = player.dimension.spawnEntity("lian:skills.6.3", {x: locate.location.x, y: locate.location.y, z: locate.location.z})
          projectile.nameTag = player.nameTag
          projectile.setProperty("lian:pivot_x", player.getRotation().x)
          projectile.setProperty("lian:pivot_y", player.getRotation().y)
          projectile.setProperty("lian:pivot_z", lib.random(90, -90))
          projectile.applyImpulse({x: player.getViewDirection().x * 2, y: player.getViewDirection().y  * 2, z: player.getViewDirection().z * 2})
          projectile.setDynamicProperty("initialDirectionX", player.getViewDirection().x); projectile.setDynamicProperty("initialDirectionZ", player.getViewDirection().z)
          const tick = mc.system.runInterval(() => {
    
            mc.world.playSound("weapon.1.1", projectile.location, {volume: 10, pitch: lib.random(8, 12) / 10})
            mc.world.playSound("explode", projectile.location, {volume: 10, pitch: lib.random(8, 12) / 10})
            projectile.dimension.createExplosion({x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, 3, {breaksBlocks: false, source: player})
            const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: 10, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()})
            const entities = player.dimension.getEntities({location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
            entities.forEach(entity => {
    
              try {
    
                entity.applyKnockback(projectile.getDynamicProperty("initialDirectionX"), projectile.getDynamicProperty("initialDirectionZ"), 10, 0.8)
                entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "contact"})
    
    
              } catch {}
    
    
            })
    
          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {mc.system.clearRun(tick); entity.remove()}, lib.convertTick(3))
          mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
          entity.addTag("finalPress")
    
    
        })
    
    
      }, lib.convertTick(0))


    })
    
  
  } 

},
{

  name: "power 3", 
  function: function(player) {

    lib.conditionSkillMob(player, 400, 1, (player) => {

      player.playAnimation("animation.player.skills.6.4")
      entity.triggerEvent("4.0")
      const entities = player.getEntitiesFromViewDirection({maxDistance: 100})
      if (entities[0]) {
          
        entities.forEach(hit => {
          
          mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
          entity.addTag("finalPress")
          hit.entity.setDynamicProperty("locationOfSkills.6.4", {x: hit.entity.location.x, y: hit.entity.location.y, z: hit.entity.location.z})
          const tick = mc.system.runInterval(() => {
              
            if (hit.entity.typeId === "minecraft:player") {
    
              hit.entity.runCommandAsync("inputpermission set @s movement disabled")
    
    
            } else {
    
              hit.entity.teleport(hit.entity.getDynamicProperty("locationOfSkills.6.4"))
    
    
            }
    
    
          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {mc.system.clearRun(tick); hit.entity.runCommandAsync("inputpermission set @s movement enabled"); hit.entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.1)}, lib.convertTick(1))
         
        
        })
      
      
      }
      mc.system.runTimeout(() => {
        
        entity.triggerEvent("4.400")
        const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
        locate.runCommandAsync("execute at @a[name=id_" + player.getDynamicProperty("id") + "] positioned ^^^ run tp @s ~~~ ~~").then(() => {
    
          const projectile = player.dimension.spawnEntity("lian:skills.6.4", {x: locate.location.x, y: locate.location.y, z: locate.location.z})
          projectile.nameTag = player.nameTag
  
          projectile.setProperty("lian:pivot_x", player.getRotation().x)
          projectile.setProperty("lian:pivot_y", player.getRotation().y)
  
          projectile.applyImpulse({x: player.getViewDirection().x * 3, y: player.getViewDirection().y * 3, z: player.getViewDirection().z * 3})
          projectile.setDynamicProperty("initialDirectionX", player.getViewDirection().x); projectile.setDynamicProperty("initialDirectionZ", player.getViewDirection().z)
          const tick = mc.system.runInterval(() => {
    
            try {projectile.runCommandAsync("particle lian:skills.6.4.1"); projectile.runCommandAsync("particle lian:skills.6.4.2")} catch {}
            projectile.dimension.createExplosion({x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, lib.random(10, 20) / 10, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player}); const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: 5, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()})
            mc.world.playSound("mob.ghast.fireball", {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, {pitch: 1, volume: 10})
    
          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {
            
            const entities = player.dimension.getEntities({location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, maxDistance: 20, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
            entities.forEach(entity => {
    
              const tick = mc.system.runInterval(() => {
    
                entity.runCommandAsync("particle lian:skills.6.4.3")
                entity.runCommandAsync("particle lian:skills.6.4.4")
                entity.runCommandAsync("particle lian:skills.6.4.5")
                entity.runCommandAsync("particle lian:skills.6.4.6")
                entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "fire"})
                // entity.applyKnockback(entity.getViewDirection().x, entity.getViewDirection().z, 0, 1)
    
    
              }, lib.convertTick(0.1))
              mc.system.runTimeout(() => {mc.system.clearRun(tick)}, lib.convertTick(2))
    
    
            })
            mc.system.clearRun(tick); projectile.remove()
    
          
          
          }, lib.convertTick(0.5))
    
    
        })
    
    
      }, lib.convertTick(0.9))


    })


  }

}]
const powersMove = [{

  name: "power 1", 
  function: function(player) {

    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 5, 0.2)
    player.playAnimation("animation.player.skills.dash")
    
  
  } 

},
{

  name: "power 2", 
  function: function(player) {

    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0, 0.7)
    player.playAnimation("animation.player.skills.dash")
    
  
  } 

},
{

  name: "power 3", 
  function: function(player) {

    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 5, 2)
    player.playAnimation("animation.player.skills.dash")
    
  
  } 

}]

// hit event
mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entity = event.hitEntity; const entityLocation = {x: entity.location.x, y: entity.location.y, z: entity.location.z}
  if (player.typeId === entityInfo.typeId && !player.hasTag("finalCombo")) {

    powersHit[lib.random(0, 2)].function(player, entity)
    entity.removeTag("finalPress")


  }


})


// press event
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
  entities.forEach(entity => {
    
    const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
    entities.forEach(entity => {
      
      if (entity.hasTag("target") && entity.hasTag("finalCombo") && !entity.hasTag("finalPress")) {

        powersComb[lib.random(0, 2)].function(entity)
    
    
      }
  
  
    })
  


  })


}, lib.convertTick(0.1))

// random event
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
  entities.forEach(entity => {
    
    const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
    entities.forEach(entity => {
      
      if (entity.hasTag("target") && !entity.hasTag("finalPress")) {

        powersEvent[lib.random(0, 3)].function(entity)
    
    
      }
  
  
    })
  


  })


}, lib.convertTick(7))

// move event
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
  entities.forEach(entity => {
    
    const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
    entities.forEach(entity => {
      
      if (entity.hasTag("target") && !entity.hasTag("finalPress")) {

        powersMove[lib.random(0, 2)].function(entity)
    
    
      }
  
  
    })
  


  })


}, lib.convertTick(12))

// reverse event
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
  entities.forEach(player => {
    
    if (player.getComponent("minecraft:health").currentValue < 2500) {

      lib.conditionSkillMob(player, 500, 1, function() {
      
        const life = player.getComponent("minecraft:health").currentValue + parseInt(player.getComponent("minecraft:health").defaultValue / 100 * 40)
        player.getComponent("minecraft:health").setCurrentValue(life)
    
        const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (lib.random(-100, 100) / 100), y: player.location.y + (1 + (lib.random(-100, 100) / 100)), z: player.location.z + (lib.random(-100, 100) / 100)})
        display.nameTag = `§a+${parseInt(life) - player.getComponent("minecraft:health").currentValue}`
    
        player.runCommandAsync("particle lian:skills.extra.4")
        
    
    
      })


    }
  


  })


}, lib.convertTick(1))

// repeat
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
  entities.forEach(entity => {
    
    !entity.getDynamicProperty("id") ? (entity.setDynamicProperty("id", lib.random(0, 9999)), entity.triggerEvent("4.400"), lib.setScore(entity, "energy_cur", 5000), entity.triggerEvent("1.5000"), entity.getComponent("minecraft:health").setCurrentValue(5000)): null
    entity.nameTag = `id_${entity.getDynamicProperty("id")}`
    lib.setScore(entity, "str_cur", 150)
    lib.setScore(entity, "energy_base", 5000)
    entity.setDynamicProperty("mastery", 99999)
    entity.addTag("player")
    entity.triggerEvent("2.450")
    entity.triggerEvent("3.1")
  


  })


}, lib.convertTick(0.1))

// domain event
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
  entities.forEach(entity => {
    
    if (entity.hasTag("target") && !entity.hasTag("ownerExpansion") && lib.getScore(entity, "energy_cur") >= (lib.getScore(entity, "energy_base") / 100 * 30)) {

      entity.triggerEvent("4.0")
      expansion(entity)
  
  
    }
  


  })


}, lib.convertTick(20))

function expansion(player) {

  player.setDynamicProperty("domain", 1)
  player.playAnimation("animation.player.skills.6.5"); mc.world.playSound("skills.6.5.1", player.location, {pitch: 1, volume: 10.0})
  player.addTag("ownerExpansion")
  const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, type: "minecraft:player"})
  players.forEach(a => {

    a.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.1)
    a.runCommandAsync("tp ~~~ ~ 0")
    mc.system.runTimeout(() => {a.runCommandAsync("execute as @s at @e[name=id_" + player.getDynamicProperty("id") + "] run camera @s set minecraft:free ease 1 linear pos ~~1.8~2 facing ~~1.5~")}, lib.convertTick(0.5))
    lib.subtitle(a, "Domain expansion...")
    a.runCommandAsync("inputpermission set @s camera disabled")
    a.runCommandAsync("inputpermission set @s movement disabled")
    a.addTag("inAttack")
    a.setDynamicProperty("scene", 1)
    a.runCommandAsync("fog @s push lian:sukuna domainFog")

  
  })
  mc.system.runTimeout(() => {mc.world.playSound("skills.6.5.2", player.location, {pitch: 1, volume: 10.0}); player.runCommandAsync("playsound skills.6.5.3 @a[r=100] ~~~-4 100")}, lib.convertTick(3))
  mc.system.runTimeout(() => {
              
    const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, type: "minecraft:player"})
    players.forEach(a => {a.runCommandAsync("camera @s fade time 0.1 0.6 1 color 0 0 0")})
        
        
  }, lib.convertTick(6))
  mc.system.runTimeout(() => {
              
    const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, type: "minecraft:player"})
    players.forEach(a => {a.runCommandAsync("execute as @s at @e[name=id_" + player.getDynamicProperty("id") + "] run camera @s set minecraft:free ease 10 linear pos ~~8~10 facing ~~1.5~")})
    const visual = player.dimension.spawnEntity("lian:skills.6.5", {x: player.location.x, y: player.location.y, z: player.location.z})
    visual.runCommandAsync("execute at @e[name=id_" + player.getDynamicProperty("id") + "] run tp ~~4^~7 ~~")
    mc.system.runTimeout(() => {visual.playAnimation("animation.2")}, lib.convertTick(0.1))
    mc.system.runTimeout(() => {

      visual.runCommandAsync("particle lian:skills.6.5.1 ~~~")
      visual.runCommandAsync("particle lian:skills.6.5.2 ~~1~")
      visual.runCommandAsync("particle lian:skills.6.5.3 ~~~")
      

    }, lib.convertTick(0.5))
        
        
  }, lib.convertTick(6.5))
  mc.system.runTimeout(() => {

    mc.system.runTimeout(() => {player.removeTag("finalCombo")}, lib.convertTick(1))
    player.addTag("finalPress")
    player.triggerEvent("4.400")
    const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, type: "minecraft:player"})
    players.forEach(a => {
  
      a.runCommandAsync("camera @s clear")
      a.runCommandAsync("inputpermission set @s camera enabled")
      a.runCommandAsync("inputpermission set @s movement enabled")
      a.removeTag("inAttack")
      a.setDynamicProperty("scene", 0)
      player.setDynamicProperty("domainIs", 1)
  
    
    })
        
        
  }, lib.convertTick(15))


}
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
  entities.forEach(player => {

    if (player.hasTag("ownerExpansion") && lib.getScore(player, "energy_cur") >= (lib.getScore(player, "energy_base") / 100 * 1)) {lib.setScore(player, "energy_cur", lib.clamp(lib.getScore(player, "energy_cur") - Math.round(lib.getScore(player, "energy_base") / 100 * 1), 0, lib.getScore(player, "energy_base")))} else {lib.setScore(player, "energy_cur", lib.clamp(lib.getScore(player, "energy_cur") + Math.round(lib.getScore(player, "energy_base") / 100 * 0.5), 0, lib.getScore(player, "energy_base")))}
  

  })



}, lib.convertTick(1))
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
  entities.forEach(player => {

      const visuals = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, type: "lian:skills.6.5"})
      if (visuals[0] && player.hasTag("ownerExpansion")) {
    
        if (lib.getScore(player, "energy_cur") >= (lib.getScore(player, "energy_base") / 100 * 1)) {
        
          visuals[0].runCommandAsync("particle lian:skills.6.5.4")
          visuals[0].runCommandAsync("particle lian:skills.6.5.5")
          visuals[0].runCommandAsync("particle lian:skills.6.5.6")
          visuals[0].runCommandAsync("particle lian:skills.6.5.7")
          visuals[0].runCommandAsync("particle lian:skills.6.5.8")
          visuals[0].runCommandAsync("particle lian:skills.6.5.9")
          const entities = player.dimension.getEntities({location: {x: visuals[0].location.x, y: visuals[0].location.y, z: visuals[0].location.z}, maxDistance: 50, minDistance: 0, excludeTypes: ["orb", "item"], excludeFamilies: ["not", "skill"], excludeNames: [player.nameTag]})
          entities.forEach(entity => {
            
            if (!entity.getDynamicProperty("simpleDomain")) {
    
              entity.addTag("remove_knockback")
              entity.runCommandAsync("camerashake add @s 0.05 1 positional")
              entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "contact"})
    
    
            }
          
          
          })
          randomExplode(player, visuals[0])
          randomExplode(player, visuals[0])
          randomExplode(player, visuals[0])
          player.setDynamicProperty("multiplier", 2)
    
    
        } else {
  
          player.setDynamicProperty("domain", 0)
          player.runCommandAsync("stopsound @a[r=100] skills.6.5.3")
          const visuals = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, type: "lian:skills.6.5"})
          visuals.forEach(visual => {
    
            visual.playAnimation("animation.3")
            mc.system.runTimeout(() => {visual.remove()}, lib.convertTick(2))
    
    
          })
          const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
          entities.forEach(entity => {
    
            entity.removeTag("ownerExpansion")
            entity.typeId === "minecraft:player" ? (entity.runCommandAsync("fog @s remove domainFog"), entity.removeTag("remove_knockback")): null
      
      
          })
          player.setDynamicProperty("domainIs", 0); player.setDynamicProperty("domainTime", 0)
          player.setDynamicProperty("multiplier", 1)
        
  
      }
      
      
      }
  

  })


}, lib.convertTick(0.1))
function randomExplode(player, entity) {

  try {

    let locX = lib.random(-50, 50)
    let locZ = lib.random(-50, 50)
    let loc = {x: entity.location.x + locX, y: entity.location.y, z: entity.location.z + locZ}
    let verify = player.dimension.getEntities({location: loc, maxDistance: 10, type: "lian:skills.6.5"})
    for (let i = 0; verify[0]; i++) {
      
      locX = lib.random(-50, 50)
      locZ = lib.random(-50, 50)
      loc = {x: entity.location.x + locX, y: entity.location.y, z: entity.location.z + locZ}
      verify = player.dimension.getEntities({location: loc, maxDistance: 10, type: "lian:skills.6.5"})
  
  
    }
    player.dimension.createExplosion(loc, lib.random(1, 20) / 10, {breaksBlocks: false, source: player})
    const items = player.dimension.getEntities({type: "minecraft:item", maxDistance: 20, minDistance: 0, location: loc}); items.forEach(item => {item.remove()})
    mc.world.playSound("weapon.1.1", loc, {volume: 10, pitch: lib.random(5, 25) / 10})


  } catch {}


}
mc.world.afterEvents.projectileHitEntity.subscribe(data => {

  const projectile = data.projectile, target = data.getEntityHit().entity
  if (projectile.typeId === "lian:skills.6.3") {

    const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
    entities.forEach(player => {

      if (player.nameTag === projectile.nameTag) {

        if (projectile.nameTag !== target.nameTag) {

          mc.world.playSound("explode", location, {volume: 10, pitch: lib.random(8, 10) / 10})
          projectile.remove()


        }


      }


    })


  }



})
mc.world.afterEvents.projectileHitEntity.subscribe(data => {

  const projectile = data.projectile, target = data.getEntityHit().entity
  if (projectile.typeId === "lian:skills.6.3") {

    const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
    entities.forEach(player => {

      if (player.nameTag === projectile.nameTag) {

        if (projectile.nameTag !== target.nameTag) {

          mc.world.playSound("explode", location, {volume: 10, pitch: lib.random(8, 10) / 10})
          projectile.remove()
          

        }


      }


    })


  }



})
mc.world.afterEvents.projectileHitEntity.subscribe(data => {

  const projectile = data.projectile, target = data.getEntityHit().entity
  if (projectile.typeId === "lian:skills.6.4") {

    const entities = mc.world.getDimension("the_end").getEntities({type: "lian:mobs.npc.sukuna"})
    entities.forEach(player => {

      if (player.nameTag === projectile.nameTag) {

        if (projectile.nameTag !== target.nameTag) {

          projectile.remove()
          const tick = mc.system.runInterval(() => {

            target.runCommandAsync("particle lian:skills.6.4.3")
            target.runCommandAsync("particle lian:skills.6.4.4")
            target.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "fire"})
            target.applyKnockback(target.getViewDirection().x, target.getViewDirection().z, 0, 1)


          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {mc.system.clearRun(tick)}, lib.convertTick(2))

        }


      }


    })


  }



})