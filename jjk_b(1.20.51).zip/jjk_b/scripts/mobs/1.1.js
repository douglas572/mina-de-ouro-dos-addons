import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../lib.js";

// configurations
const entity = {
  
  typeId: "lian:enemy.1.1",
  name: "Yoga Yeti Curse",
  class: "§cGrade 1",
  health: [1100, 1500],
  scale: [1, 15],
  damage: [8, 16],
  velocity: [0, 0]


}

mc.system.afterEvents.scriptEventReceive.subscribe(event => {

  const id = event.id, player = event.sourceEntity, message = event.message
  if(id === "lian:spawnEntity" && player.typeId === entity.typeId) {

    player.setDynamicProperty("name", entity.name)
    player.setDynamicProperty("class", entity.class)
    const health = lib.random(entity.health[0], entity.health[1])
    player.triggerEvent("1." + health)
    player.getComponent("health").setCurrentValue(health)
    player.triggerEvent("3." + lib.random(entity.damage[0], entity.damage[1]))
    player.triggerEvent("movement." + lib.random(entity.velocity[0], entity.velocity[1]) / 10)
    player.triggerEvent("scale." + lib.random(entity.scale[0], entity.scale[1]) / 10)


  }


})