import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../lib.js";

// configurations
const entity = {
  
  typeId: "lian:enemy.0.3",
  name: "Insect Curse",
  class: "§cGrade Especial",
  health: [3000, 3000],
  scale: [11, 13],
  damage: [80, 120],
  velocity: [4, 5]


}
const powersHit = [{

  name: "power 1", 
  function: function(player, damagedEntity) {

    !player.getDynamicProperty("combo") ? player.setDynamicProperty("combo", 0): null
    if (player.getDynamicProperty("combo") === 0) {
  
      player.setDynamicProperty("combo", 1)
      damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(10, 20) / 10, 0.2)
      player.playAnimation("animation.attack.1")
  
  
    } else if (player.getDynamicProperty("combo") === 1) {
  
      player.setDynamicProperty("combo", 2)
      damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(10, 20) / 10, 0.2)
      player.playAnimation("animation.attack.2")
  
  
    } else if (player.getDynamicProperty("combo") === 2) {
  
      player.setDynamicProperty("combo", 0)

      mc.world.playSound("explode", player.location, {volume: 1.0, pitch: lib.random(8, 12) / 10})
      damagedEntity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, lib.random(100, 130) / 10, 0.2)
      damagedEntity.runCommandAsync("particle lian:explosion")
      mc.system.runTimeout(() => {player.teleport(lookDirection(damagedEntity, -2), {facingLocation: damagedEntity.location})}, lib.convertTick(0.8))
      damagedEntity.applyDamage(entity.damage[1] * 1.5, {damagingEntity: player, cause: "contact"})


      player.playAnimation("animation.attack.1")
  
  
    }
    
  
  }

}]

function lookDirection(player, distance) {

  return mc.Vector.add(player.getHeadLocation(), mc.Vector.multiply(player.getViewDirection(), distance))


}
// hit event
mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entityDamaged = event.hitEntity; const entityLocation = {x: entityDamaged.location.x, y: entityDamaged.location.y, z: entityDamaged.location.z}
  if (player.typeId === entity.typeId) {

    powersHit[0].function(player, entityDamaged)


  }


})


// reverse event
mc.system.runInterval(() => {

  const entities = mc.world.getDimension("overworld").getEntities({type: entity.typeId})
  entities.forEach(player => {
    
    if (player.getComponent("minecraft:health").currentValue < 800) {

      lib.conditionSkillMob(player, 500, 1, function() {
      
        const life = player.getComponent("minecraft:health").currentValue + parseInt(player.getComponent("minecraft:health").defaultValue / 100 * 40)
        player.getComponent("minecraft:health").setCurrentValue(life)
    
        const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (lib.random(-100, 100) / 100), y: player.location.y + (1 + (lib.random(-100, 100) / 100)), z: player.location.z + (lib.random(-100, 100) / 100)})
        display.nameTag = `§a+${parseInt(life) - player.getComponent("minecraft:health").currentValue}`
    
        player.runCommandAsync("particle lian:skills.extra.4")
        
    
    
      })


    }
  


  })


}, lib.convertTick(1))


mc.system.afterEvents.scriptEventReceive.subscribe(event => {

  const id = event.id, player = event.sourceEntity, message = event.message
  if (id === "lian:spawnEntity" && player.typeId === entity.typeId) {

    player.setDynamicProperty("name", entity.name)
    player.setDynamicProperty("class", entity.class)
    const health = lib.random(entity.health[0], entity.health[1])
    player.triggerEvent("1." + health)
    player.getComponent("health").setCurrentValue(health)
    player.triggerEvent("3." + lib.random(entity.damage[0], entity.damage[1]))
    player.triggerEvent("movement." + lib.random(entity.velocity[0], entity.velocity[1]) / 10)
    player.triggerEvent("scale." + lib.random(entity.scale[0], entity.scale[1]) / 10)
    lib.setScore(player, "energy_base", 1000)
    lib.setScore(player, "energy_cur", 1000)
    player.addTag("player")

  }


})