import * as mc from "@minecraft/server";
import * as lib from "./lib.js";

mc.system.runInterval(() => {

  for (const player of mc.world.getPlayers()) {

    player.getDynamicProperty("skill") === 4 ? lib.setScore(player, "energy_cur", 0): null
    if (player.getDynamicProperty("skill") !== 4) {
  
      lib.setScore(player, "energy_cur", lib.clamp(lib.getScore(player, 'energy_cur') + Math.round(lib.getScore(player, "energy_base") / 100 * 1), 0, lib.getScore(player, 'energy_base')))
  
  
    }


  }


}, lib.convertTick(1))
lib.tick(async function(player) {

  !player.getDynamicProperty("grade") ? player.setDynamicProperty("grade", 5): null
  const propertys = player.getDynamicPropertyIds()
  propertys.forEach(id => {

    if (id.startsWith("time.")) {

      player.getDynamicProperty(id) > 0 ? player.setDynamicProperty(id, player.getDynamicProperty(id) + 1): null


    }
    const nameOfProperty = id.replace("time.", "")



  })

  !player.getDynamicProperty("multiplier") ? player.setDynamicProperty("multiplier", 1): null
  player.triggerEvent("1." + (player.getDynamicProperty("skill") !== 4 ? lib.clamp(lib.getScore(player, "hp_cur") * player.getDynamicProperty("multiplier"), 0, 5000): lib.clamp(lib.getScore(player, "hp_cur") * 2, 0, 5000)))
  player.triggerEvent("2." + (player.hasTag("invulnerable") || player.hasTag("inAttack") || player.hasTag("invulnerableStructure") ? 1000: player.getDynamicProperty("skill") !== 4 ? lib.clamp(lib.getScore(player, "res_cur") * player.getDynamicProperty("multiplier"), 0, 1000): lib.clamp(lib.getScore(player, "res_cur") * 2, 0, 1000)))
  player.triggerEvent(player.hasTag("invulnerable") || player.hasTag("inAttack") || player.hasTag("remove_knockback") || player.hasTag("invulnerableStructure") ? "remove_knockback": "add_knockback")
  player.triggerEvent("3.1")
  player.addEffect('jump_boost', 100, {amplifier: 2, showParticles: false})
  if (player.getDynamicProperty("stopMovement") === false || !player.getDynamicProperty("stopMovement")) {
    
    if (player.isSprinting) {

      player.triggerEvent("4." + (player.getDynamicProperty("skill") !== 4 ? lib.clamp(lib.getScore(player, "mvm_cur") * player.getDynamicProperty("multiplier"), 0, 1000): lib.clamp(lib.getScore(player, "mvm_cur") * 2, 0, 1000)))


    } else {

      player.triggerEvent("4.1")
      player.addEffect('jump_boost', 5, {amplifier: 0, showParticles: false})


    }


  } else {

    player.triggerEvent("4.0")


  }
  if (lib.getScore(player, "exp") >= lib.getScore(player, "exp_base")) {

    player.sendMessage(`§aLevel Up!`)
    player.playSound("random.levelup")
    lib.setScore(player, "exp", lib.getScore(player, "exp") - lib.getScore(player, "exp_base"))
    lib.setScore(player, "exp_base", lib.getScore(player, "exp_base") + 85)
    lib.setScore(player, "level", lib.getScore(player, "level") + 1)
    up(player, lib.random(300, 655), lib.random(0, 200), lib.random(3, 5), lib.random(20, 30))



  }
  

}, lib.convertTick(3))
function up(player, dinheiro, exp, yp, energy) {

  player.sendMessage(`§fVocê recebeu §a${dinheiro} §rde Yen`)
  lib.setScore(player, `yen`, lib.getScore(player, "yen") + dinheiro)
  player.sendMessage(`§fVocê recebeu §a${energy} §rde Energy base`)
  lib.setScore(player, `energy`, lib.getScore(player, "energy_base") + energy)
  player.sendMessage(`§fVocê recebeu §a${yp} §rde Yp`)
  lib.setScore(player, `yp`, yp)


}
const hurt = mc.world.afterEvents.entityHurt.subscribe((event) => {

  const display = event.hurtEntity.dimension.spawnEntity("lian:text", {x: event.hurtEntity.location.x, y: event.hurtEntity.location.y, z: event.hurtEntity.location.z})
  display.runCommandAsync(`tp ^${lib.random(-1, 1)}^${lib.random(-1, 1)}^${lib.random(-1, 1)}`).then(() => {display.nameTag = `§c-${(event.damage)}`})
  

  event.hurtEntity.runCommandAsync("particle lian:skills.blood ~~~")
  lib.random(1, 2) === 2 ? event.hurtEntity.runCommandAsync("particle lian:skills.blood.2 ~~-0.4~"): null


})
mc.world.afterEvents.entityHitEntity.subscribe((event) => {

  event.hitEntity.applyKnockback(event.damagingEntity.getViewDirection().x, event.damagingEntity.getViewDirection().z, lib.getScore(event.damagingEntity, "knc_cur") / 50, lib.getScore(event.damagingEntity, "knc_cur") / 100)


})
mc.world.afterEvents.entityDie.subscribe(data => {

  const ids = [{

    id: "minecraft:player", command: function(player, entity) {

      try {

        entity.runCommandAsync("fog @s remove domainFog")
        if (player.getDynamicProperty("domainIs") === 1) {player.setDynamicProperty("domainIs", 0); player.setDynamicProperty("domain", 0)

        hitUi(player, "§cYour domain is over!"); player.playSound("note.bass")
        delayItem(player, skills[player.getDynamicProperty("skill")].itemsId[4], 8, 40)
        player.removeTag("ownerExpansion")
        if (player.hasTag("isInExpansion")) {
    
          player.runCommandAsync("execute positioned " + player.getDynamicProperty("locAfterDomainX") + " 200 " + player.getDynamicProperty("locAfterDomainZ") + " run structure load domain.erase ~-32 ~-32 ~-32 0_degrees none layer_by_layer 3 false").then(() => {
    
            const entities = player.dimension.getEntities({location: {x: player.getDynamicProperty("locAfterDomainX"), y: player.location.y, z: player.getDynamicProperty("locAfterDomainZ")}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
            entities.forEach(entity => {
      
              entity.getDynamicProperty("locAfterDomainY") ? entity.teleport({x: entity.getDynamicProperty("locAfterDomainX"), y: entity.getDynamicProperty("locAfterDomainY"), z: entity.getDynamicProperty("locAfterDomainZ")}): null
              entity.typeId === "minecraft:player" ? (entity.runCommandAsync("camera @s fade time 0 0 1 color 0 0 0"), entity.runCommandAsync("fog @s remove domainFog"), entity.addTag("breacksBlock")): null
              entity.removeTag("isInExpansion")
      
      
            })
            player.setDynamicProperty("domainIs", 0)
      
      
          })
    
    
        } else {
    
          player.runCommandAsync("stopsound @s skills.6.5.3")
          const visuals = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, type: "lian:skills.6.5"})
          visuals.forEach(visual => {
      
            visual.playAnimation("animation.3")
            mc.system.runTimeout(() => {visual.remove()}, convertTick(2))
      
      
          })
          const entities = player.dimension.getEntities({location: {x: visuals[0].location.x, y: player.location.y, z: visuals[0].location.z}, maxDistance: 100, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
          entities.forEach(entity => {
    
            entity.typeId === "minecraft:player" ? (entity.runCommandAsync("fog @s remove domainFog"), entity.removeTag("remove_knockback")): null
            entity.removeTag("isInExpansion")
    
    
          })
          player.setDynamicProperty("domainIs", 0)
    
    
        }
    
    
        }


      } catch {}
      player.setDynamicProperty("canTeleport", 0)
      entity.hasTag("secondHotbar") ? (lib.close(entity), entity.setDynamicProperty("skill", 0)): null
      entity.runCommandAsync("fog @s remove structureFog")
      entity.runCommandAsync("music stop")
      entity.runCommandAsync("gamemode survival")
      entity.addTag("breacksBlock")
      entity.addTag("pvp")
      for (let i = 0; i < 13; i++) {

        entity.hasTag("mission:" + i + ".cur") ? (entity.removeTag("mission:" + i + ".cur"), entity.setDynamicProperty("mission.have", false)): null


      }
      


    }

  },
  {

    id: "lian:enemy.0.1", command: function(player, entity) {

      if (player.hasTag("mission:1.cur")) {

        player.removeTag("mission:1.cur"); player.addTag("mission:1.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        player.setDynamicProperty("grade", 4)


      } else {

        player.sendMessage("§eYou killed a grade 4 curse!");
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 30); player.sendMessage("Received §a" + 30 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 30); player.sendMessage("Received §a" + 30 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.4.1", command: function(player, entity) {

      if (player.hasTag("mission:2.cur") && player.getDynamicProperty("mission.condition") >= 14) {

        player.removeTag("mission:2.cur"); player.addTag("mission:2.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 100); player.sendMessage("Received §a" + 50 + "§r yen")


      } else if (player.hasTag("mission:2.cur") && player.getDynamicProperty("mission.condition") < 14) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§715 §rcurses Grade 4."); player.sendMessage("§eYou killed a grade 4 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 4 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 30); player.sendMessage("Received §a" + 30 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 30); player.sendMessage("Received §a" + 30 + "§r exp")


      }
      if (player.hasTag("mission:3.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:3.cur"); player.addTag("mission:3.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 250); player.sendMessage("Received §a" + 250 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 250); player.sendMessage("Received §a" + 250 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 200); player.sendMessage("Received §a" + 200 + "§r yen")


      } else if (player.hasTag("mission:3.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 4."); player.sendMessage("§eYou killed a grade 4 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 4 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 30); player.sendMessage("Received §a" + 30 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 30); player.sendMessage("Received §a" + 30 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.4.2", command: function(player, entity) {

      if (player.hasTag("mission:2.cur") && player.getDynamicProperty("mission.condition") >= 14) {

        player.removeTag("mission:2.cur"); player.addTag("mission:2.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 100); player.sendMessage("Received §a" + 50 + "§r yen")


      } else if (player.hasTag("mission:2.cur") && player.getDynamicProperty("mission.condition") < 14) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§715 §rcurses Grade 4."); player.sendMessage("§eYou killed a grade 4 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 4 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 30); player.sendMessage("Received §a" + 30 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 30); player.sendMessage("Received §a" + 30 + "§r exp")


      }
      if (player.hasTag("mission:3.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:3.cur"); player.addTag("mission:3.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 250); player.sendMessage("Received §a" + 250 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 250); player.sendMessage("Received §a" + 250 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 200); player.sendMessage("Received §a" + 200 + "§r yen")


      } else if (player.hasTag("mission:3.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 4."); player.sendMessage("§eYou killed a grade 4 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 4 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 30); player.sendMessage("Received §a" + 30 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 30); player.sendMessage("Received §a" + 30 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.4.3", command: function(player, entity) {

      if (player.hasTag("mission:2.cur") && player.getDynamicProperty("mission.condition") >= 14) {

        player.removeTag("mission:2.cur"); player.addTag("mission:2.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 100); player.sendMessage("Received §a" + 50 + "§r yen")


      } else if (player.hasTag("mission:2.cur") && player.getDynamicProperty("mission.condition") < 14) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§715 §rcurses Grade 4."); player.sendMessage("§eYou killed a grade 4 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 4 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 30); player.sendMessage("Received §a" + 30 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 30); player.sendMessage("Received §a" + 30 + "§r exp")


      }
      if (player.hasTag("mission:3.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:3.cur"); player.addTag("mission:3.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 250); player.sendMessage("Received §a" + 250 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 250); player.sendMessage("Received §a" + 250 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 200); player.sendMessage("Received §a" + 200 + "§r yen")


      } else if (player.hasTag("mission:3.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 4."); player.sendMessage("§eYou killed a grade 4 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 4 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 30); player.sendMessage("Received §a" + 30 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 30); player.sendMessage("Received §a" + 30 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.0.2", command: function(player, entity) {

      if (player.hasTag("mission:4.cur")) {

        player.removeTag("mission:4.cur"); player.addTag("mission:4.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        player.setDynamicProperty("grade", 3)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 50); player.sendMessage("Received §a" + 50 + "§r yen")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.2.1", command: function(player, entity) {

      if (player.hasTag("mission:7.cur")) {

        player.removeTag("mission:7.cur"); player.addTag("mission:7.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        player.setDynamicProperty("grade", 2)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 50); player.sendMessage("Received §a" + 50 + "§r yen")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.0.3", command: function(player, entity) {

      if (player.hasTag("mission:10.cur")) {

        player.removeTag("mission:10.cur"); player.addTag("mission:10.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        player.setDynamicProperty("grade", 1)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 1000); player.sendMessage("Received §a" + 1000 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 1000); player.sendMessage("Received §a" + 1000 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 5000); player.sendMessage("Received §a" + 5000 + "§r yen")
        player.runCommandAsync("give @s lian:item.1 5")


      } else {

        player.sendMessage("§eYou killed a especial curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }


    }

  },
  {

    id: "lian:mobs.npc.sukuna", command: function(player, entity) {

      if (player.hasTag("mission:13.cur")) {

        player.removeTag("mission:13.cur"); player.addTag("mission:13.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        player.setDynamicProperty("grade", 6)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100000); player.sendMessage("Received §a" + 100000 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100000); player.sendMessage("Received §a" + 100000 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 100000); player.sendMessage("Received §a" + 100000 + "§r yen")
        player.runCommandAsync("give @s lian:item.1 20")


      } else {

        player.sendMessage("§eYou killed a especial curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.3.1", command: function(player, entity) {

      if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:5.cur"); player.addTag("mission:5.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 300); player.sendMessage("Received §a" + 300 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 300); player.sendMessage("Received §a" + 300 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 300); player.sendMessage("Received §a" + 300 + "§r yen")


      } else if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }
      if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:6.cur"); player.addTag("mission:6.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 450); player.sendMessage("Received §a" + 450 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 450); player.sendMessage("Received §a" + 450 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 500); player.sendMessage("Received §a" + 500 + "§r yen")


      } else if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.3.2", command: function(player, entity) {

      if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:5.cur"); player.addTag("mission:5.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 300); player.sendMessage("Received §a" + 300 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 300); player.sendMessage("Received §a" + 300 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 300); player.sendMessage("Received §a" + 300 + "§r yen")


      } else if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }
      if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:6.cur"); player.addTag("mission:6.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 450); player.sendMessage("Received §a" + 450 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 450); player.sendMessage("Received §a" + 450 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 500); player.sendMessage("Received §a" + 500 + "§r yen")


      } else if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.3.3", command: function(player, entity) {

      if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:5.cur"); player.addTag("mission:5.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 300); player.sendMessage("Received §a" + 300 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 300); player.sendMessage("Received §a" + 300 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 300); player.sendMessage("Received §a" + 300 + "§r yen")


      } else if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }
      if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:6.cur"); player.addTag("mission:6.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 450); player.sendMessage("Received §a" + 450 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 450); player.sendMessage("Received §a" + 450 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 500); player.sendMessage("Received §a" + 500 + "§r yen")


      } else if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.3.4", command: function(player, entity) {

      if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:5.cur"); player.addTag("mission:5.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 300); player.sendMessage("Received §a" + 300 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 300); player.sendMessage("Received §a" + 300 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 300); player.sendMessage("Received §a" + 300 + "§r yen")


      } else if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }
      if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:6.cur"); player.addTag("mission:6.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 450); player.sendMessage("Received §a" + 450 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 450); player.sendMessage("Received §a" + 450 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 500); player.sendMessage("Received §a" + 500 + "§r yen")


      } else if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.3.5", command: function(player, entity) {

      if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:5.cur"); player.addTag("mission:5.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 300); player.sendMessage("Received §a" + 300 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 300); player.sendMessage("Received §a" + 300 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 300); player.sendMessage("Received §a" + 300 + "§r yen")


      } else if (player.hasTag("mission:5.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }
      if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:6.cur"); player.addTag("mission:6.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 450); player.sendMessage("Received §a" + 450 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 450); player.sendMessage("Received §a" + 450 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 500); player.sendMessage("Received §a" + 500 + "§r yen")


      } else if (player.hasTag("mission:6.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 3."); player.sendMessage("§eYou killed a grade 3 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 3 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 50); player.sendMessage("Received §a" + 50 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 50); player.sendMessage("Received §a" + 50 + "§r exp")


      }


    }

  },
  {

    id: "jujutsu:especial_2", command: function(player, entity) {

      if (player.hasTag("mission:7.cur")) {

        player.removeTag("mission:7.cur"); player.addTag("mission:7.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        player.setDynamicProperty("grade", 2); player.runCommandAsync("give @s jujutsu:sukuna_finger")


      } else {

        player.sendMessage("§eYou killed a grade especial curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 200); player.sendMessage("Received §a" + 200 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 200); player.sendMessage("Received §a" + 200 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.2.1", command: function(player, entity) {

      if (player.hasTag("mission:8.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:8.cur"); player.addTag("mission:8.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 700); player.sendMessage("Received §a" + 700 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 700); player.sendMessage("Received §a" + 700 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 700); player.sendMessage("Received §a" + 700 + "§r yen")


      } else if (player.hasTag("mission:8.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 2."); player.sendMessage("§eYou killed a grade 2 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }
      if (player.hasTag("mission:9.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:9.cur"); player.addTag("mission:9.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 850); player.sendMessage("Received §a" + 850 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 850); player.sendMessage("Received §a" + 850 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 850); player.sendMessage("Received §a" + 850 + "§r yen")


      } else if (player.hasTag("mission:9.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 2."); player.sendMessage("§eYou killed a grade 2 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.2.2", command: function(player, entity) {

      if (player.hasTag("mission:8.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:8.cur"); player.addTag("mission:8.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 700); player.sendMessage("Received §a" + 700 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 700); player.sendMessage("Received §a" + 700 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 700); player.sendMessage("Received §a" + 700 + "§r yen")


      } else if (player.hasTag("mission:8.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 2."); player.sendMessage("§eYou killed a grade 2 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }
      if (player.hasTag("mission:9.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:9.cur"); player.addTag("mission:9.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 850); player.sendMessage("Received §a" + 850 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 850); player.sendMessage("Received §a" + 850 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 850); player.sendMessage("Received §a" + 850 + "§r yen")


      } else if (player.hasTag("mission:9.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 2."); player.sendMessage("§eYou killed a grade 2 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.2.3", command: function(player, entity) {

      if (player.hasTag("mission:8.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:8.cur"); player.addTag("mission:8.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 700); player.sendMessage("Received §a" + 700 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 700); player.sendMessage("Received §a" + 700 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 700); player.sendMessage("Received §a" + 700 + "§r yen")


      } else if (player.hasTag("mission:8.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 2."); player.sendMessage("§eYou killed a grade 2 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }
      if (player.hasTag("mission:9.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:9.cur"); player.addTag("mission:9.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 850); player.sendMessage("Received §a" + 850 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 850); player.sendMessage("Received §a" + 850 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 850); player.sendMessage("Received §a" + 850 + "§r yen")


      } else if (player.hasTag("mission:9.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 2."); player.sendMessage("§eYou killed a grade 2 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.2.4", command: function(player, entity) {

      if (player.hasTag("mission:8.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:8.cur"); player.addTag("mission:8.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 700); player.sendMessage("Received §a" + 700 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 700); player.sendMessage("Received §a" + 700 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 700); player.sendMessage("Received §a" + 700 + "§r yen")


      } else if (player.hasTag("mission:8.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 2."); player.sendMessage("§eYou killed a grade 2 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }
      if (player.hasTag("mission:9.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:9.cur"); player.addTag("mission:9.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 850); player.sendMessage("Received §a" + 850 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 850); player.sendMessage("Received §a" + 850 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 850); player.sendMessage("Received §a" + 850 + "§r yen")


      } else if (player.hasTag("mission:9.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 2."); player.sendMessage("§eYou killed a grade 2 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 2 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 75); player.sendMessage("Received §a" + 75 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 75); player.sendMessage("Received §a" + 75 + "§r exp")


      }


    }

  },
  {

    id: "jujutsu:megumi", command: function(player, entity) {

      if (player.hasTag("mission:10.cur")) {

        player.removeTag("mission:10.cur"); player.addTag("mission:10.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        player.setDynamicProperty("grade", 1)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 1500); player.sendMessage("Received §a" + 1500 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 1000); player.sendMessage("Received §a" + 1000 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 1050); player.sendMessage("Received §a" + 1050 + "§r yen")


      } else {

        player.sendMessage("§eYou killed a grade especial curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 200); player.sendMessage("Received §a" + 200 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 200); player.sendMessage("Received §a" + 200 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.1.1", command: function(player, entity) {

      if (player.hasTag("mission:11.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:11.cur"); player.addTag("mission:11.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 1000); player.sendMessage("Received §a" + 1000 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 1000); player.sendMessage("Received §a" + 1000 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 1000); player.sendMessage("Received §a" + 1000 + "§r yen")


      } else if (player.hasTag("mission:11.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 1."); player.sendMessage("§eYou killed a grade 1 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 1 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")


      }
      if (player.hasTag("mission:12.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:12.cur"); player.addTag("mission:12.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 1200); player.sendMessage("Received §a" + 1200 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 1200); player.sendMessage("Received §a" + 1200 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 1200); player.sendMessage("Received §a" + 1200 + "§r yen")


      } else if (player.hasTag("mission:12.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 1."); player.sendMessage("§eYou killed a grade 1 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 1 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")


      }


    }

  },
  {

    id: "lian:enemy.1.2", command: function(player, entity) {

      if (player.hasTag("mission:11.cur") && player.getDynamicProperty("mission.condition") >= 9) {

        player.removeTag("mission:11.cur"); player.addTag("mission:11.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 1000); player.sendMessage("Received §a" + 1000 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 1000); player.sendMessage("Received §a" + 1000 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 1000); player.sendMessage("Received §a" + 1000 + "§r yen")


      } else if (player.hasTag("mission:11.cur") && player.getDynamicProperty("mission.condition") < 9) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§710 §rcurses Grade 1."); player.sendMessage("§eYou killed a grade 1 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 1 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")


      }
      if (player.hasTag("mission:12.cur") && player.getDynamicProperty("mission.condition") >= 34) {

        player.removeTag("mission:12.cur"); player.addTag("mission:12.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 1200); player.sendMessage("Received §a" + 1200 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 1200); player.sendMessage("Received §a" + 1200 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 1200); player.sendMessage("Received §a" + 1200 + "§r yen")


      } else if (player.hasTag("mission:12.cur") && player.getDynamicProperty("mission.condition") < 34) {

        player.setDynamicProperty("mission.condition", player.getDynamicProperty("mission.condition") + 1); player.setDynamicProperty("mission.text", "Exorcise " + player.getDynamicProperty("mission.condition") + "/§735 §rcurses Grade 1."); player.sendMessage("§eYou killed a grade 1 curse!")


      } else {

        player.sendMessage("§eYou killed a grade 1 curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 100); player.sendMessage("Received §a" + 100 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 100); player.sendMessage("Received §a" + 100 + "§r exp")


      }


    }

  },
  {

    id: "jujutsu:jogo", command: function(player, entity) {

      if (player.hasTag("mission:13.cur")) {

        player.removeTag("mission:13.cur"); player.addTag("mission:13.finaly"); player.sendMessage("§eYou have completed a mission!"); player.playSound("random.orb"); player.setDynamicProperty("mission.have", false)
        player.setDynamicProperty("grade", 1)
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 2000); player.sendMessage("Received §a" + 2000 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 2000); player.sendMessage("Received §a" + 2000 + "§r exp")
        lib.setScore(player, "yen", lib.getScore(player, "yen") + 2000); player.sendMessage("Received §a" + 2000 + "§r yen")


      } else {

        player.sendMessage("§eYou killed a grade especial curse!")
        lib.setScore(player, "tp", lib.getScore(player, "tp") + 200); player.sendMessage("Received §a" + 200 + "§r tp")
        lib.setScore(player, "exp", lib.getScore(player, "exp") + 200); player.sendMessage("Received §a" + 200 + "§r exp")


      }


    }

  },]
  ids.forEach(entity => {
    
    data.deadEntity.typeId === entity.id ? (entity.command(data.damageSource.damagingEntity, data.deadEntity)): null


  })


})

mc.world.afterEvents.playerSpawn.subscribe(data => {

  const player = data.player;
  for (let i = 0; i < player.getComponent("minecraft:inventory").container.size; i++) {

    if (player.typeId === "player" && player.getComponent("minecraft:inventory").container.getItem(i).typeId === "lian:skills.air") {

      const item = new mc.ItemStack(player.getComponent("minecraft:inventory").container.getItem(i).getLore()[0], 1)
      player.getComponent("minecraft:inventory").container.setItem(i, item)


    }


  }


})