import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../lib.js";
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:item.1") {
    
    mc.system.run(() => {
      
      lib.setScore(data.source, "yp", lib.getScore(data.source, "yp") + 1)
      data.source.runCommandAsync("replaceitem entity @s slot.weapon.mainhand 1 air")
      lib.hitUi(data.source, "§eReceived 1 Yp."); data.source.playSound("note.banjo")

      
    })
    
    
  }
  
  
})