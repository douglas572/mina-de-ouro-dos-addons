import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:random.inata.1") {
    
    mc.system.run(() => {
      
      const items = [
        {id: "lian:skills.1.open", name: "Boggie wogie inata", ease: 20, dificult: "§f- Common"},
        {id: "lian:skills.8.open", name: "Straw doll inata", ease: 20, dificult: "§f- Common"},
        {id: "lian:skills.9.open", name: "Cursed speech inata", ease: 20, dificult: "§f- Common"}
      ]
      randomItem(data.source, items, function(player) {player.runCommandAsync("replaceitem entity @s slot.weapon.mainhand 1 air")})
      data.source.setDynamicProperty("mastery", 0)

      
    })
    
    
  }
  
  
})
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:random.inata.2") {
    
    mc.system.run(() => {
      
      const items = [
        {id: "lian:skills.1.open", name: "Boggie wogie inata", ease: 50, dificult: "§f- Common"},
        {id: "lian:skills.2.open", name: "Disaster flame inata", ease: 10, dificult: "§d- Rare"},
        {id: "lian:skills.3.open", name: "Six eyes inata", ease: 1, dificult: "§4- Legendary"},
        {id: "lian:skills.4.open", name: "Heavenly restriction inata", ease: 5, dificult: "§d- Epic"},
        {id: "lian:skills.6.open", name: "King of curses inata", ease: 1, dificult: "§4- Legendary"},
        {id: "lian:skills.8.open", name: "Straw doll inata", ease: 50, dificult: "§f- Common"},
        {id: "lian:skills.9.open", name: "Cursed speech inata", ease: 50, dificult: "§f- Common"}
      ]
      randomItem(data.source, items, function(player) {player.runCommandAsync("replaceitem entity @s slot.weapon.mainhand 1 air")})
      data.source.setDynamicProperty("mastery", 0)

      
    })
    
    
  }
  
  
})
function randomItem(player, array, command) {

  const ease = []
  array.forEach(item => {
    
    for (let i = 0; i < item.ease; i++) {

      ease.push({id: item.id, name: item.name, dificult: item.dificult})


    }


  })
  const random = lib.random(0, ease.length)
  !player.getDynamicProperty("randomSkillsSpin") ? player.setDynamicProperty("randomSkillsSpin", 0): null
  player.setDynamicProperty("randomSkillsSpin", player.getDynamicProperty("randomSkillsSpin") + 1)
  player.runCommandAsync(`replaceitem entity @s slot.weapon.mainhand 1 ${ease[random].id}`); player.playSound(`random.pop`)
  player.sendMessage(`You received §e${ease[random].name} ${ease[random].dificult}§7: you've spin ${player.getDynamicProperty("randomSkillsSpin")} times so far`)
  lib.hitUi(player, `                     You received §e${ease[random].name} ${ease[random].dificult}§7: ${player.getDynamicProperty("randomSkillsSpin")} spins`)


}