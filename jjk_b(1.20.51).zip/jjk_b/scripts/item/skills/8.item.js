import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:skills.8.open" && data.source.hasTag("pvp")) {mc.system.run(() => {

    data.source.setDynamicProperty("skill", 8)
    lib.setScore(data.source, "mode", 0)
    lib.open(data.source, lib.skills[8].itemsId)
  
  
  })}
  else if (data.itemStack.typeId == "lian:skills.load" && data.source.getDynamicProperty("clash") === 0) {mc.system.run(() => {lib.close(data.source); data.source.setDynamicProperty("skill", 0)})}
  
  
})

lib.itemUse("lian:skills.8.1", function(player, item) {

  lib.conditionSkill(player, 15, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.8.1", player.selectedSlot, 0.4, true, "lian:skills.8.bloqued")
    player.playAnimation("animation.player.skills.8.1")
    mc.system.runTimeout(() => {
  
      const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
      locate.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^^^1.5 run tp @s ~~~").then(() => {
  
        const entity = player.dimension.spawnEntity("lian:skills.8.1", {x: locate.location.x, y: locate.location.y + 1.8, z: locate.location.z})
        entity.nameTag = player.nameTag
        entity.setProperty("lian:pivot_x", player.getRotation().x)
        entity.setProperty("lian:pivot_y", player.getRotation().y)
        entity.addTag("projectile")
        entity.applyImpulse({x: player.getViewDirection().x * 3, y: player.getViewDirection().y  * 3, z: player.getViewDirection().z * 3})
      
      
      })
  
  
    }, lib.convertTick(0.15))


  })
  

})

lib.itemUse("lian:skills.8.2", function(player, item) {

  lib.conditionSkill(player, 50, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.8.2", player.selectedSlot, 1, true, "lian:skills.8.bloqued")
    player.playAnimation("animation.player.skills.8.1")
    mc.system.runTimeout(() => {
  
      const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
      locate.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^^^1.5 run tp @s ~~~").then(() => {
  
        const entity = player.dimension.spawnEntity("lian:skills.8.2", {x: locate.location.x, y: locate.location.y + 1.8, z: locate.location.z})
        entity.nameTag = player.nameTag
        entity.setProperty("lian:pivot_x", player.getRotation().x)
        entity.setProperty("lian:pivot_y", player.getRotation().y)
        entity.applyImpulse({x: player.getViewDirection().x * 3, y: player.getViewDirection().y  * 3, z: player.getViewDirection().z * 3})
      
      
      })
  
  
    }, lib.convertTick(0.15))


  })
  

})

lib.itemUse("lian:skills.8.3", function(player, item) {

  lib.conditionSkill(player, 250, 2, (player) => {

    lib.delayItem(player, "lian:skills.8.3", player.selectedSlot, 25, true, "lian:skills.8.bloqued")
    player.playAnimation("animation.player.skills.8.3")
    const entities = player.dimension.getEntities({excludeFamilies: ["not"], excludeNames: [player.nameTag], tag: [], maxDistance: 30, minDistance: 0})
    entities.forEach(entity => {
  
      try {

        if (entity.hasTag("markOfNobaraNail")) {
  
          entity.applyDamage(lib.getScore(player, "str_cur") * 5, {damagingEntity: player, cause: "entityExplosion"})
          entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 1)
          entity.removeTag("markOfNobaraNail")
          entity.dimension.createExplosion(entity.location, lib.random(1, 2), {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player})
          entity.runCommandAsync("particle lian:explosion")
          mc.world.playSound("explode", entity.location, {volume: 5, pitch: lib.random(9, 11) / 10})
    
    
        }


      } catch {}
      
  
    })
    const targets = player.dimension.getEntities({type: "lian:skills.8.2", name: player.nameTag})
    targets.forEach(target => {

      try {

        target.dimension.createExplosion(target.location, lib.random(1, 2), {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player})
        target.dimension.runCommandAsync("execute positioned " + target.location.x + " " + target.location.y + " " + target.location.z + " run particle lian:explosion")
        mc.world.playSound("explode", target.location, {volume: 5, pitch: lib.random(9, 11) / 10})
        const items = target.dimension.getEntities({type: "minecraft:item", maxDistance: 5, minDistance: 0, location: {x: target.location.x, y: target.location.y, z: target.location.z}})
        items.forEach(item => {item.remove()})
        const entities2 = target.dimension.getEntities({location: {x: target.location.x, y: target.location.y, z: target.location.z}, maxDistance: 10, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
        entities2.forEach(entity => {
    
          entity.applyDamage(lib.getScore(player, "str_cur") * 5, {damagingEntity: player, cause: "entityExplosion"})
          entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 1)
    
    
        })
        target.remove()


      } catch {}
      
  
    })
    if (!entities.find(player => player.hasTag("markOfNobaraNail")) && !targets[0]) {
  
      lib.hitUi(player, "§cYou didn't drive any nails."); player.playSound("note.bass")
  
  
    } else {
  
      lib.hitUi(player, "Blow all the nails!"); player.playSound("note.hat")
  
  
    }


  })
  

})

mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entity = event.hitEntity; const entityLocation = {x: entity.location.x, y: entity.location.y, z: entity.location.z}
  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.8.1" || player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.8.2" || player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.8.3"  || player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.8.open") {

    const kncRandom = (lib.random(0, 100) / 100)
    entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, kncRandom, 0.2)
    entity.applyDamage(lib.random(0, lib.getScore(player, "str_cur")) * 1, {damagingEntity: player, cause: "entityAttack"})


  }


})
mc.world.afterEvents.projectileHitEntity.subscribe(data => {

  const projectile = data.projectile, target = data.getEntityHit().entity
  if (projectile.typeId === "lian:skills.8.1") {

    const players = projectile.dimension.getPlayers()
    players.forEach(player => {

      if (player.nameTag === projectile.nameTag && target.nameTag !== projectile.nameTag) {

        target.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "entityAttack"})


      }


    })


  } else if (projectile.typeId === "lian:skills.8.2") {

    const players = projectile.dimension.getPlayers()
    players.forEach(player => {

      if (player.nameTag === projectile.nameTag && target.nameTag !== projectile.nameTag) {

        target.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "entityAttack"})
        target.addTag("markOfNobaraNail")
        const tick = mc.system.runInterval(() => {

          try {

            target.hasTag("markOfNobaraNail") ? target.runCommandAsync("particle lian:skills.extra.3 ~~~"): null
            mc.system.runTimeout(() => {
          
              mc.system.clearRun(tick)
              target.removeTag("markOfNobaraNail")
          
          
            }, lib.convertTick(40))


          } catch {}
          


        }, lib.convertTick(0.5))


      }


    })


  }



})