import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.afterEvents.itemStartUse.subscribe(data => {
  
    const player = data.source
    if (data.itemStack.typeId == "lian:skills.clash.1") {if (player.getDynamicProperty("clashNumber") === 1) {player.setDynamicProperty("clasHits", player.getDynamicProperty("clasHits") + 1); player.playSound("note.banjo"); const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (lib.random(-100, 100) / 100), y: player.location.y + 0.1, z: player.location.z + (lib.random(-100, 100) / 100)}); display.nameTag = `§a${player.getDynamicProperty("clasHits")}`} else {player.playSound("note.bass")}}
    if (data.itemStack.typeId == "lian:skills.clash.2") {if (player.getDynamicProperty("clashNumber") === 2) {player.setDynamicProperty("clasHits", player.getDynamicProperty("clasHits") + 1); player.playSound("note.banjo"); const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (lib.random(-100, 100) / 100), y: player.location.y + 0.1, z: player.location.z + (lib.random(-100, 100) / 100)}); display.nameTag = `§a${player.getDynamicProperty("clasHits")}`} else {player.playSound("note.bass")}}
    if (data.itemStack.typeId == "lian:skills.clash.3") {if (player.getDynamicProperty("clashNumber") === 3) {player.setDynamicProperty("clasHits", player.getDynamicProperty("clasHits") + 1); player.playSound("note.banjo"); const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (lib.random(-100, 100) / 100), y: player.location.y + 0.1, z: player.location.z + (lib.random(-100, 100) / 100)}); display.nameTag = `§a${player.getDynamicProperty("clasHits")}`} else {player.playSound("note.bass")}}
    if (data.itemStack.typeId == "lian:skills.clash.4") {if (player.getDynamicProperty("clashNumber") === 4) {player.setDynamicProperty("clasHits", player.getDynamicProperty("clasHits") + 1); player.playSound("note.banjo"); const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (lib.random(-100, 100) / 100), y: player.location.y + 0.1, z: player.location.z + (lib.random(-100, 100) / 100)}); display.nameTag = `§a${player.getDynamicProperty("clasHits")}`} else {player.playSound("note.bass")}}
    
    
})