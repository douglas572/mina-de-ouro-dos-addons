import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:skills.9.open" && data.source.hasTag("pvp")) {mc.system.run(() => {

    data.source.setDynamicProperty("skill", 9)
    lib.setScore(data.source, "mode", 1)
    lib.open(data.source, lib.skills[9].itemsId)
  
  
  })}
  else if (data.itemStack.typeId == "lian:skills.load" && data.source.getDynamicProperty("clash") === 0) {mc.system.run(() => {lib.close(data.source); data.source.setDynamicProperty("skill", 0); lib.setScore(data.source, "mode", 0)})}
  
  
})

lib.itemUse("lian:skills.9.1", function(player, item) {

  lib.conditionSkill(player, 25, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.9.1", player.selectedSlot, 12)
    const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, minDistance: 0, maxDistance: 15, excludeNames: [player.nameTag]})
    player.playAnimation("animation.player.skills.9.all")
    mc.system.runTimeout(() => {
      
      if (entities[0]) {
        
        lib.hitUi(player, "Do not move!")
        mc.world.playSound("skills.9.1", player.location, {volume: 5, pitch: lib.random(9, 11) / 10})
        entities.forEach(entity => {
          
          if (entity.typeId === "minecraft:player") {
            
            entity.runCommandAsync("inputpermission set @s movement disabled")
            mc.system.runTimeout(() => {entity.runCommandAsync("inputpermission set @s movement enabled")}, lib.convertTick(15))
            lib.hitUi(entity, "§cIs under the effect of the cursed speech of " + player.nameTag); entity.playSound("note.bass")
        
  
          } else {
            
            entity.setDynamicProperty("locationAfterSpeech", {x: entity.location.x, y: entity.location.y, z: entity.location.z})
            const tick = mc.system.runInterval(() => {
              
              try {entity.teleport(entity.getDynamicProperty("locationAfterSpeech"))} catch {}
            
            
            }, lib.convertTick(0.1))
            mc.system.runTimeout(() => {mc.system.clearRun(tick)}, lib.convertTick(10))
          
          
          }
        
        
        })
        mc.system.runTimeout(() => {lib.hitUi(player, "§cThe effect of speech is over"); player.playSound("note.bass")}, lib.convertTick(15))
      
      
      } else {
        
        lib.hitUi(player, "§cNo entities within 15 blocks"); player.playSound("note.bass")
      
      
      }
    
    
    }, lib.convertTick(0.39))


  })
  

})

lib.itemUse("lian:skills.9.2", function(player, item) {

  lib.conditionSkill(player, 80, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.9.2", player.selectedSlot, 8)
    const loc = player.dimension.spawnEntity("lian:entity.null", {x: player.location.x, y: player.location.y, z: player.location.z})
    loc.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^^1^5 run tp @s ~~~").then(() => {
      
      player.playAnimation("animation.player.skills.9.all")
      mc.system.runTimeout(() => {
        
        const entities = player.dimension.getEntities({location: {x: loc.location.x, y: loc.location.y, z: loc.location.z}, minDistance: 0, maxDistance: 5, excludeNames: [player.nameTag]})
        if (entities[0]) {
          
          entities.forEach(entity => {
            
            entity.applyDamage(lib.getScore(player, "str_cur") * 2.5, {damagingEntity: player, cause: "entityExplosion"})
            entity.runCommandAsync("particle lian:explosion")
            entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 2, 1)
            mc.world.playSound("explode", {x: entity.location.x, y: entity.location.y, z: entity.location.z}, {pitch: 1, volume: 1})
          
          
          })
          lib.hitUi(player, "Explode!")
          mc.world.playSound("skills.9.2", player.location, {volume: 5, pitch: lib.random(9, 11) / 10})
        
        
        } else {
          
          lib.hitUi(player, "§cNo entities around"); player.playSound("note.bass")
        
        
        }
      
      
      }, lib.convertTick(0.39))
    
    
    })


  })
  

})

lib.itemHitEntity("lian:skills.9.3", function(player, entity) {

  lib.conditionSkill(player, 200, 1, (player) => {

    lib.delayItem(player, "lian:skills.9.3", player.selectedSlot, 15)
    player.playAnimation("animation.player.skills.9.all")
    entity.applyDamage(lib.getScore(player, "str_cur") * 4, {damagingEntity: player, cause: "entityExplosion"})
    entity.runCommandAsync("particle lian:explosion")
    entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 100, 1)
    lib.hitUi(player, "Disappear!")
    mc.world.playSound("skills.9.3", player.location, {volume: 5, pitch: lib.random(9, 11) / 10})


  })


})

lib.itemHitEntity("lian:skills.9.4", function(player, entity) {

  if (entity.typeId === "minecraft:player") {

    lib.conditionSkill(player, 800, 1, (player) => {

      lib.delayItem(player, "lian:skills.9.4", player.selectedSlot, 30)
      player.playAnimation("animation.player.skills.9.all")
      lib.hitUi(player, "Die!")
      mc.world.playSound("skills.9.4", player.location, {volume: 5, pitch: lib.random(9, 11) / 10})
      lib.getScore(player, "energy_base") >= lib.getScore(entity, "energy_base") ? 
      (lib.hitUi(entity, "§cYou are weaker than the cursed speech user."), entity.playSound("note.bass"), entity.kill()): 
      (lib.hitUi(player, "§cYou are weaker than the target."), player.playSound("note.bass"), player.kill())


    })
  
  
  } else {
  
    lib.hitUi(player, "§cThis only works on players.")
  
  
  }


})