import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:skills.2.open" && data.source.hasTag("pvp")) {mc.system.run(() => {

    data.source.setDynamicProperty("skill", 2)
    lib.setScore(data.source, "mode", 0)
    lib.open(data.source, lib.skills[2].itemsId)
  
  
  })}
  else if (data.itemStack.typeId == "lian:skills.load" && data.source.getDynamicProperty("clash") === 0) {mc.system.run(() => {lib.close(data.source); data.source.setDynamicProperty("skill", 0)})}
  
  
})

// skill 1
lib.itemUse("lian:skills.2.1", function(player, item) {

  lib.conditionSkill(player, 80, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.2.1", player.selectedSlot, 2)
    player.playAnimation("animation.player.skills.2.3")
    mc.system.runTimeout(() => {
    
      for (let i = 0; i < 5; i++) {
        
        const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
        locate.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^" + lib.random(-10, 10) / 10 + "^" + lib.random(-10, 10) / 10 + "^2.5 run tp @s ~~~ ~~").then(() => {
  
          const entity = player.dimension.spawnEntity("lian:skills.2.3", {x: locate.location.x, y: locate.location.y + 1.8, z: locate.location.z})
          entity.nameTag = player.nameTag
          entity.applyImpulse({x: player.getViewDirection().x * 3, y: player.getViewDirection().y  * 3, z: player.getViewDirection().z * 3})
      
      
        })
  
  
      }
  
  
    }, lib.convertTick(0.15))


  })


})
lib.projectileHitEntity("lian:skills.2.3", function(player, target, projectile, location) {

  projectile.dimension.runCommandAsync("execute positioned " + location.x + " " + location.y + " " + location.z + " run particle lian:explosion")
  target.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "fire"})
  target.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 9, 0.1)
  projectile.dimension.createExplosion(location, 1, {breaksBlocks: false, source: player}); lib.killItens(projectile, 5)
  mc.world.playSound("explode", location, {pitch: lib.random(8, 15) / 10, volume: 1.0})
  projectile.remove()


})
lib.projectileHitBlock("lian:skills.2.3", function(player, projectile, location) {

  projectile.dimension.runCommandAsync("execute positioned " + location.x + " " + location.y + " " + location.z + " run particle lian:explosion")
  projectile.dimension.createExplosion(location, 1, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player}); lib.killItens(projectile, 5)
  mc.world.playSound("explode", location, {pitch: lib.random(8, 15) / 10, volume: 1.0})
  projectile.remove()


})

// skill 2
lib.itemHitEntity("lian:skills.2.1", function(player, entity) {

  !player.getDynamicProperty("skills.2.1") ? player.setDynamicProperty("skills.2.1", 0): null
  if (player.getDynamicProperty("skills.2.1") === 0) {

    lib.conditionSkill(player, 25, 1, (player) => {

      player.setDynamicProperty("skills.2.1", 1)
      lib.delayItem(player, "lian:skills.2.1", player.selectedSlot, 0.4)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 1, {damagingEntity: player, cause: "fire"})
      mc.world.playSound("mob.ghast.fireball", entity.location, {pitch: 1, volume: 1})
      lib.hitUi(player, "Hit 1")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.2.1.1")
      entity.runCommandAsync("particle lian:skills.2.1 ~~~")


    })


  } else if (player.getDynamicProperty("skills.2.1") === 1) {

    lib.conditionSkill(player, 25, 1, (player) => {

      player.setDynamicProperty("skills.2.1", 2)
      lib.delayItem(player, "lian:skills.2.1", player.selectedSlot, 0.4)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "fire"})
      mc.world.playSound("mob.ghast.fireball", entity.location, {pitch: 1, volume: 1})
      lib.hitUi(player, "Hit 2")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.2.1.2")
      entity.runCommandAsync("particle lian:skills.2.1 ~~~")


    })


  } else if (player.getDynamicProperty("skills.2.1") === 2) {

    lib.conditionSkill(player, 25, 1, (player) => {

      player.setDynamicProperty("skills.2.1", 0)
      lib.delayItem(player, "lian:skills.2.1", player.selectedSlot, 4)
      lib.hitUi(player, "Hit 3")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.2.1.3")
      entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "fire"})
      const tick = mc.system.runInterval(() => {
  
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 5, 0.4)
        entity.runCommandAsync("particle lian:skills.2.1 ~~~")
        mc.world.playSound("mob.ghast.fireball", entity.location, {pitch: 1, volume: 1})
  
  
      }, lib.convertTick(0.1))
      mc.system.runTimeout(() => {mc.system.clearRun(tick)}, lib.convertTick(0.5))


    })


  }


})
lib.tickItem("lian:skills.2.1", function(player) {player.playAnimation("animation.player.skills.2.1.all")})

// skill 3
lib.itemUse("lian:skills.2.2", function(player, item) {

  lib.conditionSkill(player, 150, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.2.2", player.selectedSlot, 10)
    player.runCommandAsync("inputpermission set @s movement disabled")
    player.runCommandAsync("camera @s set minecraft:third_person")
    player.playAnimation("animation.player.skills.2.2")
    const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 8, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
    mc.system.runTimeout(() => {
  
      const tick = mc.system.runInterval(() => {
  
        entities.forEach(entity => {
  
          entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "fire"})
          entity.runCommandAsync("particle lian:skills.2.1 ~~~")
          mc.world.playSound("mob.ghast.fireball", {x: entity.location.x, y: entity.location.y, z: entity.location.z}, {pitch: 1, volume: 1})
  
  
        })
  
  
      }, lib.convertTick(0.1))
      mc.system.runTimeout(() => {mc.system.clearRun(tick); player.runCommandAsync("inputpermission set @s movement enabled"); player.runCommandAsync("camera @s clear")}, lib.convertTick(1.5))
  
  
    }, lib.convertTick(1.3))


  })


})

// skill 4
lib.itemHitEntity("lian:skills.2.4", function(player, entity) {

  lib.conditionSkill(player, 350, 1, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.2.4", player.selectedSlot, 12)
    player.runCommandAsync("camera @s clear")
    entity.setDynamicProperty("locationOfVulcano", {x: entity.location.x, y: entity.location.y, z: entity.location.z})
    const projectile = entity.dimension.spawnEntity("lian:skills.2.4", {x: entity.location.x, y: entity.location.y, z: entity.location.z})
    const tick = mc.system.runInterval(() => {
      
      entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "fire"})
      entity.teleport(entity.getDynamicProperty("locationOfVulcano"))
  
  
    }, lib.convertTick(0.1))
    mc.system.runTimeout(() => {mc.system.clearRun(tick); projectile.remove(); entity.runCommandAsync("inputpermission set @s movement enabled"); entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.1)}, lib.convertTick(2))


  })


})

// skill 5
lib.itemUse("lian:skills.2.5", function(player, item) {

  lib.conditionSkill(player, 1000, 2, (player) => {

    const block = player.getBlockFromViewDirection({maxDistance: 200})
    if (block) {
  
      player.runCommandAsync("camera @s clear")
      player.playSound("note.hat"); lib.delayItem(player, "lian:skills.2.5", player.selectedSlot, 30)
      player.playAnimation("animation.player.skills.2.5")
      mc.system.runTimeout(() => {
        
        const locate = player.dimension.spawnEntity("lian:projectileView", block.block.location)
        locate.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^^^ run tp @s ~~~ ~~").then(() => {
    
          const entity = player.dimension.spawnEntity("lian:skills.2.5", {x: block.block.location.x, y:  block.block.location.y + 100, z:  block.block.location.z})
          entity.nameTag = player.nameTag
          entity.applyImpulse({x: 0, y: -15, z: 0})
          mc.system.runTimeout(() => {player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 2, 2)}, lib.convertTick(0.1))
    
    
        })
    
    
      }, lib.convertTick(0.5))

  
    } else {lib.hitUi(player, "No blocks nearby")}


  })


})
lib.projectileHitBlock("lian:skills.2.5", function(player, projectile, location) {

  try {
          
    const entities = projectile.dimension.getEntities({location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, maxDistance: 25, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
    entities.forEach(entity => {

      entity.applyDamage(lib.getScore(player, "str_cur") * 4, {damagingEntity: player, cause: "fire"})
      entity.runCommandAsync("particle lian:skills.2.1 ~~~")
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 30, 1)
      mc.world.playSound("mob.ghast.fireball", {x: entity.location.x, y: entity.location.y, z: entity.location.z}, {pitch: 1, volume: 100})


    })


  } catch {}
  mc.world.playSound("explode", location, {pitch: lib.random(8, 15) / 10, volume: 100})
  projectile.dimension.createExplosion(location, 20, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player, causesFire: false})
  const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: 25, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()}); projectile.remove()


})

// skill 6
lib.itemUse("lian:skills.2.6", function(player, item) {

  lib.conditionSkill(player, 350, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.2.6", player.selectedSlot, 10)
    const player2 = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 30, minDistance: 0, type: "minecraft:player", tags: ["ownerExpansion"], excludeNames: [player.nameTag]})
    if (player2[0] && player.getDynamicProperty("domain") === 0) {
      
      if (player2[0].getDynamicProperty("clash") === 0) {
  
        player.runCommandAsync("camera @s set minecraft:third_person"); player2[0].runCommandAsync("camera @s set minecraft:third_person"); player.setDynamicProperty("clasHits", 0); player.setDynamicProperty("clashStage", 0)
        player2[0].setDynamicProperty("clasHits", 0); player2[0].setDynamicProperty("clashStage", 0); player.runCommandAsync("inputpermission set @s camera disabled"); player.runCommandAsync("inputpermission set @s movement disabled")
        player2[0].runCommandAsync("inputpermission set @s camera disabled"); player2[0].runCommandAsync("inputpermission set @s movement disabled")
        player.runCommandAsync("camerashake add @s 0.3 15 positional"); player2[0].runCommandAsync("camerashake add @s 0.3 15 positional")
        lib.setScore(player, "res_cur", 1000); lib.setScore(player2[0], "res_cur", 1000)
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(0))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(2))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(4))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(6))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(8))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(10))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(12))
        mc.system.runTimeout(() => {player.setDynamicProperty("clash", 0); player2[0].setDynamicProperty("clash", 0); lib.open(player, lib.skills[2].itemsId)}, lib.convertTick(12))
  
  
      } else {
  
        lib.hitUi(player, "§cWait for the clash to end")
  
  
      }
  
  
    } else {expansion(player)}
  
    
  })


})
function clash(players) {

  if (players[0].getDynamicProperty("clashStage") >= 6 || players[1].getDynamicProperty("clashStage") >= 6) {

   if (players[0].getDynamicProperty("clasHits") > players[1].getDynamicProperty("clasHits")) {

     lib.hitUi(players[0], "Player " + players[0].nameTag + " won!")
     lib.hitUi(players[1], "Player " + players[0].nameTag + " won!")
     players[0].setDynamicProperty("domain", 0)
     players[1].setDynamicProperty("domain", 1)
     lib.removeExpansion(players[1], "lian:skills.2.6")
     mc.system.runTimeout(() => {expansion(players[0])}, lib.convertTick(2))


   } else if (players[0].getDynamicProperty("clasHits") < players[1].getDynamicProperty("clasHits")) {

     lib.hitUi(players[0], "Player " + players[1].nameTag + " won!")
     lib.hitUi(players[1], "Player " + players[1].nameTag + " won!")
     lib.delayItem(players[0], "lian:skills.2.6", 8, 100)
     players[0].setDynamicProperty("domain", 0)
     players[1].setDynamicProperty("domain", 1)


   } else {

     lib.hitUi(players[0], "A tie!!")
     lib.hitUi(players[1], "A tie!!")
     players[1].setDynamicProperty("domain", 1)
     players[0].setDynamicProperty("domain", 0)
     lib.removeExpansion(players[1], "lian:skills.2.6")
     lib.delayItem(players[0], "lian:skills.2.6", 8, 100)
     lib.delayItem(players[1], "lian:skills.2.6", 8, 100)


   }
   players[0].runCommandAsync("inputpermission set @s camera enabled")
   players[0].runCommandAsync("inputpermission set @s movement enabled")
   players[1].runCommandAsync("inputpermission set @s camera enabled")
   players[1].runCommandAsync("inputpermission set @s movement enabled")
   lib.setScore(players[0], "res_cur", lib.getScore(players[0], "res_base"))
   lib.setScore(players[1], "res_cur", lib.getScore(players[1], "res_base"))
   players[0].runCommandAsync("camera @s clear")
   players[1].runCommandAsync("camera @s clear")


  } else {

   let random1 = lib.random(5, 8); let random2 = lib.random(5, 8); let random3 = lib.random(5, 8); let random4 = lib.random(5, 8)
   for (let i = 0; random1 === random2 || random1 === random3 || random1 === random4; i++) {random1 = lib.random(5, 8)}
   for (let i = 0; random2 === random1 || random2 === random3 || random2 === random4; i++) {random2 = lib.random(5, 8)}
   for (let i = 0; random3 === random2 || random3 === random1 || random3 === random4; i++) {random3 = lib.random(5, 8)}
   for (let i = 0; random4 === random2 || random4 === random3 || random4 === random1; i++) {random4 = lib.random(5, 8)}
   for (let i = 0; i < 2; i++) {

     players[i].playSound("note.bell")
     !players[i].getDynamicProperty("clashNumber") ? players[i].setDynamicProperty("clashNumber", 0): null
     !players[i].getDynamicProperty("clasHits") ? players[i].setDynamicProperty("clasHits", 1): null;
     !players[i].getDynamicProperty("clashStage") ? players[i].setDynamicProperty("clashStage", 0): null; players[i].setDynamicProperty("clashStage", players[i].getDynamicProperty("clashStage") + 1)
     players[i].setDynamicProperty("clashNumber", lib.random(1, 4))
     players[i].setDynamicProperty("clash", 1)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random1} lian:skills.clash.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random2} lian:skills.clash.2 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random3} lian:skills.clash.3 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random4} lian:skills.clash.4 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)

   
   }

  }


}
function expansion(player) {

  !player.getDynamicProperty("domain") ? player.setDynamicProperty("domain", 0): null
  if (player.getDynamicProperty("domain") === 0) {
    
    player.setDynamicProperty("domain", 1)
    player.playAnimation("animation.player.skills.2.6"); mc.world.playSound("skills.2.6.1", player.location, {pitch: 1, volume: 10.0})
    player.addTag("ownerExpansion")
    const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 15, minDistance: 0, type: "minecraft:player"})
    players.forEach(a => {
    
      a.runCommandAsync("execute as @s at @a[name=\"" + player.nameTag + "\"] run camera @s set minecraft:free ease 1 linear pos ^^1.8^2 facing ~~1.5~")
      lib.subtitle(a, "Domain expansion...")
      a.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.1)
      a.runCommandAsync("inputpermission set @s camera disabled")
      a.runCommandAsync("inputpermission set @s movement disabled")
      lib.setScore(a, "res_cur", 1000)
      a.setDynamicProperty("scene", 1)
  
    
    })
    mc.system.runTimeout(() => {

      player.runCommandAsync("execute positioned ~ 198 ~ run fill ~25~~25 ~-25~~-25 lian:void_expansion.1")
      player.runCommandAsync("execute positioned ~ 198 ~ run fill ~15~~15 ~-15~25~-15 lian:void_expansion.1").then(() => {

        player.runCommandAsync("event entity @e[r=100] expansion.kill")
        const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 15, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
        entities.forEach(entity => {
    
          !entity.hasTag("isInExpansion") ? entity.setDynamicProperty("locAfterDomainX", entity.location.x): null
          !entity.hasTag("isInExpansion") ? entity.setDynamicProperty("locAfterDomainY", entity.location.y): null
          !entity.hasTag("isInExpansion") ? entity.setDynamicProperty("locAfterDomainZ", entity.location.z): null
          entity.teleport({x: entity.location.x, y: 199, z: entity.location.z})
          entity.typeId === "minecraft:player" ? (entity.runCommandAsync("camera @s fade time 0 1 5 color 0 0 0"), entity.runCommandAsync("fog @s push lian:jogo domainFog"), entity.removeTag("breacksBlock")): null
          entity.addTag("isInExpansion")
          entity.nameTag !== player.nameTag ? entity.setDynamicProperty("domain", 0): null

  
        })
        player.runCommandAsync("execute positioned ~ 200 ~ run structure load domain.jogo ~-25 ~-3 ~-25 0_degrees none layer_by_layer 4 false")
        mc.system.runTimeout(() => {
                
          mc.world.playSound("skills.2.6.2", player.location, {pitch: 1, volume: 10.0})
          const visual = player.dimension.spawnEntity("lian:skills.2.6", {x: player.location.x, y: 199, z: player.location.z})
          visual.nameTag = "expansionOf." + player.nameTag
              
              
        }, lib.convertTick(0.5))
        const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 15, minDistance: 0, type: "minecraft:player"})
        players.forEach(a => {
        
          a.runCommandAsync("camera @s clear")
          a.runCommandAsync("inputpermission set @s camera enabled")
          a.runCommandAsync("inputpermission set @s movement enabled")
          lib.setScore(a, "res_cur", lib.getScore(a, "res_base"))
          a.setDynamicProperty("scene", 0)
      
        
        })
        lib.subtitle(player, "Iron Mountain Confinement")
        player.setDynamicProperty("domainIs", 1); player.setDynamicProperty("domainTime", 100)
    
    
      })


    }, lib.convertTick(3))


  } else if (player.getDynamicProperty("domain") === 1) {
    
    lib.delayItem(player, "lian:skills.2.6", player.selectedSlot, 40)
    player.setDynamicProperty("domain", 0)
    player.runCommandAsync("execute positioned " + player.getDynamicProperty("locAfterDomainX") + " 200 " + player.getDynamicProperty("locAfterDomainZ") + " run structure load domain.erase ~-25 ~-3 ~-25").then(() => {

      const entities = player.dimension.getEntities({location: {x: player.getDynamicProperty("locAfterDomainX"), y: player.location.y, z: player.getDynamicProperty("locAfterDomainZ")}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
      entities.forEach(entity => {
  
        entity.removeTag("isInExpansion")
        entity.removeTag("ownerExpansion")
        entity.getDynamicProperty("locAfterDomainY") ? entity.teleport({x: entity.getDynamicProperty("locAfterDomainX"), y: entity.getDynamicProperty("locAfterDomainY"), z: entity.getDynamicProperty("locAfterDomainZ")}): null
        entity.typeId === "minecraft:player" ? (entity.runCommandAsync("camera @s fade time 0 0 1 color 0 0 0"), entity.runCommandAsync("fog @s remove domainFog"), entity.addTag("breacksBlock")): null
  
  
      })
      player.setDynamicProperty("domainIs", 0); player.setDynamicProperty("domainTime", 0)
      player.setDynamicProperty("multiplier", 1)
  
  
    })


  }



}
mc.system.runInterval(() => {

  for (const player of mc.world.getPlayers()) {

    if (player.hasTag("ownerExpansion") && player.getDynamicProperty("skill") === 2 && lib.getScore(player, "energy_cur") >= (lib.getScore(player, "energy_base") / 100 * 1)) {player.getDynamicProperty("scene") === 0 ? lib.setScore(player, "energy_cur", lib.clamp(lib.getScore(player, "energy_cur") - Math.round(lib.getScore(player, "energy_base") / 100 * 1), 0, lib.getScore(player, "energy_base"))): null}


  }


}, lib.convertTick(1))
lib.tick((player) => {

  if (player.hasTag("ownerExpansion") && player.getDynamicProperty("skill") === 2) {
    
    if (lib.getScore(player, "energy_cur") >= (lib.getScore(player, "energy_base") / 100 * 1)) {
      
      player.getDynamicProperty("scene") === 0 ? lib.setScore(player, "energy_cur", Math.round(lib.clamp(lib.getScore(player, "energy_cur") - (lib.getScore(player, "energy_base") / 100 * 0.3), 0, lib.getScore(player, "energy_base")))): null
      player.setDynamicProperty("multiplier", 1.5)
      const entities = player.dimension.getEntities({location: {x: player.getDynamicProperty("locAfterDomainX"), y: player.location.y, z: player.getDynamicProperty("locAfterDomainZ")}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"], excludeNames: [player.nameTag]})
      entities.forEach(entity => {
        
        if (!entity.getDynamicProperty("simpleDomain")) {
  
          entity.applyDamage(lib.getScore(player, "str_cur") * 0.1, {damagingEntity: player, cause: "fire"})


        }
      
      
      })

    } else {

      lib.hitUi(player, "§chas no energy...")
      player.playSound("note.bass")
      lib.delayItem(player, "lian:skills.3.5", 8, 40)
      player.setDynamicProperty("domain", 0)
      player.runCommandAsync("execute positioned " + player.getDynamicProperty("locAfterDomainX") + " 200 " + player.getDynamicProperty("locAfterDomainZ") + " run structure load domain.erase ~-15 ~-15 ~-15").then(() => {
   
        const entities = player.dimension.getEntities({location: {x: player.getDynamicProperty("locAfterDomainX"), y: player.location.y, z: player.getDynamicProperty("locAfterDomainZ")}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
        entities.forEach(entity => {
    
          entity.removeTag("isInExpansion")
          entity.removeTag("ownerExpansion")
          entity.getDynamicProperty("locAfterDomainY") ? entity.teleport({x: entity.getDynamicProperty("locAfterDomainX"), y: entity.getDynamicProperty("locAfterDomainY"), z: entity.getDynamicProperty("locAfterDomainZ")}): null
          entity.typeId === "minecraft:player" ? (entity.runCommandAsync("camera @s fade time 0 0 1 color 0 0 0"), entity.runCommandAsync("fog @s remove domainFog"), entity.addTag("breacksBlock")): null
    
    
        })
        player.setDynamicProperty("domainIs", 0)
        player.setDynamicProperty("multiplier", 1)
    
    
      })


    }


  }

})