import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:skills.3.open" && data.source.hasTag("pvp")) {mc.system.run(() => {

    data.source.setDynamicProperty("skill", 3)
    lib.setScore(data.source, "mode", 3)
    lib.open(data.source, lib.skills[3].itemsId)
  
  
  })}
  else if (data.itemStack.typeId == "lian:skills.load" && data.source.getDynamicProperty("clash") === 0) {mc.system.run(() => {lib.close(data.source); data.source.setDynamicProperty("skill", 0); lib.setScore(data.source, "mode", 0)})}
  
  
})

lib.itemUse("lian:skills.3.1", function(player, item) {

  player.playSound("note.hat"); lib.delayItem(player, "lian:skills.3.1", player.selectedSlot, 40)
  player.runCommandAsync("camera @s fade time 0.5 0 0.5 color 0 0 0")
  player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.1)
  player.runCommandAsync("inputpermission set @s camera disabled")
  player.runCommandAsync("inputpermission set @s movement disabled")
  player.setProperty("lian:particle", 0)
  player.addTag("invulnerable")
  player.addTag("infinitySkill")

  mc.system.runTimeout(() => {

    player.runCommandAsync("camera @s set minecraft:free ease 0 linear pos ^^2^2 facing ~~1.5~")
    player.playAnimation("animation.player.skills.3.1.2")
    lib.subtitle(player, "Infinite")
    player.setDynamicProperty("scene", 1)


  }, lib.convertTick(0.5))
  mc.system.runTimeout(() => {}, lib.convertTick(1.2))
  mc.system.runTimeout(() => {player.runCommandAsync("camera @s fade time 0.5 0 0.5 color 0 0 0")}, lib.convertTick(3))
  mc.system.runTimeout(() => {

    player.runCommandAsync("camera @s clear")
    player.setDynamicProperty("scene", 0)
    player.runCommandAsync("inputpermission set @s camera enabled")
    player.runCommandAsync("inputpermission set @s movement enabled")


  }, lib.convertTick(3.5))


})
lib.itemHitEntity("lian:skills.3.1", function(player, entity) {

  !player.getDynamicProperty("skills.3.1") ? player.setDynamicProperty("skills.3.1", 0): null
  if (player.getDynamicProperty("skills.3.1") === 0) {

    lib.conditionSkill(player, 20, 1, (player) => {

      player.setDynamicProperty("skills.3.1", 1)
      lib.delayItem(player, "lian:skills.3.1", player.selectedSlot, 0.1)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "entityAttack"})
      lib.hitUi(player, "Cut 1")
      player.playAnimation("animation.player.skills.2.1.1")
      entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      mc.world.playSound("explode", player.location, {pitch: lib.random(9, 11) / 10, volume: 1.0})
      entity.runCommandAsync("particle lian:skills.4.1 ^^1^")


    })


  } else if (player.getDynamicProperty("skills.3.1") === 1) {

    lib.conditionSkill(player, 20, 1, (player) => {

      player.setDynamicProperty("skills.3.1", 2)
      lib.delayItem(player, "lian:skills.3.1", player.selectedSlot, 0.1)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "entityAttack"})
      lib.hitUi(player, "Cut 2")
      player.playAnimation("animation.player.skills.2.1.2")
      entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      mc.world.playSound("explode", player.location, {pitch: lib.random(9, 11) / 10, volume: 1.0})
      entity.runCommandAsync("particle lian:skills.4.1 ^^1^")


    })
    

  } else if (player.getDynamicProperty("skills.3.1") === 2) {

    lib.conditionSkill(player, 20, 1, (player) => {

      player.setDynamicProperty("skills.3.1", 0)
      lib.delayItem(player, "lian:skills.3.1", player.selectedSlot, 1)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 6, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 2.5, {damagingEntity: player, cause: "entityAttack"})
      lib.hitUi(player, "Cut 3")
      player.playAnimation("animation.player.skills.2.1.3")
      entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      mc.world.playSound("explode", player.location, {pitch: lib.random(9, 11) / 10, volume: 1.0})
      entity.runCommandAsync("particle lian:skills.4.1 ^^1^")


    })


  }
  

})
lib.tick((player) => {

  if (player.hasTag("infinitySkill") && lib.getScore(player, "energy_cur") > 0) {

    lib.setScore(player, "energy_cur", lib.clamp(lib.getScore(player, 'energy_cur') - Math.round(lib.getScore(player, "energy_base") / 100 * 1), 0, lib.getScore(player, 'energy_base')))
    player.setProperty("lian:particle", 31)
    const entities = player.dimension.getEntities({location: player.location, maxDistance: 2, excludeNames: [player.nameTag]})
    entities.forEach(entity => {entity.applyKnockback(-entity.getViewDirection().x, -entity.getViewDirection().z, 2, 0.1)})


  } else if (player.hasTag("infinitySkill") && lib.getScore(player, "energy_cur") === 0) {

    player.setProperty("lian:particle", 0)
    player.removeTag("infinitySkill")
    lib.hitUi(player, "§cYour infinity is over."); player.playSound("note.bass")
    player.removeTag("invulnerable")


  }
  if (player.hasTag("infinitySkill") && player.getDynamicProperty("skill") !== 3) {

    player.setProperty("lian:particle", 0)
    player.removeTag("infinitySkill")
    lib.hitUi(player, "§cYou have disabled your ability."); player.playSound("note.bass")
    player.removeTag("invulnerable")


  }



})

lib.itemUse("lian:skills.3.2", function(player, item) {

  lib.conditionSkill(player, 80, 2, (player) => {

    const block = player.getBlockFromViewDirection({maxDistance: 50})
    if (block) {
  
      player.playSound("note.hat"); lib.delayItem(player, "lian:skills.3.2", player.selectedSlot, 5, "lian:skills.air.2")
      player.runCommandAsync("camera @s clear"); player.runCommandAsync("inputpermission set @s camera disabled"); player.runCommandAsync("inputpermission set @s movement disabled")
      player.playAnimation("animation.player.skills.3.2.2")
      mc.system.runTimeout(() => {
  
        const entity2 = player.dimension.spawnEntity("lian:entity.null", {x: block.block.location.x + block.faceLocation.x, y: block.block.location.y + (block.faceLocation.y === 1 ? 1: block.faceLocation.y !== 0 ? block.faceLocation.y: -2), z: block.block.location.z + block.faceLocation.z})
        entity2.runCommandAsync("particle lian:skills.3.2.3 ~~0.2~")
        entity2.runCommandAsync("particle lian:skills.3.2.4 ~~0.2~")
        entity2.runCommandAsync("particle lian:skills.3.2.5")
        entity2.runCommandAsync("particle lian:skills.3.2.6 ~~0.2~")
        entity2.runCommandAsync("particle lian:skills.3.2.7 ~~0.2~")
        mc.system.runTimeout(() => {
  
          const entities = entity2.dimension.getEntities({location: {x: entity2.location.x, y: entity2.location.y, z: entity2.location.z}, maxDistance: 25, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
          entities.forEach(entity5 => {
  
            entity5.applyDamage(lib.getScore(player, "str_cur") * 2.5, {damagingEntity: player, cause: "void"})
            mc.world.playSound("spread.sculk", {x: entity5.location.x, y: entity5.location.y, z: entity5.location.z}, {pitch: 1, volume: 1})
            entity5.teleport(entity2.location)
            mc.world.playSound("explode", entity2.location, {pitch: lib.random(40, 80) / 10, volume: 2})
  
  
          })
          lib.hitUi(player, "To Pull")          
  
        
        }, lib.convertTick(0.2))
  
      
      }, lib.convertTick(0.2))
      mc.system.runTimeout(() => {player.runCommandAsync("inputpermission set @s camera enabled"); player.runCommandAsync("inputpermission set @s movement enabled"); player.setProperty("lian:particle", 0)}, lib.convertTick(0.65))
  
  
    } else {lib.hitUi(player, "No blocks nearby")}


  })


})
lib.itemHitEntity("lian:skills.3.2", function(player, entity) {

  lib.conditionSkill(player, 100, 1, (player) => {

    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.1); player.runCommandAsync("inputpermission set @s camera disabled"); player.runCommandAsync("inputpermission set @s movement disabled")
    player.playAnimation("animation.player.skills.3.2.2"); player.runCommandAsync("camera @s set minecraft:third_person"); lib.delayItem(player, "lian:skills.3.2", player.selectedSlot, 6, "lian:skills.air.2")
    entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.1)
    mc.system.runTimeout(() => {
      
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear"); player.runCommandAsync("inputpermission set @s camera enabled"); player.runCommandAsync("inputpermission set @s movement enabled")}, lib.convertTick(0.5))
      entity.runCommandAsync("particle lian:skills.3.2.3 ~~0.2~")
      entity.runCommandAsync("particle lian:skills.3.2.4 ~~0.2~")
      entity.runCommandAsync("particle lian:skills.3.2.5")
      entity.runCommandAsync("particle lian:skills.3.2.6 ~~0.2~")
      entity.runCommandAsync("particle lian:skills.3.2.7 ~~0.2~")
      mc.system.runTimeout(() => {
  
        const entities = entity.dimension.getEntities({location: {x: entity.location.x, y: entity.location.y, z: entity.location.z}, maxDistance: 12 , minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
        entities.forEach(entity5 => {
  
          entity5.applyDamage(lib.getScore(player, "str_cur") * 3, {damagingEntity: player, cause: "fire"})
          mc.world.playSound("spread.sculk", {x: entity.location.x, y: entity.location.y, z: entity.location.z}, {pitch: 1, volume: 1})
          entity5.teleport(entity.location)
  
  
        })
        lib.hitUi(player, "Snatch")
        mc.world.playSound("explode", player.location, {pitch: lib.random(40, 80) / 10, volume: 2})
  
      
      }, lib.convertTick(0.2))
  
    
    }, lib.convertTick(0.2))


  })


})

lib.itemUse("lian:skills.3.3", function(player, item) {

  lib.conditionSkill(player, 200, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.3.3", player.selectedSlot, 10, "lian:skills.air.2")
    player.playAnimation("animation.player.skills.3.3")
    player.runCommandAsync("inputpermission set @s movement disabled")
    lib.setScore(player, "res_cur", 1000)
    mc.system.runTimeout(() => {player.runCommandAsync("inputpermission set @s movement enabled")}, lib.convertTick(1.5))
    mc.system.runTimeout(() => {
      
      player.runCommandAsync("camera @s fade time 0 0.1 0.8 color 255 100 100")
  
      for (let i = 0; i < 40; i++) {const effect = player.dimension.spawnEntity("lian:skills.blocks", player.location); effect.applyKnockback(lib.random(180, -180), lib.random(180, -180), lib.random(2.5, 4), 0.1)}
      for (let i = 0; i < 10; i++) {const effect = player.dimension.spawnEntity("lian:skills.blocks", player.location); effect.applyKnockback(lib.random(180, -180), lib.random(180, -180), lib.random(0.5, 4), 0.5)}
    
    
    }, lib.convertTick(0.5))
    mc.system.runTimeout(() => {
  
      mc.world.playSound("explode", player.location, {pitch: lib.random(8, 15) / 10, volume: 2})
      player.runCommandAsync("particle lian:skills.3.3.5")
      player.runCommandAsync("particle lian:skills.3.3.6")
      player.runCommandAsync("particle lian:skills.3.3.7")
      player.runCommandAsync("particle lian:skills.3.3.8")
      player.runCommandAsync("particle lian:skills.3.3.9")
      player.runCommandAsync("particle lian:skills.3.3.10")
      const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 6, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
      entities.forEach(entity => {
  
        entity.applyDamage(lib.getScore(player, "str_cur") * 4, {damagingEntity: player, cause: "void"})
        entity.applyKnockback(lib.random(180, -180), lib.random(180, -180), lib.random(10, 12), lib.random(0.1, 1))
  
  
      })
      lib.hitUi(player, "To Pull")
      lib.setScore(player, "res_cur", lib.getScore(player, "res_base"))
    
    
    }, lib.convertTick(0.6))


  })


})

lib.itemUse("lian:skills.3.4", function(player, item) {

  lib.conditionSkill(player, 350, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.3.1", player.selectedSlot, 25)
    player.runCommandAsync("camera @s fade time 0.5 0 0.5 color 0 0 0")
    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.1)
    player.runCommandAsync("inputpermission set @s camera disabled")
    player.runCommandAsync("inputpermission set @s movement disabled")
    lib.setScore(player, "res_cur", 1000)
    mc.world.playSound("skills.3.4.1", player.location, {volume: 5, pitch: 1})
    mc.system.runTimeout(() => {
  
      player.runCommandAsync("camera @s set minecraft:free ease 1 linear pos ^-3^2^-2 facing ~~1.5~")
      lib.subtitle(player, "Blue...")
      player.playAnimation("animation.player.skills.3.4")
      player.setDynamicProperty("scene", 1)
  
  
    }, lib.convertTick(0.5))
    mc.system.runTimeout(() => {
  
      player.runCommandAsync("camera @s set minecraft:free ease 2 linear pos ^2^2^-3 facing ~~1.5~")
      mc.world.playSound("skills.3.4.2", player.location, {volume: 5, pitch: 1})
  
  
    }, lib.convertTick(2))
    mc.system.runTimeout(() => {
  
      lib.subtitle(player, "Red...")
  
  
    }, lib.convertTick(3))
    mc.system.runTimeout(() => {
  
      player.runCommandAsync("camera @s set minecraft:free ease 0 linear pos ^1^2^1 facing ~~1.5~")
      mc.world.playSound("skills.3.4.3", player.location, {volume: 10, pitch: 1})
  
  
    }, lib.convertTick(6))
    mc.system.runTimeout(() => {
  
      lib.subtitle(player, "Hollow purple")
  
  
    }, lib.convertTick(6.5))
    mc.system.runTimeout(() => {
  
      player.runCommandAsync("camera @s clear")
      player.runCommandAsync("inputpermission set @s camera enabled")
      player.setDynamicProperty("scene", 0)
  
  
    }, lib.convertTick(8.5))
    mc.system.runTimeout(() => {
      
      // mc.world.playSound("skills.3.4.4", player.location, {volume: 100, pitch: 1})
      const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
      locate.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^^^ run tp @s ~~~ ~~").then(() => {
  
        const entity = player.dimension.spawnEntity("lian:skills.3.4", {x: locate.location.x, y: locate.location.y + 1.8, z: locate.location.z})
        entity.nameTag = player.nameTag
        entity.applyImpulse({x: player.getViewDirection().x * 2, y: player.getViewDirection().y * 2, z: player.getViewDirection().z * 2})
        mc.world.playSound("explode", player.location, {pitch: 1, volume: 2})
        
        const tick = mc.system.runInterval(() => {
        
          try {
  
            entity.dimension.createExplosion(entity.location, lib.random(20, 40) / 10, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player})
            const items = entity.dimension.getEntities({type: "minecraft:item", maxDistance: 5, minDistance: 0, location: {x: entity.location.x, y: entity.location.y, z: entity.location.z}})
            items.forEach(item => {item.remove()})
            entity.runCommandAsync("particle lian:skills.3.4.17")
            const entities = player.dimension.getEntities({location: {x: entity.location.x, y: entity.location.y, z: entity.location.z}, maxDistance: 6, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
            entities.forEach(entity => {
  
              entity.applyDamage(lib.getScore(player, "str_cur") * 8, {damagingEntity: player, cause: "void"})
              entity.applyKnockback(lib.random(180, -180), lib.random(180, -180), lib.random(10, 12), lib.random(0.1, 1))
  
  
            })
            mc.world.playSound("explode", player.location, {pitch: 1, volume: 2})
  
  
          } catch {}
  
  
        }, lib.convertTick(0.01))
        mc.system.runTimeout(() => {entity.remove(); mc.system.clearRun(tick)}, lib.convertTick(5))
        const locate2 = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 0.5, z: player.location.z})
        locate2.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^5^^ run tp @s ~~~ ~~").then(() => {
  
          const entity = player.dimension.spawnEntity("lian:entity.projectile", {x: locate2.location.x, y: locate2.location.y + 0.5, z: locate2.location.z})
          entity.nameTag = player.nameTag
          entity.applyImpulse({x: player.getViewDirection().x * 2, y: player.getViewDirection().y * 2, z: player.getViewDirection().z * 2})
          player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 4, 0.6)
          const tick = mc.system.runInterval(() => {
            
            try {
  
              const effect = entity.dimension.spawnEntity("lian:skills.blocks", entity.location)
              effect.applyKnockback(lib.random(-180, 180), lib.random(-180, 180), lib.random(0.1, 1), 0.2)
  
  
            } catch {}
  
  
          }, lib.convertTick(0.1))
  
  
        })
        const locate3 = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 0.5, z: player.location.z})
        locate3.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^-5^^ run tp @s ~~~ ~~").then(() => {
  
          const entity = player.dimension.spawnEntity("lian:entity.projectile", {x: locate3.location.x, y: locate3.location.y + 0.5, z: locate3.location.z})
          entity.nameTag = player.nameTag
          entity.applyImpulse({x: player.getViewDirection().x * 2, y: player.getViewDirection().y * 2, z: player.getViewDirection().z * 2})
          const tick = mc.system.runInterval(() => {
            
            try {
  
              const effect = entity.dimension.spawnEntity("lian:skills.blocks", entity.location)
              effect.applyKnockback(lib.random(-180, 180), lib.random(-180, 180), lib.random(0.5, 1), 0.1)
              const effect2 = entity.dimension.spawnEntity("lian:skills.blocks", entity.location)
              effect2.applyKnockback(lib.random(-180, 180), lib.random(-180, 180), lib.random(3, 6), 0.8)
  
  
            } catch {}
  
  
          }, lib.convertTick(0.1))
  
  
        })
        player.runCommandAsync("inputpermission set @s movement enabled")
        lib.setScore(player, "res_cur", lib.getScore(player, "res_base"))
  
  
      })
  
  
    }, lib.convertTick(10))


  })


})

lib.itemUse("lian:skills.3.5", function(player, item) {

  lib.conditionSkill(player, 350, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.3.5", player.selectedSlot, 10)
    const player2 = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 30, minDistance: 0, type: "minecraft:player", tags: ["ownerExpansion"], excludeNames: [player.nameTag]})
    if (player2[0] && player.getDynamicProperty("domain") === 0) {
      
      if (player2[0].getDynamicProperty("clash") === 0) {
  
        player.runCommandAsync("camera @s set minecraft:third_person"); player2[0].runCommandAsync("camera @s set minecraft:third_person"); player.setDynamicProperty("clasHits", 0); player.setDynamicProperty("clashStage", 0)
        player2[0].setDynamicProperty("clasHits", 0); player2[0].setDynamicProperty("clashStage", 0); player.runCommandAsync("inputpermission set @s camera disabled"); player.runCommandAsync("inputpermission set @s movement disabled")
        player2[0].runCommandAsync("inputpermission set @s camera disabled"); player2[0].runCommandAsync("inputpermission set @s movement disabled")
        player.runCommandAsync("camerashake add @s 0.3 15 positional"); player2[0].runCommandAsync("camerashake add @s 0.3 15 positional")
        lib.setScore(player, "res_cur", 1000); lib.setScore(player2[0], "res_cur", 1000)
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(0))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(2))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(4))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(6))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(8))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(10))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(12))
        mc.system.runTimeout(() => {player.setDynamicProperty("clash", 0); player2[0].setDynamicProperty("clash", 0); lib.open(player, lib.skills[2].itemsId)}, lib.convertTick(12))
  
  
      } else {
  
        lib.hitUi(player, "§cWait for the clash to end")
  
  
      }
  
  
    } else {expansion(player)}


  })


})
function clash(players) {

  if (players[0].getDynamicProperty("clashStage") >= 6 || players[1].getDynamicProperty("clashStage") >= 6) {

   if (players[0].getDynamicProperty("clasHits") > players[1].getDynamicProperty("clasHits")) {

     lib.hitUi(players[0], "Player " + players[0].nameTag + " won!")
     lib.hitUi(players[1], "Player " + players[0].nameTag + " won!")
     players[0].setDynamicProperty("domain", 0)
     players[1].setDynamicProperty("domain", 1)
     lib.removeExpansion(players[1], "lian:skills.3.5")
     mc.system.runTimeout(() => {expansion(players[0])}, lib.convertTick(2))


   } else if (players[0].getDynamicProperty("clasHits") < players[1].getDynamicProperty("clasHits")) {

     lib.hitUi(players[0], "Player " + players[1].nameTag + " won!")
     lib.hitUi(players[1], "Player " + players[1].nameTag + " won!")
     lib.delayItem(players[0], "lian:skills.2.6", 8, 100)
     players[0].setDynamicProperty("domain", 0)
     players[1].setDynamicProperty("domain", 1)


   } else {

     lib.hitUi(players[0], "A tie!!")
     lib.hitUi(players[1], "A tie!!")
     players[1].setDynamicProperty("domain", 1)
     players[0].setDynamicProperty("domain", 0)
     lib.removeExpansion(players[1], "lian:skills.3.5")
     lib.delayItem(players[0], "lian:skills.2.6", 8, 100)
     lib.delayItem(players[1], "lian:skills.2.6", 8, 100)


   }
   players[0].runCommandAsync("inputpermission set @s camera enabled")
   players[0].runCommandAsync("inputpermission set @s movement enabled")
   players[1].runCommandAsync("inputpermission set @s camera enabled")
   players[1].runCommandAsync("inputpermission set @s movement enabled")
   lib.setScore(players[0], "res_cur", lib.getScore(players[0], "res_base"))
   lib.setScore(players[1], "res_cur", lib.getScore(players[1], "res_base"))
   players[0].runCommandAsync("camera @s clear")
   players[1].runCommandAsync("camera @s clear")


  } else {

   let random1 = lib.random(5, 8); let random2 = lib.random(5, 8); let random3 = lib.random(5, 8); let random4 = lib.random(5, 8)
   for (let i = 0; random1 === random2 || random1 === random3 || random1 === random4; i++) {random1 = lib.random(5, 8)}
   for (let i = 0; random2 === random1 || random2 === random3 || random2 === random4; i++) {random2 = lib.random(5, 8)}
   for (let i = 0; random3 === random2 || random3 === random1 || random3 === random4; i++) {random3 = lib.random(5, 8)}
   for (let i = 0; random4 === random2 || random4 === random3 || random4 === random1; i++) {random4 = lib.random(5, 8)}
   for (let i = 0; i < 2; i++) {

     players[i].playSound("note.bell")
     !players[i].getDynamicProperty("clashNumber") ? players[i].setDynamicProperty("clashNumber", 0): null
     !players[i].getDynamicProperty("clasHits") ? players[i].setDynamicProperty("clasHits", 1): null;
     !players[i].getDynamicProperty("clashStage") ? players[i].setDynamicProperty("clashStage", 0): null; players[i].setDynamicProperty("clashStage", players[i].getDynamicProperty("clashStage") + 1)
     players[i].setDynamicProperty("clashNumber", lib.random(1, 4))
     players[i].setDynamicProperty("clash", 1)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random1} lian:skills.clash.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random2} lian:skills.clash.2 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random3} lian:skills.clash.3 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random4} lian:skills.clash.4 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)

   
   }

  }


}
function expansion(player) {

 !player.getDynamicProperty("domain") ? player.setDynamicProperty("domain", 0): null
 if (player.getDynamicProperty("domain") === 0) {
   
   player.setDynamicProperty("domain", 1)
   player.playAnimation("animation.player.skills.3.5"); mc.world.playSound("skills.3.5.1", player.location, {pitch: 1, volume: 10.0})
   player.addTag("ownerExpansion")
   const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 15, minDistance: 0, type: "minecraft:player"})
   players.forEach(a => {
   
     a.runCommandAsync("execute as @s at @a[name=\"" + player.nameTag + "\"] run camera @s set minecraft:free ease 1 linear pos ^^1.8^2 facing ~~1.5~")
     lib.subtitle(a, "Domain expansion...")
     a.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.1)
     a.runCommandAsync("inputpermission set @s camera disabled")
     a.runCommandAsync("inputpermission set @s movement disabled")
     lib.setScore(a, "res_cur", 1000)
     a.setDynamicProperty("scene", 1)
 
   
   })
   mc.system.runTimeout(() => {

    mc.system.runTimeout(() => {
               
      players.forEach(a => {
     
        a.runCommandAsync("execute as @s at @a[name=\"" + player.nameTag + "\"] run camera @s set minecraft:free ease 0 linear pos ^^1.8^2 facing ~~1.5~")
        lib.subtitle(a, "Muryou Kuusho...")
        a.runCommandAsync("inputpermission set @s camera disabled")
        a.runCommandAsync("inputpermission set @s movement disabled")
        lib.setScore(a, "res_cur", 1000)
        a.setDynamicProperty("scene", 1)
    
      
      })
          
          
    }, lib.convertTick(1))
     player.runCommandAsync("execute positioned ~ 199 ~ run fill ~15~~15 ~-15~~-15 lian:void_expansion.invisible").then(() => {

       player.runCommandAsync("execute positioned ~ 200 ~ run structure load domain.gojo.2 ~-15 ~-15 ~-15 0_degrees none layer_by_layer 0 false")
       mc.system.runTimeout(() => {
               
        const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 15, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
        entities.forEach(entity => {
    
          entity.setDynamicProperty("locAfterDomainX", entity.location.x)
          entity.setDynamicProperty("locAfterDomainY", entity.location.y)
          entity.setDynamicProperty("locAfterDomainZ", entity.location.z)
          entity.setDynamicProperty("locationDomain", {x: entity.location.x, y: 200, z: entity.location.z})
          entity.removeTag("isInExpansionTerrain")
          entity.teleport({x: entity.location.x, y: 201, z: entity.location.z})
          entity.typeId === "minecraft:player" ? (entity.runCommandAsync("camera @s fade time 0 1 7 color 0 0 0"), entity.runCommandAsync("fog @s push lian:gojo domainFog"), entity.removeTag("breacksBlock")): null
          entity.addTag("isInExpansion")
          entity.nameTag !== player.nameTag ? entity.setDynamicProperty("domain", 0): null
 
  
        })
        player.runCommandAsync("event entity @e[r=100] expansion.kill")
        players.forEach(a => {
     
          a.runCommandAsync("execute as @s at @a[name=\"" + player.nameTag + "\"] run camera @s set minecraft:free ease 0 linear pos ~2~1.8~ facing ~~1.5~")
          a.runCommandAsync("inputpermission set @s camera disabled")
          a.runCommandAsync("inputpermission set @s movement disabled")
          lib.setScore(a, "res_cur", 1000)
          a.setDynamicProperty("scene", 1)
      
        
        })
        mc.system.runTimeout(() => {
               
          player.runCommandAsync("execute positioned " + player.getDynamicProperty("locAfterDomainX") + " 200 " + player.getDynamicProperty("locAfterDomainZ") + " run particle lian:skills.3.5.1")
          players.forEach(a => {
         
            a.playSound("skills.3.5.2")
            a.runCommandAsync("execute positioned " + player.getDynamicProperty("locAfterDomainX") + " 200 " + player.getDynamicProperty("locAfterDomainZ") + " run camera @s set minecraft:free ease 1 linear pos ~10~2~ facing ~~1.5~")
            a.runCommandAsync("camerashake add @s 0.7 10 positional")
            a.runCommandAsync("inputpermission set @s camera disabled")
            a.runCommandAsync("inputpermission set @s movement disabled")
            lib.setScore(a, "res_cur", 1000)
            a.setDynamicProperty("scene", 1)
        
          
          })
          mc.system.runTimeout(() => {

            players.forEach(a => {a.runCommandAsync("camera @s fade time 0 3 5 color 0 0 0")})
            const visual = player.dimension.spawnEntity("lian:skills.3.5", {x: player.location.x, y: 201, z: player.location.z})
            visual.nameTag = "expansionOf." + player.nameTag
                
                
          }, lib.convertTick(8))
          mc.system.runTimeout(() => {

            players.forEach(a => {
           
              a.playSound("skills.3.5.3")
              a.runCommandAsync("camera @s clear")
              a.runCommandAsync("inputpermission set @s camera enabled")
              a.runCommandAsync("inputpermission set @s movement enabled")
              lib.setScore(a, "res_cur", lib.getScore(a, "res_base"))
              a.setDynamicProperty("scene", 0)
          
            
            })
            const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 15, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
                
                
          }, lib.convertTick(10))
              
              
        }, lib.convertTick(2))
            
            
      }, lib.convertTick(4))
       player.setDynamicProperty("domainIs", 1)
   
   
     })


   }, lib.convertTick(3))


 } else if (player.getDynamicProperty("domain") === 1) {
   
   lib.delayItem(player, "lian:skills.3.5", player.selectedSlot, 40)
   player.setDynamicProperty("domain", 0)
   player.runCommandAsync("execute positioned " + player.getDynamicProperty("locAfterDomainX") + " 200 " + player.getDynamicProperty("locAfterDomainZ") + " run structure load domain.erase ~-15 ~-15 ~-15").then(() => {

     const entities = player.dimension.getEntities({location: {x: player.getDynamicProperty("locAfterDomainX"), y: player.location.y, z: player.getDynamicProperty("locAfterDomainZ")}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
     entities.forEach(entity => {
 
       entity.removeTag("isInExpansion")
       entity.removeTag("ownerExpansion")
       entity.getDynamicProperty("locAfterDomainY") ? entity.teleport({x: entity.getDynamicProperty("locAfterDomainX"), y: entity.getDynamicProperty("locAfterDomainY"), z: entity.getDynamicProperty("locAfterDomainZ")}): null
       entity.typeId === "minecraft:player" ? (entity.runCommandAsync("camera @s fade time 0 0 1 color 0 0 0"), entity.runCommandAsync("fog @s remove domainFog"), entity.addTag("breacksBlock")): null
 
 
     })
     player.setDynamicProperty("domainIs", 0)
     player.setDynamicProperty("multiplier", 1)
 
 
   })


 }



}
mc.system.runInterval(() => {

  for (const player of mc.world.getPlayers()) {

    if (player.hasTag("ownerExpansion") && player.getDynamicProperty("skill") === 3 && lib.getScore(player, "energy_cur") >= (lib.getScore(player, "energy_base") / 100 * 1)) {player.getDynamicProperty("scene") === 0 ? lib.setScore(player, "energy_cur", lib.clamp(lib.getScore(player, "energy_cur") - Math.round(lib.getScore(player, "energy_base") / 100 * 1), 0, lib.getScore(player, "energy_base"))): null}


  }


}, lib.convertTick(1))
lib.tick((player) => {

  if (player.hasTag("ownerExpansion") && player.getDynamicProperty("skill") === 3) {
    
    if (lib.getScore(player, "energy_cur") >= (lib.getScore(player, "energy_base") / 100 * 1)) {
      

      player.getDynamicProperty("scene") === 0 ? lib.setScore(player, "energy_cur", lib.clamp(lib.getScore(player, "energy_cur") - Math.round(lib.getScore(player, "energy_base") / 100 * 0.3), 0, lib.getScore(player, "energy_base"))): null
      const entities = player.dimension.getEntities({location: {x: player.getDynamicProperty("locAfterDomainX"), y: player.location.y, z: player.getDynamicProperty("locAfterDomainZ")}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"], excludeNames: [player.nameTag]})
      entities.forEach(entity => {
        
        if (!entity.getDynamicProperty("simpleDomain")) {

          try {entity.teleport(entity.getDynamicProperty("locationDomain"))} catch {}


        }
      
      
      })
      player.setDynamicProperty("multiplier", 2)

    } else {

      lib.hitUi(player, "§chas no energy...")
      player.playSound("note.bass")
      lib.delayItem(player, "lian:skills.3.5", 8, 40)
      player.setDynamicProperty("domain", 0)
      player.runCommandAsync("execute positioned " + player.getDynamicProperty("locAfterDomainX") + " 200 " + player.getDynamicProperty("locAfterDomainZ") + " run structure load domain.erase ~-15 ~-15 ~-15").then(() => {
   
        const entities = player.dimension.getEntities({location: {x: player.getDynamicProperty("locAfterDomainX"), y: player.location.y, z: player.getDynamicProperty("locAfterDomainZ")}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
        entities.forEach(entity => {
    
          entity.removeTag("isInExpansion")
          entity.removeTag("ownerExpansion")
          entity.getDynamicProperty("locAfterDomainY") ? entity.teleport({x: entity.getDynamicProperty("locAfterDomainX"), y: entity.getDynamicProperty("locAfterDomainY"), z: entity.getDynamicProperty("locAfterDomainZ")}): null
          entity.typeId === "minecraft:player" ? (entity.runCommandAsync("camera @s fade time 0 0 1 color 0 0 0"), entity.runCommandAsync("fog @s remove domainFog"), entity.addTag("breacksBlock")): null
    
    
        })
        player.setDynamicProperty("domainIs", 0)
        player.setDynamicProperty("multiplier", 1)
    
    
      })


    }


  }

})