import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:skills.4.open" && data.source.hasTag("pvp")) {mc.system.run(() => {

    data.source.setDynamicProperty("skill", 4)
    lib.setScore(data.source, "mode", 4)
    lib.open(data.source, lib.skills[4].itemsId)
  
  
  })}
  else if (data.itemStack.typeId == "lian:skills.load" && data.source.getDynamicProperty("clash") === 0) {mc.system.run(() => {lib.close(data.source); data.source.setDynamicProperty("skill", 0); lib.setScore(data.source, "mode", 0)})}
  
  
})

lib.itemUse("lian:skills.4.1", function(player, item) {

  lib.conditionSkill(player, 0, 2, (player) => {

    const entities = player.getEntitiesFromViewDirection({maxDistance: 20})
    if (!entities[0]) {lib.aiming(player, "§cNo entities around"); player.playSound("note.bass")} else {
  
      lib.delayItem(player, "lian:skills.4.1", player.selectedSlot, 8)
      const loc = player.dimension.spawnEntity("lian:entity.ride", player.location)
      loc.nameTag = "insured." + player.nameTag
      entities.forEach(hit => {
        
        hit.entity.addTag("insured")
        const tick = mc.system.runInterval(() => {
  
          hit.entity.hasTag("insured") ? hit.entity.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] run teleport @s ^^0.2^1"): null
          player.playAnimation("animation.player.skills.4.1.4")
  
  
        }, lib.convertTick(0.1))
        mc.system.runTimeout(() => {
          
          hit.entity.removeTag("insured"); mc.system.clearRun(tick)
          mc.system.runTimeout(() => {entity.applyDamage(lib.getScore(player, "str_cur") * 2.5, {damagingEntity: player, cause: "entityAttack"}); player.playAnimation("animation.player.skills.4.1." + lib.random(1, 3)); hit.entity.runCommandAsync("particle lian:skills.4.1 ^^1^"); hit.entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 8, 0.2)}, lib.convertTick(0.2))
          mc.world.playSound("explode", player.location, {pitch: lib.random(8, 15) / 10, volume: 1.0})
  explode
        
        }, lib.convertTick(5))
      
      
      })
  
  
    }


  })


})
lib.itemHitEntity("lian:skills.4.1", function(player, entity) {

  lib.conditionSkill(player, 0, 1, (player) => {

    lib.delayItem(player, "lian:skills.4.1", player.selectedSlot, 1)
    entity.runCommandAsync("particle lian:skills.4.1 ^^1^")
    entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 7, 0.2)
    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, -1, 0.2)
    entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "entityAttack"})
    lib.hitUi(player, "Strong punch")
    player.playAnimation("animation.player.skills.4.1." + lib.random(1, 3))
    mc.world.playSound("explode", player.location, {pitch: lib.random(8, 15) / 10, volume: 1.0})


  })


})

lib.itemUse("lian:skills.4.2", function(player, item) {
  
  lib.conditionSkill(player, 0, 2, (player) => {

    const entities = player.getEntitiesFromViewDirection({maxDistance: 100})
    if (entities[0]) {
      
      lib.delayItem(player, "lian:skills.4.3", player.selectedSlot, 0.3)
      entities.forEach(hit => {
        
        player.runCommandAsync("particle lian:skills.4.1 ^^1^")
        player.runCommandAsync("camera @s set minecraft:third_person"); mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
        player.playAnimation("animation.player.skills.4.2.2")
        mc.system.runTimeout(() => {
  
          player.teleport(hit.entity.location)
          player.runCommandAsync("tp ^^^")
          hit.entity.runCommandAsync("particle lian:skills.4.1 ^^1^")
          hit.entity.applyDamage(lib.getScore(player, "str_cur") * 5, {damagingEntity: player, cause: "entityAttack"})
          hit.entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 15, 0.2)
          mc.world.playSound("explode", player.location, {pitch: lib.random(8, 15) / 10, volume: 1.0})
          lib.hitUi(player, "Drag")
  
  
        }, lib.convertTick(0.2))
      
      
      })} else {
        
        lib.aiming(player, "§cNo entities around"); lib.delayItem(player, "lian:skills.4.1", player.selectedSlot, 0.3); player.playSound("note.bass")
      
      
      }


  })


})
lib.itemUse("lian:skills.4.3", function(player, item) {
  
  lib.conditionSkill(player, 0, 2, (player) => {

    !player.getDynamicProperty("punch") ? player.setDynamicProperty("punch", 1): null
    player.runCommandAsync("inputpermission set @s movement disabled")
    const loc = player.dimension.spawnEntity("lian:entity.null", player.location)
    loc.nameTag = "skills.4.3." + player.nameTag
    lib.delayItem(player, "lian:skills.4.3", player.selectedSlot, 20)
    const tick = mc.system.runInterval(() => {
  
      mc.world.playSound("explode", player.location, {pitch: lib.random(8, 15) / 10, volume: 1.0})
      player.getDynamicProperty("punch") === 1 ? player.setDynamicProperty("punch", 2): player.setDynamicProperty("punch", 1)
      player.playAnimation("animation.player.skills.4.3." + player.getDynamicProperty("punch"))
      player.runCommandAsync("particle lian:skills.4.1 ^" + lib.random(15, -15) / 10 + "^" + lib.random(15, 0) / 10 + "^1")
      loc.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] run tp @s ^^^1").then(() => {
  
        const entities = loc.dimension.getEntities({location: {x: loc.location.x, y: loc.location.y, z: loc.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], excludeTypes: ["orb", "item"]})
        entities.forEach(entity => {
  
          entity.applyDamage(lib.getScore(player, "str_cur") * 0.7, {damagingEntity: player, cause: "entityAttack"})
          entity.applyKnockback(lib.random(180, -180), lib.random(180, -180), lib.random(-10, 10) / 10, lib.random(0.1, 1) / 10)
  
  
        })
  
  
      })
  
  
    }, lib.convertTick(0.05))
    mc.system.runTimeout(() => {mc.system.clearRun(tick); player.runCommandAsync("inputpermission set @s movement enabled")}, lib.convertTick(2))


  })


})

//

mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entity = event.hitEntity; const entityLocation = {x: entity.location.x, y: entity.location.y, z: entity.location.z}
  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.4.2") {

    lib.conditionSkill(player, 0, 1, (player) => {

      lib.delayItem(player, "lian:skills.4.2", player.selectedSlot, 3)
      entity.runCommandAsync("particle lian:skills.4.1 ^^1^")
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 1.3)
      player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, -1, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 4, {damagingEntity: player, cause: "entityAttack"})
      lib.hitUi(player, "Hit up")
      player.playAnimation("animation.player.skills.4.2")
      mc.world.playSound("explode", player.location, {pitch: lib.random(8, 15) / 10, volume: 1.0})
      player.runCommandAsync("camera @s set minecraft:third_person"); mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))


    })


  }


})