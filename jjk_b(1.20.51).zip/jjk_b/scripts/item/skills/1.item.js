import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.afterEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:skills.1.open" && data.source.hasTag("pvp")) {mc.system.run(() => {

    data.source.setDynamicProperty("skill", 1)
    lib.setScore(data.source, "mode", 0)
    lib.open(data.source, lib.skills[1].itemsId)
  
  
  })}
  else if (data.itemStack.typeId == "lian:skills.load" && data.source.getDynamicProperty("clash") === 0) {mc.system.run(() => {lib.close(data.source); data.source.setDynamicProperty("skill", 0)})}
  
  
})

lib.itemUse("lian:skills.1.1", function(player, item) {

  lib.conditionSkill(player, 10, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.1.1", player.selectedSlot, 5)
    const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, minDistance: 0, maxDistance: 15, excludeFamilies: ["not"], excludeTypes: ["orb", "item"], excludeNames: [player.nameTag]})
    if (entities[0]) {
  
      const entity = entities[lib.random(0, entities.length - 1)]
      const loc = player.dimension.spawnEntity("lian:text", {x: player.location.x, y: player.location.y, z: player.location.z})
    
      player.playAnimation("animation.skills.1.all")
      mc.system.runTimeout(() => {
  
        player.teleport({x: entity.location.x, y: entity.location.y, z: entity.location.z})
        if (entity.typeId === "minecraft:player") {lib.hitUi(player, "Exchanged with " + entity.nameTag); lib.hitUi(entity, "Exchanged with " + player.nameTag)} else {lib.hitUi(player, "Exchanged with " + entity.typeId)}
        entity.teleport({x: loc.location.x, y: loc.location.y, z: loc.location.z})
        loc.remove()  
  
  
      }, lib.convertTick(0.3))
      
  
    } else {lib.hitUi(player, "§cThere is no one within 15 blocks"); player.playSound("note.bass")}


  })


})
mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entity = event.hitEntity; const entityLocation = {x: entity.location.x, y: entity.location.y, z: entity.location.z}
  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.1.1") {
      
    !player.getDynamicProperty("skills.1.1") ? player.setDynamicProperty("skills.1.1", 0): null
    if (player.getDynamicProperty("skills.1.1") === 0) {

      lib.conditionSkill(player, 30, 1, (player) => {

        player.setDynamicProperty("skills.1.1", 1); lib.delayItem(player, "lian:skills.1.1", player.selectedSlot, 0.3)
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0)
        player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 2, 0.2)
        entity.runCommand("damage @s " + parseInt(lib.getScore(player, "str_cur") * 1) + " entity_attack entity " + player.nameTag)
        mc.system.runTimeout(() => {
        
          player.playAnimation("animation.skills.1.all")
          mc.system.runTimeout(() => {
          
            const loc = player.dimension.spawnEntity("lian:text", {x: player.location.x, y: player.location.y, z: player.location.z})
            player.teleport({x: entity.location.x, y: entity.location.y, z: entity.location.z})
            entity.teleport({x: loc.location.x, y: loc.location.y, z: loc.location.z})
            loc.remove()
            mc.system.runTimeout(() => {player.runCommandAsync("tp ~~~ ~180~")}, lib.convertTick(0.1))
        
        
          }, lib.convertTick(0.25))


        }, lib.convertTick(0.2))


      })


    } else if (player.getDynamicProperty("skills.1.1") === 1) {

      lib.conditionSkill(player, 30, 1, (player) => {

        player.setDynamicProperty("skills.1.1", 2); lib.delayItem(player, "lian:skills.1.1", player.selectedSlot, 0.3)
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0)
        player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 2, 0.2)
        entity.runCommand("damage @s " + parseInt(lib.getScore(player, "str_cur") * 1.5) + " entity_attack entity " + player.nameTag)
        mc.system.runTimeout(() => {
        
          player.playAnimation("animation.skills.1.all")
          mc.system.runTimeout(() => {
          
            const loc = player.dimension.spawnEntity("lian:text", {x: player.location.x, y: player.location.y, z: player.location.z})
            player.teleport({x: entity.location.x, y: entity.location.y, z: entity.location.z})
            entity.teleport({x: loc.location.x, y: loc.location.y, z: loc.location.z})
            loc.remove()
            mc.system.runTimeout(() => {player.runCommandAsync("tp ~~~ ~180~")}, lib.convertTick(0.1))
        
        
          }, lib.convertTick(0.25))


        }, lib.convertTick(0.2))


      })


    } else if (player.getDynamicProperty("skills.1.1") === 2) {

      lib.conditionSkill(player, 30, 1, (player) => {

        player.setDynamicProperty("skills.1.1", 0); lib.delayItem(player, "lian:skills.1.1", player.selectedSlot, 3)
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0)
        player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 2, 0.2)
        entity.runCommand("damage @s " + parseInt(lib.getScore(player, "str_cur") * 2) + " entity_attack entity " + player.nameTag)
        entity.dimension.createExplosion(entity.location, 0.1, {breaksBlocks: false, source: player})
        mc.system.runTimeout(() => {
        
          player.playAnimation("animation.skills.1.all")
          mc.system.runTimeout(() => {
          
            const loc = player.dimension.spawnEntity("lian:text", {x: player.location.x, y: player.location.y, z: player.location.z})
            player.teleport({x: entity.location.x, y: entity.location.y, z: entity.location.z})
            entity.teleport({x: loc.location.x, y: loc.location.y, z: loc.location.z})
            loc.remove()
            mc.system.runTimeout(() => {player.runCommandAsync("tp ~~~ ~180~")}, lib.convertTick(0.1))
        
        
          }, lib.convertTick(0.25))


        }, lib.convertTick(0.2))


      })


    }
    

  }


})

lib.itemUse("lian:skills.1.2", function(player, item) {

  player.playSound("note.hat"); lib.delayItem(player, "lian:skills.1.2", player.selectedSlot, 10); lib.hitUi(player, "Reseted marks")
  const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, excludeFamilies: ["not"]})
  entities.forEach(entity => {

    if (entity.getDynamicProperty("boogieWoogieSelectOne." + player.nameTag) === true) {

      entity.setDynamicProperty("boogieWoogieSelectOne." + player.nameTag, false)


    }
    if (entity.getDynamicProperty("PlayerBoogieWoogieSelectOne") === true) {

      player.setDynamicProperty("PlayerBoogieWoogieSelectOne", false)


    }
    if (entity.getDynamicProperty("boogieWoogieSelectTwo." + player.nameTag) === true) {

      entity.setDynamicProperty("boogieWoogieSelectTwo." + player.nameTag, false)


    }
    if (entity.getDynamicProperty("PlayerBoogieWoogieSelectTwo") === true) {

      player.setDynamicProperty("PlayerBoogieWoogieSelectTwo", false)


    }


  })

})

lib.itemUse("lian:skills.1.4", function(player, item) {

  lib.conditionSkill(player, 20, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.1.4", player.selectedSlot, 1)
    player.playAnimation("animation.skills.1.all")
    mc.system.runTimeout(() => {
      
      const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, excludeFamilies: ["not"]})
      entities.forEach(entity => {
        
        if (entity.getDynamicProperty("boogieWoogieSelectOne." + player.nameTag) === true) {
          
          const loc = player.dimension.spawnEntity("lian:text", {x: player.location.x, y: player.location.y, z: player.location.z})
          player.teleport({x: entity.location.x, y: entity.location.y, z: entity.location.z})
          entity.teleport({x: loc.location.x, y: loc.location.y, z: loc.location.z})
          loc.remove()
          lib.hitUi(player, "Exchanged with brand one")
        
        
        } else {
          
          lib.hitUi(player, "§cThere is no brand")
        
        
        }
      
      
      })
    
    
    }, lib.convertTick(0.25))


  })


})

lib.itemUse("lian:skills.1.6", function(player, item) {

  lib.conditionSkill(player, 25, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.1.4", player.selectedSlot, 1)
    player.playAnimation("animation.skills.1.all")
    mc.system.runTimeout(() => {
      
      const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, excludeFamilies: ["not"]})
      entities.forEach(entity => {
        
        if (entity.getDynamicProperty("boogieWoogieSelectOne." + player.nameTag) === true) {
          
          const loc = player.dimension.spawnEntity("lian:text", {x: player.location.x, y: player.location.y, z: player.location.z})
          player.teleport({x: entity.location.x, y: entity.location.y, z: entity.location.z})
          entity.teleport({x: loc.location.x, y: loc.location.y, z: loc.location.z})
          loc.remove()
          lib.hitUi(player, "Exchanged with brand one")
        
        
        } else {
          
          lib.hitUi(player, "§cThere is no brand")
        
        
        }
      
      
      })
    
    
    }, lib.convertTick(0.25))


  })


})

lib.itemUse("lian:skills.1.7", function(player, item) {

  lib.conditionSkill(player, 30, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.1.7", player.selectedSlot, 5)
    player.playAnimation("animation.skills.1.all")
    mc.system.runTimeout(() => {
      
      const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, excludeFamilies: ["not"]})
      entities.forEach(entity => {
  
        if (entity.getDynamicProperty("boogieWoogieSelectOne." + player.nameTag) === true) {
          
          entities.forEach(entity2 => {
            
            if (entity2.getDynamicProperty("boogieWoogieSelectTwo." + player.nameTag) === true) {
              
              const loc = entity.dimension.spawnEntity("lian:text", {x: entity.location.x, y: entity.location.y, z: entity.location.z})
              entity.teleport({x: entity2.location.x, y: entity2.location.y, z: entity2.location.z})
              entity2.teleport({x: loc.location.x, y: loc.location.y, z: loc.location.z})
              loc.remove()
              lib.hitUi(player, "Exchanged with brand one")
            
            
            } 
          
          
          })
        
        
        } else {
  
          lib.hitUi(player, "§cThere is no brand")
        
        
        }
      
      
      })
    
    
    }, lib.convertTick(0.25))


  })


})

mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entity = event.hitEntity; const entityLocation = {x: entity.location.x, y: entity.location.y, z: entity.location.z}
  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.1.4") {
      
    if (!player.getDynamicProperty("PlayerBoogieWoogieSelectOne") || player.getDynamicProperty("PlayerBoogieWoogieSelectOne") === false) {

      if (entity.typeId === "minecraft:player") {
      
        lib.hitUi(entity, "Vou were tagged by " + player.nameTag)
        entity.playSound("note.bass")
  
  
      }
      lib.hitUi(player, "Mark one " + entity.nameTag)
      player.playSound("note.banjo")
      entity.setDynamicProperty("boogieWoogieSelectOne." + player.nameTag, true)
      player.setDynamicProperty("PlayerBoogieWoogieSelectOne", true)
      mc.system.runTimeout(() => {
  
        lib.hitUi(player, "§cMarking one was lost")
        player.playSound("note.bass")
        entity.setDynamicProperty("boogieWoogieSelectOne." + player.nameTag, false)
        player.setDynamicProperty("PlayerBoogieWoogieSelectOne", false)
  
  
      }, lib.convertTick(50))

      
    } else {

      lib.hitUi(player, "§cAlready have an appointment")
      player.playSound("note.bass")


    }
    

  } else  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.1.6") {
      
    if (!player.getDynamicProperty("PlayerBoogieWoogieSelectTwo") || player.getDynamicProperty("PlayerBoogieWoogieSelectTwo") === false) {

      if (entity.typeId === "minecraft:player") {
      
        lib.hitUi(entity, "Vou were tagged by " + player.nameTag)
        entity.playSound("note.bass")
  
  
      }
      lib.hitUi(player, "Mark two " + entity.nameTag)
      player.playSound("note.banjo")
      entity.setDynamicProperty("boogieWoogieSelectTwo." + player.nameTag, true)
      player.setDynamicProperty("PlayerBoogieWoogieSelectTwo", true)
      mc.system.runTimeout(() => {
  
        lib.hitUi(player, "§cMarking two was lost")
        player.playSound("note.bass")
        entity.setDynamicProperty("boogieWoogieSelectTwo." + player.nameTag, false)
        player.setDynamicProperty("PlayerBoogieWoogieSelectTwo", false)
  
  
      }, lib.convertTick(50))

      
    } else {

      lib.hitUi(player, "§cAlready have an appointment")
      player.playSound("note.bass")


    }
    

  }


})