import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../../lib.js";
lib.tick((player) => {

  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.extra.3") {
    
    if (lib.getScore(player, "energy_cur") >= 2) {
      
      player.playAnimation("animation.player.skills.extra.3")
      lib.setScore(player, "energy_cur", lib.getScore(player, "energy_cur") - 2)


    } else {

      lib.hitUi(player, "§chas no energy...")
      player.playSound("note.bass")
      player.setDynamicProperty("divergentHits", 0)
      lib.delayItem(player, "lian:skills.extra.3", player.selectedSlot, 20, false)


    }


  }


}, 5)
mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entity = event.hitEntity; const entityLocation = {x: entity.location.x, y: entity.location.y, z: entity.location.z}
  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.extra.3") {

    entity.runCommand("damage @s " + (lib.getScore(player, "str_cur") * 1) + " entity_attack entity " + player.nameTag)
    

  }


})