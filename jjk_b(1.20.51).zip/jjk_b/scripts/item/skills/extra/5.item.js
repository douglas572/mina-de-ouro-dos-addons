import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../../lib.js";
lib.tick(function(player) {

  lib.item(player, {

    id: "lian:skills.extra.5",
    slots: [{

      type: 1, id: 1, delay: 0, charge: 1, state: function() {
        
        player.runCommandAsync("camera @s set minecraft:third_person"); mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(3))
        player.playSound("note.hat"); lib.delayItem(player, "lian:skills.extra.5", player.selectedSlot, 3, false)
        player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 10, 0.2)
        player.playAnimation("animation.player.skills.dash")
        // player.setProperty("lian:particle", 100)


      }


    }],
    events: {

      noTime: function(player) {player.sendMessage("")},
      noCharge: function(player) {player.sendMessage("")}


    }


  })

}, 1)