import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../../lib.js";
lib.itemUse("lian:skills.extra.4", (player) => {

  lib.conditionSkill(player, 500, 0, function() {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.extra.4", player.selectedSlot, 25, false); lib.hitUi(player, "40% of total health restored")

    const life = player.getComponent("minecraft:health").currentValue + parseInt(player.getComponent("minecraft:health").defaultValue / 100 * 40)
    player.getComponent("minecraft:health").setCurrentValue(life)

    const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (lib.random(-100, 100) / 100), y: player.location.y + (1 + (lib.random(-100, 100) / 100)), z: player.location.z + (lib.random(-100, 100) / 100)})
    display.nameTag = `§a+${parseInt(life) - player.getComponent("minecraft:health").currentValue}`

    player.runCommandAsync("particle lian:skills.extra.4")
    


  })


})