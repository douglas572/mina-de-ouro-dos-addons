import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../../lib.js";
mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entity = event.hitEntity; const entityLocation = {x: entity.location.x, y: entity.location.y, z: entity.location.z}
  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.extra.1") {

    !player.getDynamicProperty("skills.extra.1") ? player.setDynamicProperty("skills.extra.1", 0): null
    if (player.getDynamicProperty("skills.extra.1") === 0 && lib.getScore(player, "energy_cur") >= 110) {

      lib.getScore(player, "energy_base") >= 120 ? player.setDynamicProperty("skills.extra.1", 1): player.setDynamicProperty("skills.extra.1", 0); lib.delayItem(player, "lian:skills.extra.1", player.selectedSlot, 1, false)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 2, 0.2)
      player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 2, 0.2)
      mc.world.playSound("explode", entityLocation, {pitch: lib.random(5, 15) / 10, volume: 0.5})
      entity.runCommand("damage @s " + (lib.getScore(player, "str_cur") * 2) + " entity_attack entity " + player.nameTag)
      lib.hitUi(player, "§fHit §c1 20%")
      lib.setScore(player, "energy_cur", lib.getScore(player, "energy_cur") - 110)
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.extra.1")


    } else if (!player.getDynamicProperty("skills.extra.1") || player.getDynamicProperty("skills.extra.1") === 0 && lib.getScore(player, "energy_cur") < 110) {
      
      lib.hitUi(player, "§cIt takes 110 energy")
      player.playSound("note.bass")
      
      
    } else if (player.getDynamicProperty("skills.extra.1") === 1 && lib.getScore(player, "energy_cur") >= 120) {

      lib.getScore(player, "energy_base") >= 140 ? player.setDynamicProperty("skills.extra.1", 2): player.setDynamicProperty("skills.extra.1", 0); lib.delayItem(player, "lian:skills.extra.1", player.selectedSlot, 1, false)
      entity.applyKnockback(event.damagingEntity.getViewDirection().x, event.damagingEntity.getViewDirection().z, 3, 0.3)
      player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 2, 0.2)
      mc.world.playSound("explode", entityLocation, {pitch: 0.6, volume: lib.random(5, 15) / 10})
      entity.runCommand("damage @s " + (lib.getScore(player, "str_cur") * 2) + " entity_attack entity " + player.nameTag)
      lib.hitUi(player, "§fHit §c2 50%")
      lib.setScore(player, "energy_cur", lib.getScore(player, "energy_cur") - 120)
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.extra.1")


    } else if (player.getDynamicProperty("skills.extra.1") === 1 && lib.getScore(player, "energy_cur") < 120) {
      
      lib.hitUi(player, "§cIt takes 120 energy")
      player.playSound("note.bass")
      
      
    } else if (player.getDynamicProperty("skills.extra.1") === 2 && lib.getScore(player, "energy_cur") >= 140) {

      lib.getScore(player, "energy_base") >= 180 ? player.setDynamicProperty("skills.extra.1", 3): player.setDynamicProperty("skills.extra.1", 0); lib.delayItem(player, "lian:skills.extra.1", player.selectedSlot, 1, false)
      entity.applyKnockback(event.damagingEntity.getViewDirection().x, event.damagingEntity.getViewDirection().z, 4, 0.4)
      player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 2, 0.2)
      mc.world.playSound("explode", entityLocation, {pitch: lib.random(5, 15) / 10, volume: 0.5})
      entity.runCommand("damage @s " + (lib.getScore(player, "str_cur") * 2) + " entity_attack entity " + player.nameTag)
      lib.hitUi(player, "§fHit §c3 70%")
      lib.setScore(player, "energy_cur", lib.getScore(player, "energy_cur") - 140)
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(0.5))
      player.playAnimation("animation.player.skills.extra.1")


    } else if (player.getDynamicProperty("skills.extra.1") === 2 && lib.getScore(player, "energy_cur") < 140) {
      
      lib.hitUi(player, "§cIt takes 140 energy")
      player.playSound("note.bass")
      
      
    } else if (player.getDynamicProperty("skills.extra.1") === 3 && lib.getScore(player, "energy_cur") >= 180) {

      player.setDynamicProperty("skills.extra.1", 0); lib.delayItem(player, "lian:skills.extra.1", player.selectedSlot, 25, false)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 20, 0.7)
      player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 5, 0.2)
      mc.world.playSound("explode", entityLocation, {pitch: lib.random(5, 15) / 10, volume: 1.0})
      mc.world.playSound("explode", entityLocation, {pitch: lib.random(5, 15) / 10, volume: 1.0})
      mc.world.playSound("explode", entityLocation, {pitch: lib.random(5, 15) / 10, volume: 1.0})
      entity.runCommand("damage @s " + (lib.getScore(player, "str_cur") * 3) + " entity_attack entity " + player.nameTag)
      lib.hitUi(player, "§fHit §c4 §fPAWNNN! 100%")
      lib.setScore(player, "energy_cur", lib.getScore(player, "energy_cur") - 180)
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.extra.1")


    } else if (player.getDynamicProperty("skills.extra.1") === 3 && lib.getScore(player, "energy_cur") < 180) {
      
      lib.hitUi(player, "§cIt takes 180 energy")
      player.playSound("note.bass")
      
      
    }
    


  }


})