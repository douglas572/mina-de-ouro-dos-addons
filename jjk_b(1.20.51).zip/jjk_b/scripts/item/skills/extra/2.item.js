import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../../lib.js";

lib.tick(function(player) {
  
  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.extra.2") {
    
    if (lib.getScore(player, "energy_cur") >= Math.round(lib.getScore(player, "energy_base") / 100 * 1)) {
    
      lib.setScore(player, "energy_cur", lib.getScore(player, "energy_cur") - Math.round(lib.getScore(player, "energy_base") / 100 * 1))
      player.setProperty("lian:extra", 2); player.setProperty("lian:outline", 1); player.setDynamicProperty("simpleDomain", true)
    
    
    } else {
    
      lib.hitUi(player, "§chas no energy...")
      player.playSound("note.bass")
      lib.delayItem(player, "lian:skills.extra.2", player.selectedSlot, 30, false)
      player.setProperty("lian:extra", 0); player.setProperty("lian:outline", 0); player.setDynamicProperty("simpleDomain", false)
  
    }
  

  
  } else {
    
    player.setProperty("lian:extra", 0); player.setProperty("lian:outline", 0); player.setDynamicProperty("simpleDomain", false)
  
  
  }

}, 1)