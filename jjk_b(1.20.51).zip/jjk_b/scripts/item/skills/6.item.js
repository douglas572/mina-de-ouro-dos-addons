import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";
mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:skills.6.open" && data.source.hasTag("pvp")) {mc.system.run(() => {

    data.source.setDynamicProperty("skill", 6)
    lib.setScore(data.source, "mode", 2)
    lib.open(data.source, lib.skills[6].itemsId)
  
  
  })}
  else if (data.itemStack.typeId == "lian:skills.load" && data.source.getDynamicProperty("clash") === 0) {mc.system.run(() => {lib.close(data.source); data.source.setDynamicProperty("skill", 0); lib.setScore(data.source, "mode", 0)})}
  
  
})

lib.itemHitEntity("lian:skills.6.1", function(player, entity) {

  !player.getDynamicProperty("skills.6.1") ? player.setDynamicProperty("skills.6.1", 0): null
  if (player.getDynamicProperty("skills.6.1") === 0) {

    lib.conditionSkill(player, 20, 1, (player) => {

      player.setDynamicProperty("skills.6.1", 1)
      lib.delayItem(player, "lian:skills.6.1", player.selectedSlot, 0.1)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "entityAttack"})
      lib.hitUi(player, "Cut 1")
      player.playAnimation("animation.player.skills.6.1.1")
      entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      mc.world.playSound("weapon.1.1", player.location, {volume: 10, pitch: lib.random(8, 12) / 10})


    })


  } else if (player.getDynamicProperty("skills.6.1") === 1) {

    lib.conditionSkill(player, 20, 1, (player) => {

      player.setDynamicProperty("skills.6.1", 2)
      lib.delayItem(player, "lian:skills.6.1", player.selectedSlot, 0.1)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "entityAttack"})
      lib.hitUi(player, "Cut 2")
      player.playAnimation("animation.player.skills.6.1.2")
      entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      mc.world.playSound("weapon.1.1", player.location, {volume: 10, pitch: lib.random(12, 18) / 10})


    })
    

  } else if (player.getDynamicProperty("skills.6.1") === 2) {

    lib.conditionSkill(player, 20, 1, (player) => {

      player.setDynamicProperty("skills.6.1", 0)
      lib.delayItem(player, "lian:skills.6.1", player.selectedSlot, 1)
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 6, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 2.5, {damagingEntity: player, cause: "entityAttack"})
      lib.hitUi(player, "Cut 3")
      player.playAnimation("animation.player.skills.6.1.3")
      entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      mc.world.playSound("weapon.1.1", player.location, {volume: 10, pitch: lib.random(18, 25) / 10})


    })


  }
  

})
lib.itemUse("lian:skills.6.2", function(player, item) {

  const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], exclueTypes: ["orb", "item"]})
  !player.getDynamicProperty("skills.6.2") ? player.setDynamicProperty("skills.6.2", 0): null
  if (player.getDynamicProperty("skills.6.2") === 0) {

    lib.conditionSkill(player, 35, 2, (player) => {

      player.setDynamicProperty("skills.6.2", 1); lib.delayItem(player, "skills.6.2", player.selectedSlot, 0.1)
      lib.hitUi(player, "Hit 1")
      mc.system.runTimeout(() => {
  
        mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(10, 17) / 10})
        entities.forEach(entity => {
  
          entity.applyDamage(lib.getScore(player, "str_cur") * 1, {damagingEntity: player, cause: "contact"})
          entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
          entity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
          entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
    
        })
  
  
      }, lib.convertTick(0.2))
      player.playAnimation("animation.player.skills.6.2.1")


    })


  } else if (player.getDynamicProperty("skills.6.2") === 1) {

    lib.conditionSkill(player, 35, 2, (player) => {

      player.setDynamicProperty("skills.6.2", 2); lib.delayItem(player, "skills.6.2", player.selectedSlot, 0.1)
      lib.hitUi(player, "Hit 2")
      mc.system.runTimeout(() => {
  
        mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(17, 20) / 10})
        entities.forEach(entity => {
  
          entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "contact"})
          entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
          entity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
          entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
    
        })
  
  
      }, lib.convertTick(0.2))
      player.playAnimation("animation.player.skills.6.2.2")


    })


  } else if (player.getDynamicProperty("skills.6.2") === 2) {

    lib.conditionSkill(player, 35, 2, (player) => {

      player.setDynamicProperty("skills.6.2", 3); lib.delayItem(player, "skills.6.2", player.selectedSlot, 0.1)
      lib.hitUi(player, "Hit 3")
      mc.system.runTimeout(() => {

        mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(20, 22) / 10})
        entities.forEach(entity => {

          entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "contact"})
          entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
          entity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
          entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
  
        })


      }, lib.convertTick(0.2))
    player.playAnimation("animation.player.skills.6.2.3")


    })


  } else if (player.getDynamicProperty("skills.6.2") === 3) {

    lib.conditionSkill(player, 35, 2, (player) => {

      player.setDynamicProperty("skills.6.2", 0); lib.delayItem(player, "skills.6.2", player.selectedSlot, 3)
      lib.hitUi(player, "Hit 4")
      mc.system.runTimeout(() => {
  
        mc.world.playSound("explode", player.location, {volume: 1.0, pitch: lib.random(8, 10) / 10})
        mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(22, 25) / 10})
        entities.forEach(entity => {
  
          entity.applyDamage(lib.getScore(player, "str_cur") * 2.5, {damagingEntity: player, cause: "contact"})
          entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 12, 0.2)
          entity.runCommandAsync("particle lian:skills.6.2.1 ~~1~")
          entity.runCommandAsync("particle lian:skills.6.2.2 ~~1~")
          entity.runCommandAsync("particle lian:skills.6.2.3 ~~1~")
    
        })
  
  
      }, lib.convertTick(0.2))
      player.playAnimation("animation.player.skills.6.2.4")
      mc.system.runTimeout(() => {player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 2.5, 0.2)}, lib.convertTick(0.3))

      
    })


  }


})

mc.world.afterEvents.entityHitEntity.subscribe(event => {

  const player = event.damagingEntity; const playerLocation = {x: player.location.x, y: player.location.y, z: player.location.z}; const entity = event.hitEntity; const entityLocation = {x: entity.location.x, y: entity.location.y, z: entity.location.z}
  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === "lian:skills.6.2") {

    lib.conditionSkill(player, 80, 1, (player) => {

      lib.delayItem(player, "lian:skills.6.2", player.selectedSlot, 5)
      player.applyKnockback(-player.getViewDirection().x, -player.getViewDirection().z, 0.4, 0.2)
      entity.applyDamage(lib.getScore(player, "str_cur") * 3, {damagingEntity: player, cause: "entityAttack"})
      mc.world.playSound("skills.6.2", entityLocation, {pitch: 1, volume: 1})
      lib.hitUi(player, "Dismantle")
      player.runCommandAsync("camera @s set minecraft:third_person")
      mc.system.runTimeout(() => {player.runCommandAsync("camera @s clear")}, lib.convertTick(1))
      player.playAnimation("animation.player.skills.6.2")
      entity.runCommandAsync("particle lian:skills.6.2 ~~~")
      player.dimension.createExplosion({x: entity.location.x, y: entity.location.y + 2, z: entity.location.z}, 1, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player})
      entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 2, 1.3)


    })


  }


})

lib.itemUse("lian:skills.6.3", function(player, item) {

  lib.conditionSkill(player, 150, 2, (player) => {

    player.runCommandAsync("camera @s clear")
    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.6.3", player.selectedSlot, 1)
    player.playAnimation("animation.player.skills.6.1." + lib.random(1, 1))
    mc.system.runTimeout(() => {
      
      const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
      locate.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^^^0.5 run tp @s ~~~ ~~").then(() => {
  
        const projectile = player.dimension.spawnEntity("lian:skills.6.3", {x: locate.location.x, y: locate.location.y + 1.8, z: locate.location.z})
        projectile.nameTag = player.nameTag
        projectile.setProperty("lian:pivot_x", player.getRotation().x)
        projectile.setProperty("lian:pivot_y", player.getRotation().y)
        projectile.setProperty("lian:pivot_z", lib.random(90, -90))
        projectile.applyImpulse({x: player.getViewDirection().x * 2, y: player.getViewDirection().y  * 2, z: player.getViewDirection().z * 2})
        projectile.setDynamicProperty("initialDirectionX", player.getViewDirection().x); projectile.setDynamicProperty("initialDirectionZ", player.getViewDirection().z)
        const tick = mc.system.runInterval(() => {
  
          mc.world.playSound("weapon.1.1", projectile.location, {volume: 10, pitch: lib.random(8, 12) / 10})
          mc.world.playSound("explode", projectile.location, {volume: 10, pitch: lib.random(8, 12) / 10})
          projectile.dimension.createExplosion({x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, 3, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player})
          const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: 10, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()})
          const entities = player.dimension.getEntities({location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
          entities.forEach(entity => {
  
            try {
  
              entity.applyKnockback(projectile.getDynamicProperty("initialDirectionX"), projectile.getDynamicProperty("initialDirectionZ"), 10, 0.8)
              entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "contact"})
  
  
            } catch {}
  
  
          })
  
        }, lib.convertTick(0.1))
        mc.system.runTimeout(() => {mc.system.clearRun(tick); entity.remove()}, lib.convertTick(3))
  
  
      })
  
  
    }, lib.convertTick(0))


  })
  

})

lib.projectileHitBlock("lian:skills.6.3", function(player, projectile, location) {

  mc.world.playSound("explode", projectile.location, {volume: 10, pitch: lib.random(8, 10) / 10})
  projectile.remove()


})
lib.projectileHitEntity("lian:skills.6.3", function(player, target, projectile, location) {

  mc.world.playSound("explode", location, {volume: 10, pitch: lib.random(8, 10) / 10})
  projectile.remove()


})

lib.itemUse("lian:skills.6.4", function(player, item) {

  lib.conditionSkill(player, 400, 2, (player) => {

    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
    mc.system.runTimeout(() => {player.runCommandAsync("tp @s ^^^1 ~ 0")}, lib.convertTick(0.1))
    player.runCommandAsync("camera @s set minecraft:free ease 1 linear pos ^1^1.8^-1 rot ~~")
    player.runCommandAsync("inputpermission set @s movement disabled")
    player.runCommandAsync("inputpermission set @s camera disabled")
    mc.system.runTimeout(() => {
      
      player.runCommandAsync("camera @s clear")
      player.runCommandAsync("inputpermission set @s movement enabled")
      player.runCommandAsync("inputpermission set @s camera enabled")
    
    
    }, lib.convertTick(2))
    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.6.4", player.selectedSlot, 20)
    player.playAnimation("animation.player.skills.6.4")
    const entities = player.getEntitiesFromViewDirection({maxDistance: 100})
    if (entities[0]) {
        
      entities.forEach(hit => {
        
        hit.entity.setDynamicProperty("locationOfSkills.6.4", {x: hit.entity.location.x, y: hit.entity.location.y, z: hit.entity.location.z})
        const tick = mc.system.runInterval(() => {
            
          if (hit.entity.typeId === "minecraft:player") {
  
            hit.entity.runCommandAsync("inputpermission set @s movement disabled")
  
  
          } else {
  
            hit.entity.teleport(hit.entity.getDynamicProperty("locationOfSkills.6.4"))
  
  
          }
  
  
        }, lib.convertTick(0.1))
        mc.system.runTimeout(() => {mc.system.clearRun(tick); hit.entity.runCommandAsync("inputpermission set @s movement enabled"); hit.entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.1)}, lib.convertTick(1))
       
      
      })
    
    
    }
    mc.system.runTimeout(() => {
      
      const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 1.8, z: player.location.z})
      locate.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^^^2.5 run tp @s ~~~ ~~").then(() => {
  
        const projectile = player.dimension.spawnEntity("lian:skills.6.4", {x: locate.location.x, y: locate.location.y + 1.8, z: locate.location.z})
        projectile.nameTag = player.nameTag

        projectile.setProperty("lian:pivot_x", player.getRotation().x)
        projectile.setProperty("lian:pivot_y", player.getRotation().y)
        // projectile.setProperty("lian:pivot_z", player.getRotation().z)

        projectile.applyImpulse({x: player.getViewDirection().x * 3, y: player.getViewDirection().y * 3, z: player.getViewDirection().z * 3})
        projectile.setDynamicProperty("initialDirectionX", player.getViewDirection().x); projectile.setDynamicProperty("initialDirectionZ", player.getViewDirection().z)
        const tick = mc.system.runInterval(() => {
  
          try {projectile.runCommandAsync("particle lian:skills.6.4.1"); projectile.runCommandAsync("particle lian:skills.6.4.2")} catch {}
          projectile.dimension.createExplosion({x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, lib.random(10, 20) / 10, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player}); const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: 5, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()})
          mc.world.playSound("mob.ghast.fireball", {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, {pitch: 1, volume: 10})
  
        }, lib.convertTick(0.1))
        mc.system.runTimeout(() => {
          
          const entities = player.dimension.getEntities({location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}, maxDistance: 20, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"]})
          entities.forEach(entity => {
  
            const tick = mc.system.runInterval(() => {
  
              entity.runCommandAsync("particle lian:skills.6.4.3")
              entity.runCommandAsync("particle lian:skills.6.4.4")
              entity.runCommandAsync("particle lian:skills.6.4.5")
              entity.runCommandAsync("particle lian:skills.6.4.6")
              entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "fire"})
              // entity.applyKnockback(entity.getViewDirection().x, entity.getViewDirection().z, 0, 1)
  
  
            }, lib.convertTick(0.1))
            mc.system.runTimeout(() => {mc.system.clearRun(tick)}, lib.convertTick(2))
  
  
          })
          mc.system.clearRun(tick); projectile.remove()
  
        
        
        }, lib.convertTick(0.5))
  
  
      })
  
  
    }, lib.convertTick(0.9))


  })
  

})

mc.world.afterEvents.projectileHitEntity.subscribe(data => {

  const projectile = data.projectile, target = data.getEntityHit().entity
  if (projectile.typeId === "lian:skills.6.4") {

    const players = projectile.dimension.getPlayers()
    players.forEach(player => {

      if (player.nameTag === projectile.nameTag) {

        if (projectile.nameTag !== target.nameTag) {

          projectile.remove()
          const tick = mc.system.runInterval(() => {

            target.runCommandAsync("particle lian:skills.6.4.3")
            target.runCommandAsync("particle lian:skills.6.4.4")
            target.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "fire"})
            target.applyKnockback(target.getViewDirection().x, target.getViewDirection().z, 0, 1)


          }, lib.convertTick(0.1))
          mc.system.runTimeout(() => {mc.system.clearRun(tick)}, lib.convertTick(2))

        }


      }


    })


  }



})

lib.itemUse("lian:skills.6.5", function(player, item) {

  lib.conditionSkill(player, 350, 2, (player) => {

    player.playSound("note.hat"); lib.delayItem(player, "lian:skills.6.5", player.selectedSlot, 1)
    const player2 = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 30, minDistance: 0, type: "minecraft:player", tags: ["ownerExpansion"], excludeNames: [player.nameTag]})
    if (player2[0] && player.getDynamicProperty("domain") === 0) {
      
      if (player2[0].getDynamicProperty("clash") === 0) {
  
        player.runCommandAsync("camera @s set minecraft:third_person"); player2[0].runCommandAsync("camera @s set minecraft:third_person"); player.setDynamicProperty("clasHits", 0); player.setDynamicProperty("clashStage", 0)
        player2[0].setDynamicProperty("clasHits", 0); player2[0].setDynamicProperty("clashStage", 0); player.runCommandAsync("inputpermission set @s camera disabled"); player.runCommandAsync("inputpermission set @s movement disabled")
        player2[0].runCommandAsync("inputpermission set @s camera disabled"); player2[0].runCommandAsync("inputpermission set @s movement disabled")
        player.runCommandAsync("camerashake add @s 0.3 15 positional"); player2[0].runCommandAsync("camerashake add @s 0.3 15 positional")
        lib.setScore(player, "res_cur", 1000); lib.setScore(player2[0], "res_cur", 1000)
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(0))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(2))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(4))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(6))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(8))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(10))
        mc.system.runTimeout(() => {clash([player, player2[0]])}, lib.convertTick(12))
        mc.system.runTimeout(() => {player.setDynamicProperty("clash", 0); player2[0].setDynamicProperty("clash", 0); lib.open(player, lib.skills[2].itemsId)}, lib.convertTick(12))
  
  
      } else {
  
        lib.hitUi(player, "§cWait for the clash to end")
  
  
      }
  
  
    } else {expansion(player)}


  })


})
function clash(players) {

  if (players[0].getDynamicProperty("clashStage") >= 6 || players[1].getDynamicProperty("clashStage") >= 6) {

   if (players[0].getDynamicProperty("clasHits") > players[1].getDynamicProperty("clasHits")) {

     lib.hitUi(players[0], "Player " + players[0].nameTag + " won!")
     lib.hitUi(players[1], "Player " + players[0].nameTag + " won!")
     players[0].setDynamicProperty("domain", 0)
     players[1].setDynamicProperty("domain", 1)
     lib.removeExpansion(players[1], "lian:skills.6.5")
     mc.system.runTimeout(() => {expansion(players[0])}, lib.convertTick(2))


   } else if (players[0].getDynamicProperty("clasHits") < players[1].getDynamicProperty("clasHits")) {

     lib.hitUi(players[0], "Player " + players[1].nameTag + " won!")
     lib.hitUi(players[1], "Player " + players[1].nameTag + " won!")
     lib.delayItem(players[0], "lian:skills.2.6", 8, 100)
     players[0].setDynamicProperty("domain", 0)
     players[1].setDynamicProperty("domain", 1)


   } else {

     lib.hitUi(players[0], "A tie!!")
     lib.hitUi(players[1], "A tie!!")
     players[1].setDynamicProperty("domain", 1)
     players[0].setDynamicProperty("domain", 0)
     lib.removeExpansion(players[1], "lian:skills.6.5")
     lib.delayItem(players[0], "lian:skills.2.6", 8, 100)
     lib.delayItem(players[1], "lian:skills.2.6", 8, 100)


   }
   players[0].runCommandAsync("inputpermission set @s camera enabled")
   players[0].runCommandAsync("inputpermission set @s movement enabled")
   players[1].runCommandAsync("inputpermission set @s camera enabled")
   players[1].runCommandAsync("inputpermission set @s movement enabled")
   lib.setScore(players[0], "res_cur", lib.getScore(players[0], "res_base"))
   lib.setScore(players[1], "res_cur", lib.getScore(players[1], "res_base"))
   players[0].runCommandAsync("camera @s clear")
   players[1].runCommandAsync("camera @s clear")


  } else {

   let random1 = lib.random(5, 8); let random2 = lib.random(5, 8); let random3 = lib.random(5, 8); let random4 = lib.random(5, 8)
   for (let i = 0; random1 === random2 || random1 === random3 || random1 === random4; i++) {random1 = lib.random(5, 8)}
   for (let i = 0; random2 === random1 || random2 === random3 || random2 === random4; i++) {random2 = lib.random(5, 8)}
   for (let i = 0; random3 === random2 || random3 === random1 || random3 === random4; i++) {random3 = lib.random(5, 8)}
   for (let i = 0; random4 === random2 || random4 === random3 || random4 === random1; i++) {random4 = lib.random(5, 8)}
   for (let i = 0; i < 2; i++) {

     players[i].playSound("note.bell")
     !players[i].getDynamicProperty("clashNumber") ? players[i].setDynamicProperty("clashNumber", 0): null
     !players[i].getDynamicProperty("clasHits") ? players[i].setDynamicProperty("clasHits", 1): null;
     !players[i].getDynamicProperty("clashStage") ? players[i].setDynamicProperty("clashStage", 0): null; players[i].setDynamicProperty("clashStage", players[i].getDynamicProperty("clashStage") + 1)
     players[i].setDynamicProperty("clashNumber", lib.random(1, 4))
     players[i].setDynamicProperty("clash", 1)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random1} lian:skills.clash.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random2} lian:skills.clash.2 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random3} lian:skills.clash.3 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
     players[i].runCommandAsync(`replaceitem entity @s slot.hotbar ${random4} lian:skills.clash.4 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)

   
   }

  }


}
function expansion(player) {

  !player.getDynamicProperty("domain") ? player.setDynamicProperty("domain", 0): null
  if (player.getDynamicProperty("domain") === 0) {
    
    player.setDynamicProperty("domain", 1)
    player.playAnimation("animation.player.skills.6.5"); mc.world.playSound("skills.6.5.1", player.location, {pitch: 1, volume: 10.0})
    player.addTag("ownerExpansion")
    const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, type: "minecraft:player"})
    players.forEach(a => {

      a.addTag("isInExpansion")
      a.addTag("isInExpansionTerrain")
      a.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1, 0.1)
      a.runCommandAsync("tp ~~~ ~ 0")
      mc.system.runTimeout(() => {a.runCommandAsync("execute as @s at @a[name=\"" + player.nameTag + "\"] run camera @s set minecraft:free ease 1 linear pos ^^1.8^2 facing ~~1.5~")}, lib.convertTick(0.5))
      lib.subtitle(a, "Domain expansion...")
      a.runCommandAsync("inputpermission set @s camera disabled")
      a.runCommandAsync("inputpermission set @s movement disabled")
      a.addTag("inAttack")
      a.setDynamicProperty("scene", 1)
      a.runCommandAsync("fog @s push lian:sukuna domainFog")
  
    
    })
    mc.system.runTimeout(() => {mc.world.playSound("skills.6.5.2", player.location, {pitch: 1, volume: 10.0}); player.runCommandAsync("playsound skills.6.5.3 @a[r=100] ^^^-4 100")}, lib.convertTick(3))
    mc.system.runTimeout(() => {
                
      const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, type: "minecraft:player"})
      players.forEach(a => {a.runCommandAsync("camera @s fade time 0.1 0.6 1 color 0 0 0")})
          
          
    }, lib.convertTick(6))
    mc.system.runTimeout(() => {
                
      const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, type: "minecraft:player"})
      players.forEach(a => {a.runCommandAsync("execute as @s at @a[name=\"" + player.nameTag + "\"] run camera @s set minecraft:free ease 10 linear pos ^^8^10 facing ~~1.5~")})
      const visual = player.dimension.spawnEntity("lian:skills.6.5", {x: player.location.x, y: player.location.y, z: player.location.z})
      visual.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] run tp ^^^-7 ~~")
      mc.system.runTimeout(() => {visual.playAnimation("animation.2")}, lib.convertTick(0.1))
      mc.system.runTimeout(() => {

        visual.runCommandAsync("particle lian:skills.6.5.1 ~~~")
        visual.runCommandAsync("particle lian:skills.6.5.2 ~~1~")
        visual.runCommandAsync("particle lian:skills.6.5.3 ~~~")
        

      }, lib.convertTick(0.5))
          
          
    }, lib.convertTick(6.5))
    mc.system.runTimeout(() => {

      const players = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, type: "minecraft:player"})
      players.forEach(a => {
    
        a.runCommandAsync("camera @s clear")
        a.runCommandAsync("inputpermission set @s camera enabled")
        a.runCommandAsync("inputpermission set @s movement enabled")
        a.removeTag("inAttack")
        a.setDynamicProperty("scene", 0)
        player.setDynamicProperty("domainIs", 1)
    
      
      })
          
          
    }, lib.convertTick(15))


  } else if (player.getDynamicProperty("domain") === 1) {
    
    lib.delayItem(player, "lian:skills.2.6", 8, 40)
    player.setDynamicProperty("domain", 0)
    player.runCommandAsync("stopsound @a[r=100] skills.6.5.3")
    const visuals = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, type: "lian:skills.6.5"})
    visuals.forEach(visual => {

      visual.playAnimation("animation.3")
      mc.system.runTimeout(() => {visual.remove()}, lib.convertTick(2))


    })
    const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
    entities.forEach(entity => {

      entity.removeTag("ownerExpansion")
      entity.typeId === "minecraft:player" ? (entity.runCommandAsync("fog @s remove domainFog"), entity.removeTag("remove_knockback"), entity.removeTag("isInExpansion")): null


    })
    player.setDynamicProperty("domainIs", 0); player.setDynamicProperty("domainTime", 0)
    player.setDynamicProperty("multiplier", 1)


  }



}
mc.system.runInterval(() => {

  for (const player of mc.world.getPlayers()) {

    if (player.hasTag("ownerExpansion") && player.getDynamicProperty("skill") === 6 && lib.getScore(player, "energy_cur") >= (lib.getScore(player, "energy_base") / 100 * 1)) {player.getDynamicProperty("scene") === 0 ? lib.setScore(player, "energy_cur", lib.clamp(lib.getScore(player, "energy_cur") - Math.round(lib.getScore(player, "energy_base") / 100 * 1), 0, lib.getScore(player, "energy_base"))): null}


  }


}, lib.convertTick(1))
mc.system.runInterval(() => {

  for (const player of mc.world.getPlayers()) {

    const visuals = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, type: "lian:skills.6.5"})
    if (visuals[0] && player.hasTag("ownerExpansion") && player.getDynamicProperty("skill") === 6) {
  
      if (lib.getScore(player, "energy_cur") >= (lib.getScore(player, "energy_base") / 100 * 1)) {
      
        visuals[0].runCommandAsync("particle lian:skills.6.5.4")
        visuals[0].runCommandAsync("particle lian:skills.6.5.5")
        visuals[0].runCommandAsync("particle lian:skills.6.5.6")
        visuals[0].runCommandAsync("particle lian:skills.6.5.7")
        visuals[0].runCommandAsync("particle lian:skills.6.5.8")
        visuals[0].runCommandAsync("particle lian:skills.6.5.9")
        const entities = visuals[0].dimension.getEntities({location: {x: visuals[0].location.x, y: visuals[0].location.y, z: visuals[0].location.z}, maxDistance: 50, minDistance: 0, excludeTypes: ["orb", "item"], excludeFamilies: ["not", "skill"]})
        const entities2 = visuals[0].dimension.getEntities({location: {x: visuals[0].location.x, y: visuals[0].location.y, z: visuals[0].location.z}, maxDistance: 60, minDistance: 51, excludeTypes: ["orb", "item"], excludeFamilies: ["not", "skill"]})
        entities.forEach(entity => {
          
          try {

            if (!entity.getDynamicProperty("simpleDomain") && !entity.hasTag("ownerExpansion")) {
            
              entity.runCommandAsync("camerashake add @s 0.05 1 positional")
              try {entity.typeId === "minecraft:player" ? entity.addTag("remove_knockback"): entity.triggerEvent("remove_knockback")} catch {}
              entity.applyDamage(lib.getScore(player, "str_cur") * 0.5, {damagingEntity: player, cause: "contact"})
    
    
            }
            entity.addTag("isInExpansion")
            entity.runCommandAsync("fog @s push lian:sukuna domainFog")


          } catch {}
        
        
        })
        entities2.forEach(entity => {
          
          try {
            
            if (entity.nameTag === player.nameTag) {
              
              lib.delayItem(player, "lian:skills.2.6", 8, 40)
              player.setDynamicProperty("domain", 0)
              player.runCommandAsync("stopsound @a[r=100] skills.6.5.3")
              
              visuals[0].playAnimation("animation.3")
              mc.system.runTimeout(() => {visuals[0].remove()}, lib.convertTick(2))
              
              const entities = visuals[0].dimension.getEntities({location: {x: visuals[0].location.x, y: visuals[0].location.y, z: visuals[0].location.z}, maxDistance: 50, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
              entities.forEach(entity => {
        
                entity.removeTag("ownerExpansion")
                try {entity.typeId === "minecraft:player" ? (entity.runCommandAsync("fog @s remove domainFog"), entity.removeTag("remove_knockback"), entity.removeTag("isInExpansion")): entity.triggerEvent("add_knockback")} catch {}
          
          
              })
              player.setDynamicProperty("domainIs", 0); player.setDynamicProperty("domainTime", 0)
              player.setDynamicProperty("multiplier", 1)
              
              
            } else {
              
              entity.runCommandAsync("fog @s remove domainFog")
              entity.removeTag("remove_knockback")
              entity.removeTag("isInExpansion")


            }
          
          
          } catch {}
        
        
        })
        randomExplode(player, visuals[0])
        randomExplode(player, visuals[0])
        randomExplode(player, visuals[0])
        player.setDynamicProperty("multiplier", 2)
  
      } else {

        lib.delayItem(player, "lian:skills.2.6", 8, 40)
        player.setDynamicProperty("domain", 0)
        player.runCommandAsync("stopsound @a[r=100] skills.6.5.3")
        const visuals = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, type: "lian:skills.6.5"})
        visuals.forEach(visual => {
  
          visual.playAnimation("animation.3")
          mc.system.runTimeout(() => {visual.remove()}, lib.convertTick(2))
  
  
        })
        const entities = visuals[0].dimension.getEntities({location: {x: visuals[0].location.x, y: visuals[0].location.y, z: visuals[0].location.z}, maxDistance: 50, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
        entities.forEach(entity => {
  
          entity.removeTag("ownerExpansion")
          try {entity.typeId === "minecraft:player" ? (entity.runCommandAsync("fog @s remove domainFog"), entity.removeTag("remove_knockback"), entity.removeTag("isInExpansion")): entity.triggerEvent("add_knockback")} catch {}
    
    
        })
        player.setDynamicProperty("domainIs", 0); player.setDynamicProperty("domainTime", 0)
        player.setDynamicProperty("multiplier", 1)

    }
    
    
    }


  }


}, lib.convertTick(0.1))
function randomExplode(player, entity) {

  try {

    let locX = lib.random(-50, 50)
    let locZ = lib.random(-50, 50)
    let loc = {x: entity.location.x + locX, y: entity.location.y, z: entity.location.z + locZ}
    let verify = player.dimension.getEntities({location: loc, maxDistance: 10, type: "lian:skills.6.5"})
    for (let i = 0; verify[0]; i++) {
      
      locX = lib.random(-50, 50)
      locZ = lib.random(-50, 50)
      loc = {x: entity.location.x + locX, y: entity.location.y, z: entity.location.z + locZ}
      verify = player.dimension.getEntities({location: loc, maxDistance: 10, type: "lian:skills.6.5"})
  
  
    }
    player.dimension.createExplosion(loc, lib.random(1, 20) / 10, {breaksBlocks: player.hasTag("breacksBlock") ? true: false, source: player})
    const items = player.dimension.getEntities({type: "minecraft:item", maxDistance: 20, minDistance: 0, location: loc}); items.forEach(item => {item.remove()})
    mc.world.playSound("weapon.1.1", loc, {volume: 10, pitch: lib.random(5, 25) / 10})


  } catch {}


}