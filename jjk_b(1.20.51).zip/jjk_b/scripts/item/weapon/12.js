import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";

lib.itemUse("lian:weapon.12", function(player, item) {

  const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], exclueTypes: ["orb", "item"]})
  !player.getDynamicProperty("weapon.12") ? player.setDynamicProperty("weapon.12", 0): null
  if (player.getDynamicProperty("weapon.12") === 0) {

    player.setDynamicProperty("weapon.12", 1)
    lib.delayItem(player, "lian:weapon.12", player.selectedSlot, 0.1, false, "lian:weapon.12.bloqued")
    mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(12, 14) / 10})
    mc.system.runTimeout(() => {

      entities.forEach(entity => {

        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 1, {damagingEntity: player, cause: "contact"})
  
  
      })


    }, lib.convertTick(0.2))
    lib.hitUi(player, "Hit 1")
    player.playAnimation("animation.player.weapon.12.1")


  } else if (player.getDynamicProperty("weapon.12") === 1) {

    player.setDynamicProperty("weapon.12", 2)
    lib.delayItem(player, "lian:weapon.12", player.selectedSlot, 0.1, false, "lian:weapon.12.bloqued")
    mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(12, 16) / 10})
    mc.system.runTimeout(() => {

      entities.forEach(entity => {

        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "contact"})
  
  
      })

      
    }, lib.convertTick(0.2))
    lib.hitUi(player, "Hit 2")
    player.playAnimation("animation.player.weapon.12.2")


  } else if (player.getDynamicProperty("weapon.12") === 2) {

    player.setDynamicProperty("weapon.12", 0)
    lib.delayItem(player, "lian:weapon.12", player.selectedSlot, 1, false, "lian:weapon.12.bloqued")
    mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(12, 18) / 10})
    mc.system.runTimeout(() => {

      entities.forEach(entity => {

        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "contact"})
  
  
      })

      
    }, lib.convertTick(0.2))
    lib.hitUi(player, "Hit 3")
    player.playAnimation("animation.player.weapon.12.3")


  }


})