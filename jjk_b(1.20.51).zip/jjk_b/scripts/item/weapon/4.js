import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "../../lib.js";

lib.itemUse("lian:weapon.4", function(player, item) {

  !player.getDynamicProperty("weapon.4") ? player.setDynamicProperty("weapon.4", 0): null
  if (player.getDynamicProperty("weapon.4") === 0) {

    player.setDynamicProperty("weapon.4", 1)
    lib.delayItem(player, "lian:weapon.4", player.selectedSlot, 0.1, false, "lian:weapon.4.bloqued")
    mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(10, 12) / 10})
    mc.system.runTimeout(() => {

      const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], exclueTypes: ["orb", "item"]})
      entities.forEach(entity => {

        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 1, {damagingEntity: player, cause: "contact"})
  
  
      })


    }, lib.convertTick(0.2))
    lib.hitUi(player, "Hit 1")
    player.playAnimation("animation.player.weapon.4.1")


  } else if (player.getDynamicProperty("weapon.4") === 1) {

    player.setDynamicProperty("weapon.4", 2)
    lib.delayItem(player, "lian:weapon.4", player.selectedSlot, 0.1, false, "lian:weapon.4.bloqued")
    mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(10, 16) / 10})
    mc.system.runTimeout(() => {

      const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], exclueTypes: ["orb", "item"]})
      entities.forEach(entity => {

        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 1.5, {damagingEntity: player, cause: "contact"})
  
  
      })

      
    }, lib.convertTick(0.2))
    lib.hitUi(player, "Hit 2")
    player.playAnimation("animation.player.weapon.4.2")


  } else if (player.getDynamicProperty("weapon.4") === 2) {

    player.setDynamicProperty("weapon.4", 3)
    lib.delayItem(player, "lian:weapon.4", player.selectedSlot, 0.1, false, "lian:weapon.4.bloqued")
    mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(10, 18) / 10})
    mc.system.runTimeout(() => {

      const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], exclueTypes: ["orb", "item"]})
      entities.forEach(entity => {

        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.5, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "contact"})
  
  
      })

      
    }, lib.convertTick(0.2))
    lib.hitUi(player, "Hit 3")
    player.playAnimation("animation.player.weapon.4.3")


  } else if (player.getDynamicProperty("weapon.4") === 3) {

    player.setDynamicProperty("weapon.4", 0)
    mc.world.playSound("weapon.1.1", player.location, {volume: 1.0, pitch: lib.random(18, 25) / 10})
    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 2.5, 0.2)
    mc.system.runTimeout(() => {

      const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 5, minDistance: 0, excludeNames: [player.nameTag], excludeFamilies: ["not"], exclueTypes: ["orb", "item"]})
      mc.world.playSound("explode", player.location, {volume: 1.0, pitch: lib.random(8, 10) / 10})
      entities.forEach(entity => {

        entity.runCommandAsync("particle lian:weapon.4.3")
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 12, 0.2)
        entity.applyDamage(lib.getScore(player, "str_cur") * 2, {damagingEntity: player, cause: "contact"})
  
  
      })

      
    }, lib.convertTick(0.2))
    lib.hitUi(player, "Hit 3")
    player.playAnimation("animation.player.weapon.4.3")


  }


})