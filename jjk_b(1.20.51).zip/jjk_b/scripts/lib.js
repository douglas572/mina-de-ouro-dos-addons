import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";

const ticks = []
export function tick(callback, delay) {ticks.push(callback)}
export const skills = [
  
  {name: "null", idName: "null", itemsId: ["lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1"], mastery: [[0, 0], [0, 0], [0, 0], [0, 0], [0, 0]]}, //
  {name: "Boggie wogie inata", idName: "todo", itemsId: ["lian:skills.1.1", "lian:skills.1.2", "lian:skills.1.4", "lian:skills.1.6", "lian:skills.1.7"], mastery: [[0, 200], [0, 500], [0, 600], [0, 800], [0, 0]]},
  {name: "Disaster flame inata", idName: "jogo", itemsId: ["lian:skills.2.1", "lian:skills.2.2", "lian:skills.2.4", "lian:skills.2.5", "lian:skills.2.6"], mastery: [[0, 200], [0, 500], [600, 0], [0, 1000], [0, 3000]]},
  {name: "Six eyes inata", idName: "gojo", itemsId: ["lian:skills.3.1", "lian:skills.3.2", "lian:skills.3.3", "lian:skills.3.4", "lian:skills.3.5"], mastery: [[0, 0], [250, 350], [0, 500], [0, 1000], [0, 4000]]},
  {name: "Heavenly restriction inata", idName: "toji", itemsId: ["lian:skills.4.1", "lian:skills.4.2", "lian:skills.4.3", "lian:skills.air.1", "lian:skills.air.1"], mastery: [[0, 200], [300, 500], [0, 850], [0, 0], [0, 0]]},
  {name: "null", idName: "null", itemsId: ["lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1"], mastery: [[0, 0], [0, 0], [0, 0], [0, 0], [0, 0]]}, //
  {name: "King of curses inata", idName: "sukuna", itemsId: ["lian:skills.6.1", "lian:skills.6.2", "lian:skills.6.3", "lian:skills.6.4", "lian:skills.6.5"], mastery: [[0, 0], [0, 150], [0, 300], [0, 1000], [0, 4000]]},
  {name: "null", idName: "null", itemsId: ["lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1", "lian:skills.air.1"], mastery: [[0, 0], [0, 0], [0, 0], [0, 0], [0, 0]]}, //
  {name: "Straw doll inata", idName: "nobara", itemsId: ["lian:skills.8.1", "lian:skills.8.2", "lian:skills.8.3", "lian:skills.air.1", "lian:skills.air.1"], mastery: [[0, 0], [0, 200], [0, 350], [0, 0], [0, 0]]},
  {name: "Cursed speech inata", idName: "toge", itemsId: ["lian:skills.9.1", "lian:skills.9.2", "lian:skills.9.3", "lian:skills.9.4", "lian:skills.air.1"], mastery: [[0, 0], [0, 200], [400, 0], [0, 800], [0, 0]]}

]
export const arrayItemUse = []
export function itemUse(itemId, callback) {arrayItemUse.push({callback: callback, itemId: itemId})}
mc.world.afterEvents.itemStartUse.subscribe(data => {arrayItemUse.forEach(a => {if (data.itemStack.typeId == a.itemId) {a.callback(data.source, data.itemStack)}})})

export const arrayItemHitEntity = []
export function itemHitEntity(itemId, callback) {arrayItemHitEntity.push({callback: callback, itemId: itemId})}
mc.world.afterEvents.entityHitEntity.subscribe(data => {arrayItemHitEntity.forEach(a => {try{if (data.damagingEntity.getComponent("minecraft:inventory").container.getItem(data.damagingEntity.selectedSlot)?.typeId === a.itemId) {a.callback(data.damagingEntity, data.hitEntity)}} catch {}})})

export const arrayProjectileHitEntity = []
export function projectileHitEntity(typeId, callback) {arrayProjectileHitEntity.push({callback: callback, typeId: typeId})}
mc.world.afterEvents.projectileHitEntity.subscribe(data => {arrayProjectileHitEntity.forEach(a => {const projectile = data.projectile, target = data.getEntityHit().entity; const location = data.location; try {if (projectile.typeId === a.typeId) {const players = projectile.dimension.getPlayers(); players.forEach(player => {if (player.nameTag === projectile.nameTag) {if (projectile.nameTag !== target.nameTag) {a.callback(player, target, projectile, location)}}})}} catch {}})})

export const arrayProjectileHitBlock = []
export function projectileHitBlock(typeId, callback) {arrayProjectileHitBlock.push({callback: callback, typeId: typeId})}
mc.world.afterEvents.projectileHitBlock.subscribe(data => {arrayProjectileHitBlock.forEach(a => {const projectile = data.projectile; try {if (projectile.typeId === a.typeId) {const players = projectile.dimension.getPlayers(); players.forEach(player => {if (player.nameTag === projectile.nameTag) {a.callback(player, projectile, data.location)}})}} catch {}})})

export const arrayTickItem = []
export function tickItem(itemId, callback) {arrayTickItem.push({callback: callback, itemId: itemId})}
tick(function(player) {arrayTickItem.forEach(a => {if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === a.itemId) {a.callback(player)}})}, 1)

export function killItens(projectile, ray) {

  const items = projectile.dimension.getEntities({type: "minecraft:item", maxDistance: ray, minDistance: 0, location: {x: projectile.location.x, y: projectile.location.y, z: projectile.location.z}}); items.forEach(item => {item.remove()}); projectile.remove()

}

mc.system.runInterval(() => {

  for (const player of mc.world.getPlayers()) {



    ticks.forEach(tick => {tick(player)})

    player.getDynamicProperty("clash") === 1 && player.selectedSlot < 5 ? player.selectedSlot = 5: null

    !player.getDynamicProperty("structureTime") ? player.setDynamicProperty("structureTime", 0): null
    !player.getDynamicProperty("structureIs") ? player.setDynamicProperty("structureIs", 0): null
    player.getDynamicProperty("structureTime") > 0 ? player.setDynamicProperty("structureTime", player.getDynamicProperty("structureTime") - 1): null
    if (player.getDynamicProperty("structureTime") > 0 && player.getDynamicProperty("canTeleport") == 0) {
      
      player.runCommandAsync("camera @s fade time 0 2 1 color 0 0 0")
      player.runCommandAsync("execute in the_end positioned " + player.getDynamicProperty("locationOfStructureX") + " 120 " + player.getDynamicProperty("locationOfStructureZ") + " run tp ~~~")
      player.setDynamicProperty("scene", 1)


    } else if (player.getDynamicProperty("structureIs") === 1 && player.getDynamicProperty("structureTime") == 0 && player.getDynamicProperty("canTeleport") == 0) {player.setDynamicProperty("structureIs", 0)

    player.setDynamicProperty("canTeleport", 1)
    const entities = player.dimension.getEntities({type: "lian:structure.spawn", location: player.location, maxDistance: 60})
    player.teleport(entities[0].location)
    player.setDynamicProperty("scene", 0)


    }
    !player.getDynamicProperty("scene") ? player.setDynamicProperty("scene", 0): null
    !player.getDynamicProperty("slot.1.delay") ? player.setDynamicProperty("slot.1.delay", 0): null
    !player.getDynamicProperty("slot.1.item") ? player.setDynamicProperty("slot.1.item", 0): null
    !player.getDynamicProperty("slot.1.is") ? player.setDynamicProperty("slot.1.is", 0): null
    if (player.getDynamicProperty("slot.1.delay") < 0) {player.setDynamicProperty("slot.1.delay", 0)}
    if (player.getDynamicProperty("slot.1.delay") > 0) {player.setDynamicProperty("slot.1.delay", player.getDynamicProperty("slot.1.delay") - 1)}
    else if (player.getDynamicProperty("slot.1.delay") === 0 && player.getDynamicProperty("slot.1.is") === 1) {player.setDynamicProperty("slot.1.is", 0); player.runCommandAsync(`replaceitem entity @s slot.hotbar 1 ` + player.getDynamicProperty("slot.1.item"))}

    !player.getDynamicProperty("slot.2.delay") ? player.setDynamicProperty("slot.2.delay", 0): null
    !player.getDynamicProperty("slot.2.item") ? player.setDynamicProperty("slot.2.item", 0): null
    !player.getDynamicProperty("slot.2.is") ? player.setDynamicProperty("slot.2.is", 0): null
    if (player.getDynamicProperty("slot.2.delay") < 0) {player.setDynamicProperty("slot.2.delay", 0)}
    if (player.getDynamicProperty("slot.2.delay") > 0) {player.setDynamicProperty("slot.2.delay", player.getDynamicProperty("slot.2.delay") - 1)}
    else if (player.getDynamicProperty("slot.2.delay") === 0 && player.getDynamicProperty("slot.2.is") === 1) {player.setDynamicProperty("slot.2.is", 0); player.runCommandAsync(`replaceitem entity @s slot.hotbar 2 ` + player.getDynamicProperty("slot.2.item"))}
    
    !player.getDynamicProperty("slot.3.delay") ? player.setDynamicProperty("slot.3.delay", 0): null
    !player.getDynamicProperty("slot.3.item") ? player.setDynamicProperty("slot.3.item", 0): null
    !player.getDynamicProperty("slot.3.is") ? player.setDynamicProperty("slot.3.is", 0): null
    if (player.getDynamicProperty("slot.3.delay") < 0) {player.setDynamicProperty("slot.3.delay", 0)}
    if (player.getDynamicProperty("slot.3.delay") > 0) {player.setDynamicProperty("slot.3.delay", player.getDynamicProperty("slot.3.delay") - 1)}
    else if (player.getDynamicProperty("slot.3.delay") === 0 && player.getDynamicProperty("slot.3.is") === 1) {player.setDynamicProperty("slot.3.is", 0); player.runCommandAsync(`replaceitem entity @s slot.hotbar 3 ` + player.getDynamicProperty("slot.3.item"))}

    if (player.hasTag("reset.delays")) {

      player.removeTag("reset.delays")
      player.runCommandAsync("camera @s clear")
      player.runCommandAsync("inputpermission set @s camera enabled")
      player.runCommandAsync("inputpermission set @s movement enabled")
      setScore(player, "res_cur", getScore(player, "res_base"))
      player.setDynamicProperty("scene", 0)
      player.setDynamicProperty("clash", 0)
      player.setDynamicProperty("slot.1.delay", 0)
      player.setDynamicProperty("slot.2.delay", 0)
      player.setDynamicProperty("slot.1.3.delay", 0)
      player.setDynamicProperty("slot.1.4.delay", 0)
      player.setDynamicProperty("slot.1.5.delay", 0)
      player.setDynamicProperty("slot.1.6.delay", 0)
      player.setDynamicProperty("slot.1.7.delay", 0)
      player.setDynamicProperty("slot.1.8.delay", 0)
      player.setDynamicProperty("slot.2.3.delay", 0)
      player.setDynamicProperty("slot.2.4.delay", 0)
      player.setDynamicProperty("slot.2.5.delay", 0)
      player.setDynamicProperty("slot.2.6.delay", 0)
      player.setDynamicProperty("slot.2.7.delay", 0)
      player.setDynamicProperty("slot.2.8.delay", 0)


    } else if (player.hasTag("grade.6")) {

      player.removeTag("grade.6")
      player.setDynamicProperty("grade", 6)


    } else if (player.hasTag("grade.1")) {

      player.removeTag("grade.1")
      player.setDynamicProperty("grade", 1)


    } else if (player.hasTag("grade.2")) {

      player.removeTag("grade.2")
      player.setDynamicProperty("grade", 2)


    } else if (player.hasTag("grade.3")) {

      player.removeTag("grade.3")
      player.setDynamicProperty("grade", 3)


    } else if (player.hasTag("grade.4")) {

      player.removeTag("grade.4")
      player.setDynamicProperty("grade", 4)


    } else if (player.hasTag("grade.5")) {

      player.removeTag("grade.5")
      player.setDynamicProperty("grade", 5)


    }


    !player.getDynamicProperty("clash") ? player.setDynamicProperty("clash", 0): null
    if (player.hasTag("secondHotbar") && player.getDynamicProperty("scene") === 0 && player.getDynamicProperty("clash") === 0) {

      player.runCommandAsync(`replaceitem entity @s slot.hotbar 0 lian:skills.load 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)

      !player.getDynamicProperty("skill") ? player.setDynamicProperty("skill", 0): null

      !player.getDynamicProperty("skill") ? player.setDynamicProperty("skill", 0): null

      !player.getDynamicProperty("slot.2.4.delay") ? player.setDynamicProperty("slot.2.4.delay", 0): null
      if (player.getDynamicProperty("slot.2.4.delay") < 0) {player.setDynamicProperty("slot.2.4.delay", 0)}
      if (player.getDynamicProperty("slot.2.4.delay") > 0) {player.setDynamicProperty("slot.2.4.delay", player.getDynamicProperty("slot.2.4.delay") - 1)}
      else if (player.getDynamicProperty("slot.2.4.delay") === 0 && skills[player.getDynamicProperty("skill")].itemsId[0]) {player.runCommandAsync(`replaceitem entity @s slot.hotbar 4 ` + skills[player.getDynamicProperty("skill")].itemsId[0] + ` 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)}
      
      !player.getDynamicProperty("slot.2.5.delay") ? player.setDynamicProperty("slot.2.5.delay", 0): null
      if (player.getDynamicProperty("slot.2.5.delay") < 0) {player.setDynamicProperty("slot.2.5.delay", 0)}
      if (player.getDynamicProperty("slot.2.5.delay") > 0) {player.setDynamicProperty("slot.2.5.delay", player.getDynamicProperty("slot.2.5.delay") - 1)}
      else if (player.getDynamicProperty("slot.2.5.delay") === 0 && skills[player.getDynamicProperty("skill")].itemsId[1]) {player.runCommandAsync(`replaceitem entity @s slot.hotbar 5 ` + skills[player.getDynamicProperty("skill")].itemsId[1] + ` 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)}
      
      !player.getDynamicProperty("slot.2.6.delay") ? player.setDynamicProperty("slot.2.6.delay", 0): null
      if (player.getDynamicProperty("slot.2.6.delay") < 0) {player.setDynamicProperty("slot.2.6.delay", 0)}
      if (player.getDynamicProperty("slot.2.6.delay") > 0) {player.setDynamicProperty("slot.2.6.delay", player.getDynamicProperty("slot.2.6.delay") - 1)}
      else if (player.getDynamicProperty("slot.2.6.delay") === 0 && skills[player.getDynamicProperty("skill")].itemsId[2]) {player.runCommandAsync(`replaceitem entity @s slot.hotbar 6 ` + skills[player.getDynamicProperty("skill")].itemsId[2] + ` 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)}
      
      !player.getDynamicProperty("slot.2.7.delay") ? player.setDynamicProperty("slot.2.7.delay", 0): null
      if (player.getDynamicProperty("slot.2.7.delay") < 0) {player.setDynamicProperty("slot.2.7.delay", 0)}
      if (player.getDynamicProperty("slot.2.7.delay") > 0) {player.setDynamicProperty("slot.2.7.delay", player.getDynamicProperty("slot.2.7.delay") - 1)}
      else if (player.getDynamicProperty("slot.2.7.delay") === 0 && skills[player.getDynamicProperty("skill")].itemsId[3]) {player.runCommandAsync(`replaceitem entity @s slot.hotbar 7 ` + skills[player.getDynamicProperty("skill")].itemsId[3] + ` 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)}
      
      !player.getDynamicProperty("slot.2.8.delay") ? player.setDynamicProperty("slot.2.8.delay", 0): null
      if (player.getDynamicProperty("slot.2.8.delay") < 0) {player.setDynamicProperty("slot.2.8.delay", 0)}
      if (player.getDynamicProperty("slot.2.8.delay") > 0) {player.setDynamicProperty("slot.2.8.delay", player.getDynamicProperty("slot.2.8.delay") - 1)}
      else if (player.getDynamicProperty("slot.2.8.delay") === 0 && skills[player.getDynamicProperty("skill")].itemsId[4]) {player.runCommandAsync(`replaceitem entity @s slot.hotbar 8 ` + skills[player.getDynamicProperty("skill")].itemsId[4] + ` 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)}
      
      
    } else if (player.getDynamicProperty("scene") === 1 && player.getDynamicProperty("structureTime") === 0 && player.getDynamicProperty("clash") === 0 && player.hasTag("secondHotbar")) {

      player.runCommandAsync(`replaceitem entity @s slot.hotbar 4 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
      player.runCommandAsync(`replaceitem entity @s slot.hotbar 5 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
      player.runCommandAsync(`replaceitem entity @s slot.hotbar 6 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
      player.runCommandAsync(`replaceitem entity @s slot.hotbar 7 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
      player.runCommandAsync(`replaceitem entity @s slot.hotbar 8 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)    


    }
    if (!player.hasTag("secondHotbar") && player.getDynamicProperty("scene") === 0 && player.getDynamicProperty("clash") === 0) {

      player.runCommandAsync(`replaceitem entity @s slot.hotbar 0 lian:menu 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)

      !player.getDynamicProperty("skill") ? player.setDynamicProperty("skill", 0): null

      !player.getDynamicProperty("skill") ? player.setDynamicProperty("skill", 0): null
      !player.getDynamicProperty("slot.1.4.delay") ? player.setDynamicProperty("slot.1.4.delay", 0): null
      if (player.getDynamicProperty("slot.1.4.delay") < 0) {player.setDynamicProperty("slot.1.4.delay", 0)}
      if (player.getDynamicProperty("slot.1.4.delay") > 0) {player.setDynamicProperty("slot.1.4.delay", player.getDynamicProperty("slot.1.4.delay") - 1)}
      else if (player.getDynamicProperty("slot.1.4.delay") === 0 && player.getDynamicProperty("slot.1.4.is") === 1) {player.setDynamicProperty("slot.1.4.is", 0); player.runCommandAsync(`replaceitem entity @s slot.hotbar 4 ` + player.getDynamicProperty("slot.1.4.item")  + ` 1 0`)}
      
      !player.getDynamicProperty("slot.1.5.delay") ? player.setDynamicProperty("slot.1.5.delay", 0): null
      if (player.getDynamicProperty("slot.1.5.delay") < 0) {player.setDynamicProperty("slot.1.5.delay", 0)}
      if (player.getDynamicProperty("slot.1.5.delay") > 0) {player.setDynamicProperty("slot.1.5.delay", player.getDynamicProperty("slot.1.5.delay") - 1)}
      else if (player.getDynamicProperty("slot.1.5.delay") === 0 && player.getDynamicProperty("slot.1.5.is") === 1) {player.setDynamicProperty("slot.1.5.is", 0); player.runCommandAsync(`replaceitem entity @s slot.hotbar 5 ` + player.getDynamicProperty("slot.1.5.item")  + ` 1 0`)}
      
      !player.getDynamicProperty("slot.1.6.delay") ? player.setDynamicProperty("slot.1.6.delay", 0): null
      if (player.getDynamicProperty("slot.1.6.delay") < 0) {player.setDynamicProperty("slot.1.6.delay", 0)}
      if (player.getDynamicProperty("slot.1.6.delay") > 0) {player.setDynamicProperty("slot.1.6.delay", player.getDynamicProperty("slot.1.6.delay") - 1)}
      else if (player.getDynamicProperty("slot.1.6.delay") === 0 && player.getDynamicProperty("slot.1.6.is") === 1) {player.setDynamicProperty("slot.1.6.is", 0); player.runCommandAsync(`replaceitem entity @s slot.hotbar 6 ` + player.getDynamicProperty("slot.1.6.item")  + ` 1 0`)}
      
      !player.getDynamicProperty("slot.1.7.delay") ? player.setDynamicProperty("slot.1.7.delay", 0): null
      if (player.getDynamicProperty("slot.1.7.delay") < 0) {player.setDynamicProperty("slot.1.7.delay", 0)}
      if (player.getDynamicProperty("slot.1.7.delay") > 0) {player.setDynamicProperty("slot.1.7.delay", player.getDynamicProperty("slot.1.7.delay") - 1)}
      else if (player.getDynamicProperty("slot.1.7.delay") === 0 && player.getDynamicProperty("slot.1.7.is") === 1) {player.setDynamicProperty("slot.1.7.is", 0); player.runCommandAsync(`replaceitem entity @s slot.hotbar 7 ` + player.getDynamicProperty("slot.1.7.item")  + ` 1 0`)}
      
      !player.getDynamicProperty("slot.1.8.delay") ? player.setDynamicProperty("slot.1.8.delay", 0): null
      if (player.getDynamicProperty("slot.1.8.delay") < 0) {player.setDynamicProperty("slot.1.8.delay", 0)}
      if (player.getDynamicProperty("slot.1.8.delay") > 0) {player.setDynamicProperty("slot.1.8.delay", player.getDynamicProperty("slot.1.8.delay") - 1)}
      else if (player.getDynamicProperty("slot.1.8.delay") === 0 && player.getDynamicProperty("slot.1.8.is") === 1) {player.setDynamicProperty("slot.1.8.is", 0); player.runCommandAsync(`replaceitem entity @s slot.hotbar 8 ` + player.getDynamicProperty("slot.1.8.item")  + ` 1 0`)}
      
      
    }


  }


}, convertTick(0.3))
export function open(player, array) {

  !player.hasTag("secondHotbar") ? (hotbar.save(player), player.addTag("secondHotbar")): null
  player.runCommandAsync(`replaceitem entity @s slot.hotbar 0 lian:skills.load 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
  player.getDynamicProperty("slot.2.4.delay") === 0 ? player.runCommandAsync(`replaceitem entity @s slot.hotbar 4 ${array[0]} 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`): player.runCommandAsync(`replaceitem entity @s slot.hotbar 4 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
  player.getDynamicProperty("slot.2.5.delay") === 0 ? player.runCommandAsync(`replaceitem entity @s slot.hotbar 5 ${array[1]} 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`): player.runCommandAsync(`replaceitem entity @s slot.hotbar 5 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
  player.getDynamicProperty("slot.2.6.delay") === 0 ? player.runCommandAsync(`replaceitem entity @s slot.hotbar 6 ${array[2]} 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`): player.runCommandAsync(`replaceitem entity @s slot.hotbar 6 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
  player.getDynamicProperty("slot.2.7.delay") === 0 ? player.runCommandAsync(`replaceitem entity @s slot.hotbar 7 ${array[3]} 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`): player.runCommandAsync(`replaceitem entity @s slot.hotbar 7 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
  player.getDynamicProperty("slot.2.8.delay") === 0 ? player.runCommandAsync(`replaceitem entity @s slot.hotbar 8 ${array[4]} 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`): player.runCommandAsync(`replaceitem entity @s slot.hotbar 8 lian:skills.air.1 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
  


}
export function delayItem(player, id, slot, delay, isSecondHotbar = true, replace = "lian:skills.air.1") {
  
  player.runCommandAsync(`replaceitem entity @s slot.hotbar ` + slot + ` ` + replace + ` 1 0 {"minecraft:item_lock":{ "mode": "lock_in_slot" }, "minecraft:keep_on_death":{}}`)
  if (slot === 1 || slot === 2 || slot === 3) {

    player.setDynamicProperty("slot." + slot + ".delay", delay * 5)
    player.setDynamicProperty("slot." + slot + ".is", 1)
    player.setDynamicProperty("slot." + slot + ".item", id)


  } else if (slot > 3 && !isSecondHotbar) {

    player.setDynamicProperty("slot.1." + slot + ".delay", delay * 5)
    player.setDynamicProperty("slot.1." + slot + ".is", 1)
    player.setDynamicProperty("slot.1." + slot + ".item", id)


  } else {

    player.setDynamicProperty("slot.2." + slot + ".delay", delay * 5)
    player.setDynamicProperty("slot.2." + slot + ".is", 1)


  } 


}

export function getScore(player, objective) {
  
  try {
    
    return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity)
  
  
  } catch (error) {
    
    return 0
  
  
  } 


}

export function addScore(objective) {

  try {

    mc.world.scoreboard.addObjective(objective, objective)


  } catch {}


}

export function removeScore(player, objective, value) {

  player.runCommandAsync("scoreboard players remove @s " + objective + " " + value)

}

export function setScore(player, objective, value) {

  player.runCommandAsync("scoreboard players set @s " + objective + " " + value)

}

export function random(min, max) {

  return Math.floor(Math.random() * (max - min + 1)) + min


}

export async function forceShow(player, form, timeout = Infinity) {

  const startTick = mc.system.currentTick
  while ((mc.system.currentTick - startTick) < timeout) {

    const response = await /** @type {ReturnType<Form["show"]>} */(form.show(player))
    if (response.cancelationReason !== "userBusy") {

      return response


    }


  }
  throw new Error(`Timed out after ${timeout} ticks`)


}

export function item(player, informations, callback = null) {

  if (!player.hasTag("start.98723")) {

    addScore("powerCharge")
    setScore(player, "powerCharge", 0)
    addScore("powerChargeMax")
    setScore(player, "powerChargeMax", 0) 
    player.addTag("start.98723")


  }

  if (!player.hasTag("start.item." + informations.id)) {

    informations.slots.forEach(slot => {

       addScore(informations.id + ".time." + slot.id)
       addScore(informations.id + ".delay." + slot.id)
       setScore(player, informations.id + ".time." + slot.id, 0)
       setScore(player, informations.id + ".delay." + slot.id, `${slot.delay}`)
       player.addTag("start.item." + informations.id)

      
    })


  }
  informations.slots.forEach(slot => {

    getScore(player, informations.id + ".time." + slot.id) >= 1 ? removeScore(player, informations.id + ".time." + slot.id, 1): null

   
 })
  

  if (player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId === informations.id) {

    if (callback) {

      callback(player, informations)
  
  
    }
    
    player.hasTag("item." + informations.id) ? null: (
      
      player.removeTag(`${player.getTags().find((tag) => tag.startsWith("item."))}`),
      player.removeTag(`${player.getTags().find((tag) => tag.startsWith("slotSelected."))}`),
      player.addTag("slotSelected." + 1)


    )
    player.addTag("item." + informations.id)

    if (player.hasTag("query.attack_time")) {

      player.getTags().find((tag) => tag.startsWith("slotSelected.")) ? null: player.addTag("slotSelected.1")
      const slot = parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", ""))

      if (slot < informations.slots.length) {

        player.removeTag(player.getTags().find((tag) => tag.startsWith("slotSelected.")))
        player.addTag("slotSelected." + (slot + 1))


      } else {

        player.removeTag(player.getTags().find((tag) => tag.startsWith("slotSelected.")))
        player.addTag("slotSelected." + 1)


      }
      player.removeTag("query.attack_time")
      console.warn(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", ""))



    }

    if (informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].type === 1) {

      if (itemStart(player, informations.id)) {

        if (getScore(player, informations.id + ".time." + informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].id) === 0) {

          informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].state(player)
          setScore(player, informations.id + ".time." + informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].id, getScore(player, informations.id + ".delay." + informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].id))



        } else {

          informations.events.noTime(player)


        }


      }


    }
    if (informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].type === 2) {

      if (getScore(player, informations.id + ".time." + informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].id) === 0) {

        if (itemStart(player, informations.id)) {

          informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].state[0](player)
          setScore(player, "powerChargeMax", informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].charge)


        } else if (itemUsing(player, informations.id)) {

          informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].state[1](player)
          setScore(player, "powerCharge", getScore(player, "powerCharge") < getScore(player, "powerChargeMax") ? getScore(player, "powerCharge") + 1: getScore(player, "powerCharge"))


        } else if (itemStop(player, informations.id) && getScore(player, "powerCharge") >= getScore(player, "powerChargeMax")) {

          informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].state[2](player)
          setScore(player, "powerCharge", 0)
          setScore(player, informations.id + ".time." + informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].id, getScore(player, informations.id + ".delay." + informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].id))


        } else if (getScore(player, "powerCharge") < getScore(player, "powerChargeMax") && getScore(player, "powerCharge") !== 0) {

          informations.events.noCharge(player)
          setScore(player, "powerCharge", 0)
          setScore(player, informations.id + ".time." + informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].id, getScore(player, informations.id + ".delay." + informations.slots[parseInt(player.getTags().find((tag) => tag.startsWith("slotSelected.")).replace("slotSelected.", "")) - 1].id))


        }


      } else {

        informations.events.noTime(player)


      }


    }



  } else if (!player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)?.typeId.startsWith("lian:ui.")) {

    player.removeTag(`${player.getTags().find((tag) => tag.startsWith("item."))}`)
    player.removeTag(`${player.getTags().find((tag) => tag.startsWith("slotSelected."))}`),
    player.addTag("slotSelected." + 1)


  }


}

export function itemStart(player, itemTypeId) {

  if (player.hasTag(itemTypeId + "item.starUse")) {

    player.removeTag(itemTypeId + "item.starUse")
    return true


  }
  return false


}
export function itemUsing(player, itemTypeId) {

  if (player.hasTag(itemTypeId + "item.using")) {

    return true


  }
  return false


}
export function itemStop(player, itemTypeId) {

  if (player.hasTag(itemTypeId + "item.stopUse")) {

    player.removeTag(itemTypeId + "item.stopUse")
    return true


  }
  return false


}

mc.world.afterEvents.itemStartUse.subscribe(data => {

  data.source.addTag(data.itemStack.typeId + "item.using")
  data.source.addTag(data.itemStack.typeId + "item.starUse")


})
mc.world.afterEvents.itemStopUse.subscribe(data => {

  data.source.removeTag(data.itemStack.typeId + "item.using")
  data.source.addTag(data.itemStack.typeId + "item.stopUse")


})

export function getItemInInventory(player, item) {

  let inventory = []
  let amount = 0
  for (let i = 0; i < player.getComponent("minecraft:inventory").container.size; i++) {

    if (player.getComponent("minecraft:inventory").container.getItem(i)?.typeId === item) {

      amount = amount + player.getComponent("minecraft:inventory").container.getItem(i).amount


    }


  }
  return amount


}

// export const hotbar = {

//   save: function(player) {

//     const stasher = player.dimension.spawnEntity("lian:items_change", new mc.Vector(player.location.x, 100, player.location.z));
//     stasher.nameTag = "lian:stasher_for_" + player.name
//     const inv = player.getComponent("inventory").container
//     const inv_stash = stasher.getComponent("inventory").container
//     for (let i = 0; i < 9; i++) {

//         if (!inv.getItem(i))
//         continue;
//         inv.swapItems(i, i, inv_stash)

        
//     }
//     stasher.runCommandAsync("structure save " + player.nameTag + ":save_inv ~~~ ~~~ true").then(() => {

//       stasher.triggerEvent("kill")


//     })
//     return false


//   },
//   load: function(player) {

//     let stasher
//     const stasherName = "lian:stasher_for_" + player.name
//     player.runCommandAsync("structure load " + player.nameTag + ":save_inv ~ 10 ~ 0_degrees none true").then(() => {

//       for (const entity of player.dimension.getEntities({ name: stasherName })) {

//         stasher = entity;


//       }
//       if (stasher) {

//         const inv = player.getComponent("inventory").container
//         const inv_stash = stasher.getComponent("inventory").container
//         for (let i = 0; i < 9; i++) {

//             inv.swapItems(i, i, inv_stash)


//         }
//         player.runCommandAsync(`tp @e[name="${stasherName}"] ~ ~ ~`)
//         stasher.triggerEvent("kill")
//         stasher.nameTag = "despawned"
//         return false

        
//       } else {

//         return true


//       }



//     })


//   }


// }
export const hotbar = {

  save: function(player) {

    const stasher = player.dimension.spawnEntity("lian:items_change", {x: player.location.x, y: player.location.y, z: player.location.z})
    stasher.setDynamicProperty("owner", player.nameTag)
    for (let i = 4; i < 9; i++) {

      if (player.getComponent("inventory").container.getItem(i)) {

        player.getComponent("inventory").container.swapItems(i, i, stasher.getComponent("inventory").container)


      }


    }
    stasher.runCommandAsync("structure save " + player.nameTag + ":save_inv ~~~ ~~~ true")
    const tick = mc.system.runInterval(() => {

      try {
        
        stasher.teleport({x: player.location.x, y: player.location.y, z: player.location.z})
        

      } catch {




      }


    }, convertTick(1))

  },
  load: function(player) {

    player.runCommandAsync("structure load \"" + player.nameTag + ":save_inv\" ~ 10 ~ 0_degrees none true").then(() => {

      const entities = player.dimension.getEntities({type: "lian:items_change"})
      entities.forEach(stasher => {
  
        if (stasher?.getDynamicProperty("owner") === player.nameTag) {
  
          for (let i = 4; i < 9; i++) {
  
              stasher.getComponent("minecraft:inventory").container.swapItems(i, i, player.getComponent("minecraft:inventory").container)
      
      
          }
          stasher.remove()
  
  
        }
  
  
      })
  


    })


  }


}
export function convertTick(sec) {

  return sec*20;


}
export function close(player) {

  hotbar.load(player); player.removeTag("secondHotbar")


}
export function removeItem(player, array) {

  array.forEach(item => {for (let i = 0; i < player.getComponent("minecraft:inventory").container.size; i++) {if (player.getComponent("minecraft:inventory").container.getItem(i)?.typeId === item.id) {player.getComponent("minecraft:inventory").container.setItem(i, new mc.ItemStack("minecraft:air", 1))}}})


}
export function hitUi(player, text) {

  let x = ""; let y = ""; let xN = random(0, 50); let yN = random(0, 15); let xE = random(0, 1); let yE = random(0, 1)
  for (let i = 0; i < xN; i++) {

    x = x + " "


  }
  for (let i = 0; i < yN; i++) {

    y = y + "\n"


  }


  player.onScreenDisplay.setActionBar((yE === 0 ? y: "") + (xE === 0 ? x: "") + text + (xE === 1 ? x: "") + (yE === 1 ? y: ""))


}
export function subtitle(player, text) {

  player.onScreenDisplay.setActionBar("\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + text)


}
export function spawnProjectile(player, id, strength, vector, modifierLoc) {

  const locate = player.dimension.spawnEntity("lian:projectileView", {x: player.location.x, y: player.location.y + 2, z: player.location.z})
  locate.runCommandAsync("execute at @a[name=\"" + player.nameTag + "\"] positioned ^"  + modifierLoc.x + "^" + modifierLoc.y + "^" + modifierLoc.z + " run tp @s ~~~").then(() => {

    const entity = player.dimension.spawnEntity(id, {x: locate.location.x, y: locate.location.y + 2, z: locate.location.z})
    entity.setDynamicProperty("owner", player.nametag)
    entity.applyImpulse({x: vector.x * strength, y: vector.y * strength, z: vector.z * strength})


  })


}
export function aiming(player, text) {

  player.onScreenDisplay.setActionBar(text + "\nV\n\n\n\n\n\n\n")


}
export const expansion = {

  create: function(player, expansionId, expansionTime, start, repeat, end) {},
  remove: function(player, end) {}


}
export function clamp(num, min, max) {return parseInt(Math.min(Math.max(num, min), max))}
export function randomColor() {

  const colors = [
    "§6",
    "§7",
    "§a",
    "§b",
    "§c",
    "§d",
    "§e",
    "§f",
    "§g",
    "§h",
    "§i",
    "§j",
    "§m",
    "§n",
    "§p",
    "§q",
    "§s",
    "§t",
    "§1"
  ]
  return colors[random(0, colors.length - 1)];


}
export function conditionSkill(player, energy, type, callback) {
  
  !player.getDynamicProperty("mastery") ? player.setDynamicProperty("mastery", 0): null
  if (type === 0 || player.getDynamicProperty("mastery") >= skills[player.getDynamicProperty("skill")].mastery[player.selectedSlot - 4][type - 1] || player.hasTag("sla")) {

    if (getScore(player, "energy_cur") >= energy) {
    
      player.setDynamicProperty("mastery", player.getDynamicProperty("mastery") + 1)
      setScore(player, "energy_cur", getScore(player, "energy_cur") - energy)
      const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (random(-100, 100) / 100), y: player.location.y + 0.1, z: player.location.z + (random(-100, 100) / 100)})
      display.nameTag = `§b-${energy}`
      callback(player)
  
    
    } else {
      
      hitUi(player, "§cYou don't have enough cursed energy."); player.playSound("note.bass")
    
    
    }


  } else {
      
    hitUi(player, "§cYou need " + skills[player.getDynamicProperty("skill")].mastery[player.selectedSlot - 4][type - 1] + " mastery for this skill."); player.playSound("note.bass")
  
  
  }


}
export function conditionSkillMob(player, energy, a, callback) {
  
  !player.getDynamicProperty("mastery") ? player.setDynamicProperty("mastery", 0): null
    if (getScore(player, "energy_cur") >= energy) {
    
      setScore(player, "energy_cur", Math.round(getScore(player, "energy_cur") - energy))
      const display = player.dimension.spawnEntity("lian:text", {x: player.location.x + (random(-100, 100) / 100), y: player.location.y + 0.1, z: player.location.z + (random(-100, 100) / 100)})
      display.nameTag = `§b-${energy}`
      callback(player)
  
    
    }


}
export function removeExpansion(player, item) {

  delayItem(player, item, 8, 40)
  player.playSound("note.bass")
  player.setDynamicProperty("domain", 0)
  if (player.getDynamicProperty("skill") !== 6) {

    player.runCommandAsync("execute positioned " + player.getDynamicProperty("locAfterDomainX") + " 200 " + player.getDynamicProperty("locAfterDomainZ") + " run structure load domain.erase ~-25 ~-3 ~-25").then(() => {
 
      const entities = player.dimension.getEntities({location: {x: player.getDynamicProperty("locAfterDomainX"), y: player.location.y, z: player.getDynamicProperty("locAfterDomainZ")}, maxDistance: 30, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
      entities.forEach(entity => {
  
        entity.removeTag("isInExpansion")
        entity.removeTag("ownerExpansion")
        entity.getDynamicProperty("locAfterDomainY") ? entity.teleport({x: entity.getDynamicProperty("locAfterDomainX"), y: entity.getDynamicProperty("locAfterDomainY"), z: entity.getDynamicProperty("locAfterDomainZ")}): null
        entity.typeId === "minecraft:player" ? (entity.runCommandAsync("camera @s fade time 0 0 1 color 0 0 0"), entity.runCommandAsync("fog @s remove domainFog"), entity.addTag("breacksBlock")): null
  
  
      })
      player.setDynamicProperty("domainIs", 0)
  
  
    })


  } else {

    delayItem(player, "lian:skills.2.6", 8, 40)
    player.setDynamicProperty("domain", 0)
    player.runCommandAsync("stopsound @a[r=100] skills.6.5.3")
    const visuals = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, type: "lian:skills.6.5"})
    visuals.forEach(visual => {

      visual.playAnimation("animation.3")
      mc.system.runTimeout(() => {visual.remove()}, convertTick(2))


    })
    const entities = player.dimension.getEntities({location: {x: player.location.x, y: player.location.y, z: player.location.z}, maxDistance: 50, minDistance: 0, excludeFamilies: ["not"], excludeTypes: ["orb"]})
    entities.forEach(entity => {

      entity.removeTag("ownerExpansion")
      entity.typeId === "minecraft:player" ? (entity.runCommandAsync("fog @s remove domainFog"), entity.removeTag("remove_knockback"), entity.removeTag("isInExpansion")): null


    })
    player.setDynamicProperty("domainIs", 0); player.setDynamicProperty("domainTime", 0)
    player.setDynamicProperty("multiplier", 1)


    
  }


}