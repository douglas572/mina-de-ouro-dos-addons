import * as mc from "@minecraft/server";
import * as lib from "./lib.js";

lib.tick(async function(player) {

  !player.getDynamicProperty("scene") ? player.setDynamicProperty("scene", 0): null
  player.onScreenDisplay.setTitle(

    (player.getDynamicProperty("scene") === 1 ? "hud.0": "hud.1") +
    `hp:` + parseInt(player.getComponent("minecraft:health").currentValue / player.getComponent("minecraft:health").defaultValue * 100) +
    `energia:` + parseInt(lib.getScore(player, 'energy_cur') / lib.getScore(player, 'energy_base') * 100) +
    `exp:` + parseInt(lib.getScore(player, 'exp') / lib.getScore(player, 'exp_base') * 100) +
    (player.getDynamicProperty("scene") === 0 ? (player.hasTag("start.menu") ? player.hasTag("secondHotbar") ? player.getDynamicProperty("clash") === 0 ? "hotbar.2": "hotbar.3": "hotbar.1": "hotbar.0"): "") +
    (player.getDynamicProperty("scene") === 1 ? "scene.1": "scene.0") +
    (player.getDynamicProperty("scene") === 0 ? 
    "slot.1:" + parseInt(player.getDynamicProperty("slot.1.delay") / 5) + ";" +
    "slot.2:" + parseInt(player.getDynamicProperty("slot.2.delay") / 5) + ";" + 
    "slot.3:" + parseInt(player.getDynamicProperty("slot.3.delay") / 5) + ";" +
    (!player.hasTag("secondHotbar") ? 
    "slot.4:" + parseInt(player.getDynamicProperty("slot.1.4.delay") / 5) + ";" +
    "slot.5:" + parseInt(player.getDynamicProperty("slot.1.5.delay") / 5) + ";" +
    "slot.6:" + parseInt(player.getDynamicProperty("slot.1.6.delay") / 5) + ";" +
    "slot.7:" + parseInt(player.getDynamicProperty("slot.1.7.delay") / 5) + ";" +
    "slot.8:" + parseInt(player.getDynamicProperty("slot.1.8.delay") / 5) + ";":
    "slot.3:" + parseInt(player.getDynamicProperty("slot.2.3.delay") / 5) + ";" +
    "slot.4:" + parseInt(player.getDynamicProperty("slot.2.4.delay") / 5) + ";" +
    "slot.5:" + parseInt(player.getDynamicProperty("slot.2.5.delay") / 5) + ";" +
    "slot.6:" + parseInt(player.getDynamicProperty("slot.2.6.delay") / 5) + ";" +
    "slot.7:" + parseInt(player.getDynamicProperty("slot.2.7.delay") / 5) + ";" +
    "slot.8:" + parseInt(player.getDynamicProperty("slot.2.8.delay") / 5) + ";"
    ): "") +
    (player.getDynamicProperty("clash") === 0 ? "": ((player.getDynamicProperty("clashNumber") === 1 ? "clashNumber.1": "") +
    (player.getDynamicProperty("clashNumber") === 2 ? "clashNumber.2": "") +
    (player.getDynamicProperty("clashNumber") === 3 ? "clashNumber.3": "") +
    (player.getDynamicProperty("clashNumber") === 4 ? "clashNumber.4": "")))




  )
  const view = player.getEntitiesFromViewDirection({maxDistance: 8})
  let viewText = ""
  const space = ""
  if (view[0]) {

    viewText = view[0].entity.typeId === "minecraft:player" || view[0].entity.hasTag("player") ? (view[0].entity.getDynamicProperty("name") ? view[0].entity.getDynamicProperty("name"): view[0].entity.nameTag) + "\n\n\n" + space + "§fHP §c" + parseInt(view[0].entity.getComponent("minecraft:health").currentValue) + " / " + parseInt(view[0].entity.getComponent("minecraft:health").defaultValue) + "\n\n\n" + space + "§fENG §b" + parseInt(lib.getScore(view[0].entity, "energy_cur")) + " / " + parseInt(lib.getScore(view[0].entity, "energy_base")): (view[0].entity.getDynamicProperty("name") ? view[0].entity.getDynamicProperty("name"): view[0].entity.typeId) + "\n\n\n" + (view[0].entity.getDynamicProperty("class") ? view[0].entity.getDynamicProperty("class")  + "\n\n\n": "") + space + "§fHP §c" + parseInt(view[0].entity.getComponent("minecraft:health").currentValue) + " / " + parseInt(view[0].entity.getComponent("minecraft:health").defaultValue)


  }
  player.onScreenDisplay.updateSubtitle(

    "ui:§r" + 
    "      " + player.nameTag +
    "\n\n\n\n\n\n                                                                                §rhp " + parseInt(player.getComponent("minecraft:health").currentValue) + "/§7" + parseInt(player.getComponent("minecraft:health").defaultValue) +
    "\n\n\n\n\n                                                                                   §reng " + lib.getScore(player, 'energy_cur') + "/§7" + lib.getScore(player, 'energy_base') +
    "\n\n\n\n  §7" + lib.getScore(player, 'exp') +
    "\n        §7/" +
    "\n           §7" + lib.getScore(player, 'exp_base') +
    "\n\n\n\n\n     §rlv" + lib.getScore(player, 'level') + "                                                                                                   $" + lib.getScore(player, 'yen') +
    (player.getDynamicProperty("mission.have") ? ("\n\n\n\n\n\n\n\n\n\n\n §7Quests" +
    "\n\n\n\n\n\n\n     §r- " + player.getDynamicProperty("mission.text")): "") +

    "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n     §rhp " + lib.getScore(player, 'hp_cur') +
    "\n\n\n     §rres " + lib.getScore(player, 'res_cur') +
    "\n\n\n     §rstr " + lib.getScore(player, 'str_cur') +
    (player.isSprinting ? "\n\n\n     §rmvm " + lib.getScore(player, 'mvm_cur'): "\n\n\n     §rmvm " + 1) +
    "\n\n\n     §rKnc " + lib.getScore(player, 'jmp_cur') +
    "\n\n\n     §rrgn " + lib.getScore(player, 'rgn_cur') +
    "\n\n\n     §reng " + lib.getScore(player, 'energy_cur') +
    "\n\n\n     " + player.getDynamicProperty("domainTime") +
    "\n\n\n     round " + player.getDynamicProperty("clashStage") +
    "\n\n\n     hit " + player.getDynamicProperty("clasHits") +
    "\n\n\n     hotbar " + player.selectedSlot +
    "\n\n\n     domain " + player.getDynamicProperty("domain") +
    "\n\n\n     clash " + player.getDynamicProperty("clash") +
    "\n\n\n     Maestry " + player.getDynamicProperty("mastery") +
    "\n\n\n     InAttack " + (player.hasTag("inAttack") ? "1": "0") +
    "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + space + "§e" + viewText
    

  )


}, lib.convertTick(0.5))
