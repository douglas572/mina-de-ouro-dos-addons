import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from "./lib.js";

mc.world.beforeEvents.itemUse.subscribe(data => {
  
  if (data.itemStack.typeId == "lian:menu") {mc.system.run(() => {menu_1(data.source)})}
  if (data.itemStack.typeId == "lian:menu.start") {mc.system.run(() => {menuCustom(data.source)})
    
    
  }
  
  
})
function menu_1(player) {

  const data = new ui.ActionFormData().title("menu_1").body("")
  .button("tab.1")
  .button("tab.2")
  .button("tab.3")
  .button("button.1").button("button.2").show(player).then(response => {

    switch(response.selection) {

      case 0: menu_1(player); break;
      case 1: menu_2(player); break;
      case 2: menu_3(player); break;
      case 3: habilidades(player); break;
      case 4: menu2(player); break;


    }


  })


}
function menu_2(player) {

  const data = new ui.ActionFormData().title("menu_2").body(
    "§rYp: §e" + lib.getScore(player, "yp") +
    "\n§rTp §e" + lib.getScore(player, 'tp') +
    "\n\n§rName: §e" + player.nameTag +
    "\n§rLevel: §e" + lib.getScore(player, 'level') +
    "\n§7" + lib.getScore(player, 'exp') + "§7/" + "§7" + lib.getScore(player, 'exp_base') +
    "\n§rYen: §e" + lib.getScore(player, 'yen') +
    "\n§rGrade: §e" + (player.getDynamicProperty("grade") === 5 ? "Normal Human": player.getDynamicProperty("grade") === 4 ? "Grade 4": player.getDynamicProperty("grade") === 3 ? "Grade 3": player.getDynamicProperty("grade") === 2 ? "Grade 2": player.getDynamicProperty("grade") === 1 ? "Grade 1": player.getDynamicProperty("grade") === 6 ? "Grade Especial": null) +
    "\n§rHealth: §e" + lib.getScore(player, "hp_base") + 
     "\n§rResistance: §e" + lib.getScore(player, "res_base") + 
     "\n§rDamage: §e" + lib.getScore(player, "str_base") + 
     "\n§rMoviment: §e" + lib.getScore(player, "mvm_base") + 
     "\n§rEnergy: §e" + lib.getScore(player, "energy_base")
     )
  .button("tab.1")
  .button("tab.2")
  .button("tab.3")
  .button("button.1").button("button.2").button("button.3").button("button.4").button("button.5").button("button.6").show(player).then(response => {

    switch(response.selection) {

      case 0: menu_1(player); break;
      case 1: menu_2(player); break;
      case 2: menu_3(player); break;
      case 3: if (lib.getScore(player, "hp_base") <= 2000) {if (lib.getScore(player, "yp") > 0) {menu_2_1(player, "Heath", "hp_", 2000, 25)} else {lib.hitUi(player, "§cYou don't have enough yp"); player.playSound("note.bass")}} else {lib.hitUi(player, "§eYou have already evolved this status to the maximum"); player.playSound("note.bass")} break;
      case 4: if (lib.getScore(player, "res_base") <= 400) {if (lib.getScore(player, "yp") > 0) {menu_2_1(player, "Resistance", "res_", 400, 1)} else {lib.hitUi(player, "§cYou don't have enough yp"); player.playSound("note.bass")}} else {lib.hitUi(player, "§eYou have already evolved this status to the maximum"); player.playSound("note.bass")} break;
      case 5: if (lib.getScore(player, "str_base") <= 200) {if (lib.getScore(player, "yp") > 0) {menu_2_1(player, "Strength", "str_", 200, 1)} else {lib.hitUi(player, "§cYou don't have enough yp"); player.playSound("note.bass")}} else {lib.hitUi(player, "§eYou have already evolved this status to the maximum"); player.playSound("note.bass")} break;
      case 6: if (lib.getScore(player, "mvm_base") <= 300) {if (lib.getScore(player, "yp") > 0) {menu_2_1(player, "Moviment", "mvm_", 300, 1)} else {lib.hitUi(player, "§cYou don't have enough yp"); player.playSound("note.bass")}} else {lib.hitUi(player, "§eYou have already evolved this status to the maximum"); player.playSound("note.bass")} break;
      case 7: if (lib.getScore(player, "energy_base") <= 10000) {if (lib.getScore(player, "yp") > 0) {menu_2_1(player, "Energy", "energy_", 10000, 25)} else {lib.hitUi(player, "§cYou don't have enough yp"); player.playSound("note.bass")}} else {lib.hitUi(player, "§eYou have already evolved this status to the maximum"); player.playSound("note.bass")} break;


    }


  })


}
function menu_2_1(player, title, score, max, upValue) {

  const data = new ui.ModalFormData()
  .title("modal:" + title + ": " + lib.getScore(player, score + "base") + "/" + max)
  .slider("Max: " + (max - lib.getScore(player, score + "cur")) + " Add", 0, lib.getScore(player, "yp"), 1, 0)
  .show(player).then(r => {

    if (r.formValues[0] <= (max - lib.getScore(player, score + "cur"))) {

      lib.setScore(player, score + "cur", lib.getScore(player, score + "cur") + (r.formValues[0] * upValue))
      lib.setScore(player, score + "base", lib.getScore(player, score + "base") + (r.formValues[0] * upValue))
      lib.setScore(player, "yp", lib.getScore(player, "yp") - r.formValues[0])
      player.playSound("note.banjo")
      menu_2(player)


    } else {lib.hitUi(player, "§cYou reached the limit!"); player.playSound("note.bass")}


  })


}
function menu_3(player) {

  const data = new ui.ActionFormData().title("menu_3").body("")
  .button("tab.1")
  .button("tab.2")
  .button("tab.3");
  const missions = [
    {title: "Defeat the cursed corpse controlled by Director Yaga, proving your worth.", command: function(player) {player.runCommandAsync("summon lian:enemy.0.1")}},
    {title: "Exorcise 15 curses Grade 4.", command: function(player) {}},
    {title: "Exorcise 35 curses Grade 4.", command: function(player) {}},
    {title: "Graduation mission - Exorcise the Masked.", command: function(player) {player.runCommandAsync("summon lian:enemy.0.2")}},
    {title: "Exorcise 10 curses Grade 3.", command: function(player) {}},
    {title: "Exorcise 35 curses Grade 3.", command: function(player) {}},
    {title: "Graduation mission - Exorcise the Dinosaur Curse.", command: function(player) {}},
    {title: "Exorcise 10 curses Grade 2.", command: function(player) {}},
    {title: "Exorcise 35 curses Grade 2.", command: function(player) {}},
    {title: "Graduation mission - Exorcise the Insect Curse.", command: function(player) {player.runCommandAsync("summon lian:enemy.0.3")}},
    {title: "Exorcise 10 curses Grade 1.", command: function(player) {}},
    {title: "Exorcise 35 curses Grade 1.", command: function(player) {}},
    {title: "Graduation mission - Defeat the sukuna boss.", command: function(player) {}}
  ]
  missions.forEach((element, index) => {data.button(element.title + `\n${player.hasTag(`mission:${(index + 1)}.finaly`) ? "§aFinished": player.hasTag(`mission:${(index + 1)}.cur`) ? "§eDoing": player.hasTag(`mission:${(index + 1) - 1}.finaly`) ? "§eAvailable": "§cBlocked"}`)})
  data.show(player).then(response => {

    switch(response.selection) {

      case 0: menu_1(player); break;
      case 1: menu_2(player); break;
      case 2: menu_3(player); break;


    }
    missions.forEach((button, index) => {

      if ((index + 3) === response.selection) {

          if (player.hasTag(`mission:` + (index + 1) + `.finaly`)) {
            
            button.command(player); player.addTag(`mission:` + (index + 1) + `.cur`);
            player.sendMessage(button.title); player.setDynamicProperty("mission.have", true);
            player.setDynamicProperty("mission.text", button.title); player.setDynamicProperty("mission.condition", 0)


          }
          else if (player.hasTag(`mission:` + (index + 1) + `.cur`)) {player.sendMessage(`this quest is in progress`)}
          else if (!player.hasTag(`mission:` + index + `.finaly`)) {player.sendMessage(`complete others first!`)}
          else if (player.hasTag(`mission:` + index + `.finaly`)) {
            
            button.command(player); player.addTag(`mission:` + (index + 1) + `.cur`);
            player.sendMessage(button.title); player.setDynamicProperty("mission.have", true);
            player.setDynamicProperty("mission.text", button.title); player.setDynamicProperty("mission.condition", 0)
          
            
          }
        
        
        }


    })


  })


}

function menu2(player) {
  
  const data = new ui.ActionFormData().title("custom:Clothings").body("").button("1").button("2").button("3").show(player).then((r) => {

    switch(r.selection) {

      case 0:
        menu2_1(player, 1)
      break;
      case 1:
        menu2_1(player, 2)
      break;
      case 2:
        menu2_1(player, 3)
      break;
      default:
        menu(player)
      break;


    }


  })
  
  
}
function menu2_1(player, slot) {
  
  const data = new ui.ActionFormData().title("custom:Clothings").body("")
  let buttons = []
  player.getTags().forEach((tag) => {

    if (tag.startsWith("clothing." + slot)) {

      let tagSplit = tag.replace("clothing.", "").split(".")
      buttons.push({class: tagSplit[0], id: tagSplit[1], tag: `${tag}`})

      
    }


  })
  buttons.forEach((element) => {data.button(element.tag, ("textures/custom/clothing/" + element.class + "/" + element.id + ".icon"))})
  data.show(player).then((r) => {
    
    if (!r.canceled) {
      
      lib.setScore(player, "clothing." + buttons[r.selection].class, buttons[r.selection].id)
      console.warn(buttons[r.selection].id)
      menu2_1(player, slot)


    } else {

      menu2(player)

      
    }


  })
  
  
}
function menuCustom(player) {
  
  const data = new ui.ActionFormData().title("custom:Custom").body("").button("1", "textures/custom/1.icon").button("2", "textures/custom/2.icon").button("3", "textures/custom/3.icon").button("4", "textures/custom/finish").show(player).then((r) => {

    switch(r.selection) {

      case 0:
        menuCustom1(player, "skin", 2)
      break
      case 1:
        menuCustom1(player, "hair", 10)
      break
      case 2:
        menuCustom1(player, "scar", 3)
      break
      case 3:
        player.setDynamicProperty("canTeleport", 0)
        player.addTag("start.menu")
        player.runCommandAsync("function lian/start")
      break;


    }


  })
  
  
}
function menuCustom1(player, name, max) {
  
  const data = new ui.ActionFormData().title("custom:Clothings").body("")
  for (let i = 0; i <= max; i++) {data.button("", "textures/custom/" + name + "/" + i + ".icon")}
  data.show(player).then((r) => {
    
    if (!r.canceled) {
      
      lib.setScore(player, name, r.selection)
      menuCustom1(player, name, max)


    } else {

      menuCustom(player)

      
    }


  })
  
  
}

function habilidades(player) {

  const data = new ui.ActionFormData().title("shop:Skills").body("")
  const buttons = [
    {text: "Divergent Fist", texture: "textures/lian/icons/skills/extra/3", tp: 5000, eng: 50, lv: 5, itemId: "lian:skills.extra.3"},
    {text: "Black Flash", texture: "textures/lian/icons/skills/extra/1", tp: 10000, eng: 110, lv: 15, itemId: "lian:skills.extra.1"},
    {text: "Simple Domain", texture: "textures/lian/icons/skills/extra/2", tp: 25000, eng: 2000, lv: 25, itemId: "lian:skills.extra.2"},
    {text: "Reverse Energy", texture: "textures/lian/icons/basic/4", tp: 35000, eng: 2000, lv: 35, itemId: "lian:nothing"}
  ]
  buttons.forEach(button => {data.button(button.text, button.texture)})
  data.show(player).then(response => {habilidadesDetails(player, buttons[response.selection])})


}
function habilidadesDetails(player, button) {

  let condition = true, tp = true, level = true
  lib.getScore(player, "tp") >= button.tp ? (condition = true, tp = true): (tp = false, player.sendMessage("§fYou don't have enough §cTp"))
  lib.getScore(player, "level") >= button.lv ? (condition = true, level = true): (level = false, player.sendMessage("§fYou don't have enough §cLevel"))
  tp === true && level === true ? condition = true: condition = false
  const data = new ui.ActionFormData().title("interact:" + button.text).body(`\n\n` + `Tp: ` + ((tp ? "§e": "§c") + button.tp + `\n`) + "§rLevel: " + ((level ? "§e": "§c") + button.lv)).button("To Obtain").button("Best Not")
  .show(player).then(response => {

    switch(response.selection) {

      case 0: condition === true ? (player.runCommandAsync("give @s " + button.itemId), player.playSound("note.banjo"), lib.hitUi(player, "§fYou bought §e" + button.text + " §c - " + button.tp + " of Tp"), lib.setScore(player, "tp", lib.getScore(player, "tp") - button.tp)): (player.playSound("note.bass"), lib.hitUi(player, "§fyou can't buy this §cSkill")); break;
      case 1: habilidades(player); break;


    }


  })
  

}
